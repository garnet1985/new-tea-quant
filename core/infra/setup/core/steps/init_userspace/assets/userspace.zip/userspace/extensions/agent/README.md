# Agent 用户扩展

本目录扩展 **New Tea Quant 助理**（`modules.agent`）的行为。  
大模型出站密钥请放在同级的 `../llm_providers/`，不要放这里。

```text
agent/
├── tools/        # 新增工具（唯一需要写 Python 的地方）
├── templates/    # 呈现模版（Markdown，可覆盖 / 新增）
└── prompts/      # 偏好与背景（Markdown，只追加）
```

## 能做什么

| 子目录 | 形式 | 规则 |
|--------|------|------|
| `tools/{name}/tool.py` | Python | **只能新增**；与内置工具同名会被忽略 |
| `templates/{scenario}.md` | Markdown | 可**覆盖**内置 scenario，也可**新增** |
| `prompts/{lane}.md` | Markdown | **只追加**进对应阶段；与产品红线冲突时以产品为准 |

## 不能做什么

- 不能改红线、NTQ 说明书（wiki）、Navigator 分流种类
- 不能整包替换 guider / worker / present 的 system 文案
- 扩展不得用于绕过合规出口（投资建议陷阱、越界资讯等）

## 免责

New Tea Quant **不对**你在本目录自行扩展的工具、模版与提示词的正确性、安全性或后果负责。  
详情见各子目录 README；产品侧说明见 `modules.agent` 的 QUICKSTART。
