# prompts — 偏好与背景（只追加）

以下文件名为固定 lane，按需创建即可（没有则跳过）：

| 文件 | 注入位置 |
|------|----------|
| `context.md` | 会话 system（背景 / 喜好） |
| `worker.md` | 执行者 system 末尾 |
| `guider.md` | 介绍者 wiki system 末尾 |
| `present.md` | 呈现阶段 system 末尾 |

## 规则

- **只追加**，不能替换产品 system
- 每文件有字数上限（见产品 conf：`USERSPACE_PROMPT_SNIPPET_MAX_CHARS`），超出会截断
- 注入时带标题：「用户扩展（偏好；与上方冲突时以上方为准）」
- 与红线、输出协议、数字来源冲突时，**以产品说明为准**

## 示例（`context.md`）

```markdown
我主要做 A 股短线研究，回复请简洁。
常用策略目录：ma20_touch、rsi_v1。
资金层报告请优先写回撤和利用率。
```

合规出口（identity / 投资建议陷阱 / 越界资讯）**不会**加载这些片段。
