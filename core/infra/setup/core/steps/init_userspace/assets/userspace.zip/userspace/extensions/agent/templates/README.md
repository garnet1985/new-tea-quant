# templates — 呈现模版（present）

助理在 **present** 阶段按 scenario 套模版改版式。这里的文件全是 Markdown。

```text
templates/
├── backtest_price.md    # 与内置同名 → 覆盖版式正文
└── my_portfolio.md      # 新名字 → 需 frontmatter match 才会自动命中
```

## 覆盖内置

文件名与产品内置 scenario 相同即可，例如 `backtest_price.md`。  
只需写正文；**不必**写 frontmatter。命中规则仍用产品内置逻辑。

## 新增 scenario

文件名即 scenario 名。若希望自动命中，在文件头加 YAML frontmatter：

```markdown
---
match:
  tool: read_execution_report
  layer: portfolio
  user_re: 总结|解读
---

# 我的资金层报告版式

……章节骨架……
```

| 字段 | 含义 |
|------|------|
| `tool` | 本轮成功调用过的工具名（必填） |
| `layer` | 可选；工具结果里的 `layer`（如 `price` / `portfolio`） |
| `user_re` | 可选；用户原话正则 |

没有 `match` 的新文件：模版会登记，但**不会自动套用**（避免误触发）。

## 与 prompts 的分工

- **templates**：报告长什么样（章节骨架）
- **prompts/present.md**：语气、详略等口味（追加进 present，冲突听产品红线）
