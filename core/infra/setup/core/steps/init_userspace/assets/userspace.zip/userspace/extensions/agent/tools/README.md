# tools — 新增 Agent 工具

每个工具一个子目录，入口文件必须是 `tool.py`。

```text
tools/
└── my_tool/
    └── tool.py
```

## 约定

- **只能新增**：`TOOL["name"]` 若与内置工具同名（如 `create_strategy`），该工具会被忽略
- `run(arguments)` 必须返回 **dict**（建议含 `"ok": true/false`）
- 两种常见写法（同一套机制）：
  1. **外接**：在 `run` 里调你自己的 HTTP / SDK（密钥放本机，勿提交仓库）
  2. **包装 NTQ**：在 `run` 里调用本机已有 API（如策略 / 报告），做成新工具名

## 最小示例

```python
TOOL = {
    "name": "my_tool",
    "description": "一句话说明用途，给模型看。",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "查询词"},
        },
        "required": ["query"],
        "additionalProperties": False,
    },
}


def run(arguments):
    query = str((arguments or {}).get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "缺少 query"}
    return {"ok": True, "echo": query}
```

放好后重启 / 再开一轮对话即可出现在工具清单里（guider 只读工具白名单不含自定义工具时，需走 worker 流向才会调用）。
