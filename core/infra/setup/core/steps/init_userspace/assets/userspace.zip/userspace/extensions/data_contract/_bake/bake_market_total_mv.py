#!/usr/bin/env python3
"""从 MySQL（默认 ntq-full，只读）汇总全市场日频总市值，写出 CSV。

输出列：
- date：YYYYMMDD
- total_market_value：当日全市场 total_market_value 之和（库内单位：万元）
- stock_count：当日参与求和的股票只数（total_market_value 非空）

用法（仓库根目录）::

    ./venv/bin/python userspace/extensions/data_contract/_bake/bake_market_total_mv.py

默认写出到 ``../market_total_mv/market_total_mv_daily_2023_2025.csv``。
可选参数见 ``--help``。不对源库做任何写入。
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import pymysql

_DEFAULT_OUT = (
    Path(__file__).resolve().parent.parent
    / "market_total_mv"
    / "market_total_mv_daily_2023_2025.csv"
)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)
    out_path = Path(args.output).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(
        f"只读连接 {args.host}:{args.port}/{args.database} "
        f"区间 {args.start_date}–{args.end_date} …",
        flush=True,
    )
    rows = _fetch_daily_totals(
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        database=args.database,
        start_date=args.start_date,
        end_date=args.end_date,
    )
    _write_csv(out_path, rows)
    print(
        f"已写入 {out_path}：{len(rows)} 个交易日 "
        f"（{rows[0][0] if rows else '-'} … {rows[-1][0] if rows else '-'}）",
        flush=True,
    )
    return 0


def _parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="只读汇总 ntq-full 全市场日频总市值 → CSV"
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3306)
    parser.add_argument("--user", default="root")
    parser.add_argument("--password", default="")
    parser.add_argument(
        "--database",
        default="ntq-full",
        help="源库名（只读；默认 ntq-full）",
    )
    parser.add_argument("--start-date", default="20230101")
    parser.add_argument("--end-date", default="20251231")
    parser.add_argument(
        "--output",
        default=str(_DEFAULT_OUT),
        help=f"输出 CSV 路径（默认 {_DEFAULT_OUT}）",
    )
    return parser.parse_args(list(argv) if argv is not None else None)


def _fetch_daily_totals(
    *,
    host: str,
    port: int,
    user: str,
    password: str,
    database: str,
    start_date: str,
    end_date: str,
) -> List[Tuple[str, float, int]]:
    """返回 [(date, total_market_value_sum, stock_count), ...]，按 date 升序。"""
    conn = pymysql.connect(
        host=host,
        port=port,
        user=user,
        password=password,
        database=database,
        charset="utf8mb4",
        connect_timeout=10,
        read_timeout=600,
        write_timeout=30,
        autocommit=True,
    )
    try:
        with conn.cursor() as cur:
            # 会话只读；若服务器不支持则忽略
            try:
                cur.execute("SET SESSION TRANSACTION READ ONLY")
            except Exception as exc:  # noqa: BLE001 — 兼容旧 MySQL
                print(f"提示：无法设置 TRANSACTION READ ONLY（{exc}）", flush=True)

            sql = """
                SELECT
                    date,
                    SUM(total_market_value) AS total_market_value,
                    COUNT(*) AS stock_count
                FROM sys_data_stock_indicators
                WHERE date >= %s
                  AND date <= %s
                  AND total_market_value IS NOT NULL
                GROUP BY date
                ORDER BY date ASC
            """
            cur.execute(sql, (start_date, end_date))
            out: List[Tuple[str, float, int]] = []
            for date, total, count in cur.fetchall():
                out.append(
                    (
                        str(date).strip(),
                        float(total),
                        int(count),
                    )
                )
            return out
    finally:
        conn.close()


def _write_csv(path: Path, rows: Sequence[Tuple[str, float, int]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as fh:
        # 首行注释：单位与口径（多数 CSV 解析器可跳过以 # 开头的行；
        # 正式 contract loader 若需可再剥注释）
        fh.write("# 全市场日频总市值合计\n")
        fh.write("# total_market_value：万元（与 sys_data_stock_indicators 同单位）\n")
        fh.write("# stock_count：当日 total_market_value 非空的股票只数\n")
        fh.write("# 区间内按交易日聚合；源库只读查询\n")
        writer = csv.writer(fh)
        writer.writerow(["date", "total_market_value", "stock_count"])
        for date, total, count in rows:
            writer.writerow([date, f"{total:.6f}", count])


if __name__ == "__main__":
    sys.exit(main())
