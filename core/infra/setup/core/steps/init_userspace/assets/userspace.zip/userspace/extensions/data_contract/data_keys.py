"""用户自定义数据键值注册表。

使用说明：
- 用户需要在 USER_DATA_KEY 类中定义所有自定义的 data key（枚举常量形式）
- declaration.py 中的 meta.key 必须使用 USER_DATA_KEY.xxx
- 系统会在 discovery 时自动合并 SYS_DATA_KEY + USER_DATA_KEY -> DATA_KEY

示例：
    from core.modules.data_contract.contracts import DATA_KEY
    contract = ContractIssuer.issue(DATA_KEY.MARKET_TOTAL_MV)
"""


class USER_DATA_KEY:
    """用户自定义数据键值（枚举常量）。"""

    # 示例占位（可删）
    MY_CUSTOM_DATA = "my.custom.data"
    MY_FINANCE_DATA = "my.finance.data"

    # 全市场日频总市值合计（CSV / 演示用）
    MARKET_TOTAL_MV = "market.total_mv"


__all__ = ["USER_DATA_KEY"]
