# 全市场总市值（data contract）

演示：**在用户空间扩展一条 data contract**，数据来自同目录烘焙 CSV，不建库表。

| 项 | 值 |
|----|-----|
| data key | `market.total_mv`（`USER_DATA_KEY.MARKET_TOTAL_MV`） |
| 类型 | 全局时序 |
| 字段 | `date`、`total_market_value`（万元）、`stock_count` |
| 文件 | `market_total_mv_daily_2023_2025.csv` |

与「建用户表」对照见 [`../../tables/market_total_mv/`](../../tables/market_total_mv/)。  
序列关系示例：[`../../series_relation/market_mv_vs_rates/`](../../series_relation/market_mv_vs_rates/)（总市值 vs LPR / Shibor）。

重新烘焙 CSV（只读连 `ntq-full`）：

```bash
./venv/bin/python userspace/extensions/data_contract/_bake/bake_market_total_mv.py
```

跑序列关系：

```bash
python cli.py srel market_mv_vs_rates
```
