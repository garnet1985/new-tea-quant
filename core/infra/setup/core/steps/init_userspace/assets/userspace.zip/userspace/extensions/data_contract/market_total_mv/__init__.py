"""全市场日频总市值 data contract。"""
