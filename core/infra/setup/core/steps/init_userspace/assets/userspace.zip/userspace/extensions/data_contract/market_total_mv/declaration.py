"""全市场日频总市值：用户空间 data contract（读同目录 CSV）。"""

from __future__ import annotations

from typing import Any, Dict

from userspace.extensions.data_contract.data_keys import USER_DATA_KEY
from userspace.extensions.data_contract.market_total_mv.loader import MarketTotalMvLoader

MARKET_TOTAL_MV_DECLARATION: Dict[str, Any] = {
    "meta": {
        "key": USER_DATA_KEY.MARKET_TOTAL_MV,
        "type": "time_series",
        "scope": "global",
        "display_name": "全市场总市值",
        "description": (
            "全市场股票 total_market_value 按日合计。"
            "本契约从同目录 CSV 读取，演示用户空间扩展 data contract（不经数据库表）。"
        ),
        "unique_keys": ["date"],
        "loader": MarketTotalMvLoader,
    },
    "specific": {
        "time_axis_field": "date",
        # 与库内指标同单位：万元
        "value_unit": "万元",
    },
}

__all__ = ["MARKET_TOTAL_MV_DECLARATION"]
