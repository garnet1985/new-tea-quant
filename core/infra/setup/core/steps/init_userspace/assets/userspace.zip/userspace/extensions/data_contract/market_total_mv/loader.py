#!/usr/bin/env python3
"""从同目录 CSV 加载全市场日频总市值。"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, List, Mapping, Optional, Sequence

from core.modules.data_contract.contracts import BaseDataContractLoader

_CSV_NAME = "market_total_mv_daily_2023_2025.csv"
_CACHE: Optional[List[dict]] = None


class MarketTotalMvLoader(BaseDataContractLoader):
    """全局时序：读烘焙好的日频合计 CSV。"""

    def load(self, params: Mapping[str, Any], context: Optional[Mapping[str, Any]] = None) -> Any:
        _ = context
        rows = _load_csv_rows()
        start = str((params or {}).get("start") or (params or {}).get("start_time") or "").strip()
        end = str((params or {}).get("end") or (params or {}).get("end_time") or "").strip()
        if not start and not end:
            return list(rows)
        out: List[dict] = []
        for row in rows:
            day = str(row.get("date") or "").strip()
            if start and day < start:
                continue
            if end and day > end:
                continue
            out.append(row)
        return out

    def load_batch(
        self,
        entity_ids: Sequence[str],
        params: Mapping[str, Any],
        context: Optional[Mapping[str, Any]] = None,
    ) -> Mapping[str, Any]:
        data = self.load(params, context)
        return {str(eid).strip(): data for eid in entity_ids if str(eid).strip()}


def _csv_path() -> Path:
    return Path(__file__).resolve().parent / _CSV_NAME


def _load_csv_rows() -> List[dict]:
    global _CACHE
    if _CACHE is not None:
        return _CACHE

    path = _csv_path()
    if not path.is_file():
        raise FileNotFoundError(f"缺少全市场总市值 CSV: {path}")

    rows: List[dict] = []
    with path.open("r", encoding="utf-8", newline="") as fh:
        # 跳过 # 注释行
        filtered = (line for line in fh if line.strip() and not line.lstrip().startswith("#"))
        reader = csv.DictReader(filtered)
        for raw in reader:
            day = str(raw.get("date") or "").strip()
            if not day:
                continue
            try:
                total = float(raw.get("total_market_value"))
            except (TypeError, ValueError):
                continue
            stock_count_raw = raw.get("stock_count")
            try:
                stock_count = int(float(stock_count_raw)) if stock_count_raw not in (None, "") else None
            except (TypeError, ValueError):
                stock_count = None
            row = {
                "date": day,
                "total_market_value": total,
            }
            if stock_count is not None:
                row["stock_count"] = stock_count
            rows.append(row)

    rows.sort(key=lambda item: str(item.get("date") or ""))
    _CACHE = rows
    return rows


__all__ = ["MarketTotalMvLoader"]
