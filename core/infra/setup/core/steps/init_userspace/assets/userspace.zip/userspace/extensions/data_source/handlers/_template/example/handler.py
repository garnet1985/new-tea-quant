# 空白数据源钩子。复制后改类名，再把需要的方法从注释里拿出来。
# 引擎负责规划日期、发请求、打进度和写库。这里只改其中某一步。
# self.context 就是这次运行的上下文，也可以写 context 参数。
# 常用的 context：
#   config          DataSourceConfig，表名、renew、接口都在这里
#   providers       按 provider_name 取出的数据源实例
#   data_manager    本地表
#   dependencies    mapping 里 depends_on 注入的结果
#   schema          绑定表的 schema
#   is_dry_run      True 时不要写库
#   force_refresh   renew -f 时为 True
#   latest_completed_trading_date
# self.ds 是引擎。钩子里要建任务、读实体列表时用它，例如 self.ds._build_job。
# self.ds.progress 是这次 renew 的进度，一般不用自己打印。

from core.modules.data_source.contracts import DataSourceHooks


class ExampleHooks(DataSourceHooks):
    """复制后改名。下面的方法默认都不启用。"""


# def on_before_run(self, context):
#     """抓取前。返回字典就结束，不再规划、不再请求。返回 None 继续。"""
#     if context.get("force_refresh"):
#         return None
#     return None
#
# def on_prepare_context(self, context):
#     """补上下文。默认会填 latest_completed_trading_date。要保留默认行为就先 super()。"""
#     context = super().on_prepare_context(context)
#     return context
#
# def on_build_job_payload(self, entity_info, apis, context):
#     """每个实体建任务时改参数。返回值是日志里的实体 id。没有实体时返回 None。"""
#     entity_id = super().on_build_job_payload(entity_info, apis, context)
#     for api in apis:
#         api.params["symbol"] = entity_id
#     return entity_id
#
# def on_after_build_jobs(self, context, jobs, entity_date_ranges):
#     """任务列表已经生成。可以删掉、合并，再返回新的列表。"""
#     return jobs
#
# def on_before_fetch(self, context, jobs):
#     """发出请求前最后一次改任务。"""
#     return jobs
#
# def enrich_result_for_batch(self, context, job_bundle, raw_result):
#     """这一包的原始返回还没映射。可以给 DataFrame 补上 id、term 再交回去。"""
#     return raw_result
#
# def on_after_fetch(self, context, fetched_data, apis):
#     """全部请求结束后的汇总。默认按有没有分组收成统一结构。一般先 super()。"""
#     return super().on_after_fetch(context, fetched_data, apis)
#
# def bundle_to_frames(self, context, job_bundle, fetched_data):
#     """把一包结果变成要写入的表。默认走字段映射。返回 DataFrame 列表。"""
#     return super().bundle_to_frames(context, job_bundle, fetched_data)
#
# def on_after_mapping(self, context, mapped_records):
#     """字段已经映射成表的列。在这里丢行、补列。"""
#     return mapped_records
#
# def on_after_normalize(self, context, normalized_data):
#     """日期和空值处理之后。normalized_data 形如 {"data": [行, ...]}。"""
#     return super().on_after_normalize(context, normalized_data)
#
# def on_before_save(self, context, normalized_data):
#     """写入前。返回 None 就写传入的数据；返回 {"data": [...]} 就改写内容。"""
#     return None
#
# def save_frames(self, context, frames):
#     """按块把表写入。默认分块后调用 save_record_chunk。"""
#     super().save_frames(context, frames)
#
# def save_record_chunk(self, context, rows):
#     """真正写一批行。dry run 时默认跳过。"""
#     super().save_record_chunk(context, rows)
#
# def on_bundle_execution_error(self, error, context, apis):
#     """一包请求失败。默认只记录，不中断其他包。"""
#     return None
#
# 行工具，都是静态方法，不改默认流程：
#   self.clean_nan_in_records(rows, default=None)
#   self.clean_nan_in_normalized_data({"data": rows}, default=0.0)
#   self.filter_records_by_required_fields(rows, ["id", "date"])
#   self.ensure_float_field(rows, "close", default=0.0)
