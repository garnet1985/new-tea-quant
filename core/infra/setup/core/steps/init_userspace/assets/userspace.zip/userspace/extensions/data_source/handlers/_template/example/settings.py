# 空白数据源模板。复制整个 example/ 到 handlers/<你的名字>/ 后：
# 1. 改目录名，并在 mapping.py 里用同一名字登记
# 2. 把下面 settings = {...} 的注释去掉，删掉用不到的键
# 3. 在 handler.py 里按需要取消钩子注释
# 本目录不在 mapping.py 里，renew 不会加载它。
# 不认识的键会被丢掉。save_mode、save_batch_size 现在不起作用。

# from core.infra.utils import Utils
#
# def _constant(_row):
#     """result_mapping 的值可以是函数，入参是原始行，返回写入表的值。"""
#     return "SW2021"
#
# settings = {
#     # 必填。要写入的表，对应表 schema 的 name。
#     "table": "sys_data_xxx",
#
#     # 可选。写入前丢掉这些字段。默认 []。
#     "ignore_fields": ["last_update"],
#
#     # 可选。True 时只抓取、不写库。默认 False。
#     "is_dry_run": False,
#
#     # 可选。True 才按实体拆日期；不配 job_execution 时保持 False。
#     "needs_stock_grouping": False,
#
#     # 可选。多个接口合并时的键。renew.data_merging.merge_by_key 优先。
#     "merge_by_key": "id",
#
#     # 可选。没有本地水位时，起点往前推几年。只认 years，小于等于 0 时按 1 年。
#     "default_date_range": {"years": 3},
#
#     # 必填。
#     "renew": {
#         # 必填。incremental 增量，rolling 滚动窗口，refresh 从默认起点重拉。
#         "type": "incremental",
#
#         # incremental、rolling 必填。refresh 只有配了 renew_if_over_days 时才需要。
#         "last_update_info": {
#             "date_field": "date",  # 表里的日期列
#             # day / month / quarter，或 Utils.date.PERIOD_DAY 等
#             "date_format": "day",
#         },
#
#         # 仅 type=rolling 时必填。length 必须大于 0。
#         "rolling": {
#             "unit": "month",
#             "length": 12,
#         },
#
#         # 可选。距上次更新不足 value 天就跳过。
#         "renew_if_over_days": {
#             "value": 30,
#             # "counting_field": "last_update",  # 不写就用 date_field
#         },
#
#         # 可选。写了就按实体拆任务。不写就是整表一次。
#         # key 和 keys 只能留一个。用 keys 时 terms 必填。
#         "job_execution": {
#             "list": "stock_list",  # 依赖里的实体列表
#             "key": "id",
#             # "keys": ["id", "term"],
#             # "terms": ["daily", "weekly"],
#             # "merge": {"by": "id"},
#         },
#
#         # 可选。交给标准化阶段的合并说明。
#         "data_merging": {
#             # "merge_by_key": "id",
#         },
#
#         # 可选。框架不解释，钩子里用 context["config"].get_renew_extra() 读。
#         "extra": {
#             # "skip_if_within_days": 7,
#         },
#     },
#
#     # 必填，且不能是空字典。一个数据源可以有多个接口。
#     "apis": {
#         "api_name": {
#             "provider_name": "tushare",  # providers 目录里的 provider_name
#             "method": "get_xxx",         # 该 provider 上的方法
#
#             # 可选。参数名 <- 实体字段名。per-entity 时把股票代码塞进接口参数。
#             "params_mapping": {
#                 "ts_code": "id",
#             },
#
#             # 可选。表字段 <- 接口字段。值也可以是函数，见上面的 _constant。
#             "result_mapping": {
#                 "id": "ts_code",
#                 "date": "trade_date",
#                 # "src": _constant,
#             },
#
#             # 可选。每个任务都带上的固定参数。
#             "params": {
#                 # "fields": "ts_code,trade_date,close",
#             },
#         },
#     },
# }
