"""复权因子事件。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class AdjFactorEventHooks(DataSourceHooks):
    """绑定表 sys_data_adj_factor_events。"""
