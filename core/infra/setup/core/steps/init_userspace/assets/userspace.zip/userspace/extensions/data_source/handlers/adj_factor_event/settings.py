"""从官网续传 sys_data_adj_factor_events。更新方式与原来的 adj_factor_event 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_adj_factor_events',
    "needs_stock_grouping": True,
    "renew": {
        'type': 'incremental',
        'last_update_info': {
            'date_field': 'last_update',
            'date_format': Utils.date.PERIOD_DAY,
        },
        'job_execution': {
            'list': 'stock_list',
            'key': 'id',
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
            "params_mapping": {"id": "id"},
        },
    },
}
