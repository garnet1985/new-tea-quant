"""从官网续传 sys_data_corporate_finance。更新方式与原来的 corporate_finance 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_corporate_finance',
    "needs_stock_grouping": True,
    "renew": {
        'type': 'rolling',
        'rolling': {
            'unit': Utils.date.PERIOD_QUARTER,
            'length': 3,
        },
        'last_update_info': {
            'date_field': Utils.date.PERIOD_QUARTER,
            'date_format': Utils.date.PERIOD_QUARTER,
        },
        'job_execution': {
            'list': 'stock_list',
            'key': 'id',
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
            "params_mapping": {"id": "id"},
        },
    },
}
