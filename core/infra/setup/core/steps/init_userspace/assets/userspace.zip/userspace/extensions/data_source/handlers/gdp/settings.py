"""从官网续传 sys_data_gdp。更新方式与原来的 gdp 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_gdp',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'rolling',
        'last_update_info': {
            'date_field': Utils.date.PERIOD_QUARTER,
            'date_format': Utils.date.PERIOD_QUARTER,
        },
        'rolling': {
            'unit': Utils.date.PERIOD_QUARTER,
            'length': 4,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
