"""从官网续传 sys_data_index_klines。更新方式与原来的 index_klines 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_index_klines',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'incremental',
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_DAY,
        },
        'renew_if_over_days': {
            'value': 1,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
