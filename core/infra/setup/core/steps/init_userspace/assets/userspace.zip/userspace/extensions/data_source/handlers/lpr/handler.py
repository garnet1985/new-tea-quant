"""宏观 LPR。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class LprHooks(DataSourceHooks):
    """绑定表 sys_data_lpr。"""
