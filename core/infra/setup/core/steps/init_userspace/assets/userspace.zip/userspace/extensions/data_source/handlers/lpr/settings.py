"""从官网续传 sys_data_lpr。更新方式与原来的 lpr 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_lpr',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'rolling',
        'rolling': {
            'length': 30,
            'unit': Utils.date.PERIOD_DAY,
        },
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_DAY,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
