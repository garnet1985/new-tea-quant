"""从官网续传 sys_data_markets。更新方式与 sw_industry 相同，接口换成 ntq。"""

settings = {
    "table": "sys_data_markets",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
