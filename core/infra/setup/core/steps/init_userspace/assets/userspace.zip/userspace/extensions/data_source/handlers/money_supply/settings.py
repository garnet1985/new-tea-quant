"""从官网续传 sys_data_money_supply。更新方式与原来的 money_supply 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_money_supply',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'rolling',
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_MONTH,
        },
        'rolling': {
            'unit': Utils.date.PERIOD_MONTH,
            'length': 12,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
