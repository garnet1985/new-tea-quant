"""指数日线：接口没有 id 和周期，映射之后补上，并丢掉没有收盘价的行。"""

from typing import Any, Dict, List

from core.modules.data_source.contracts import DataSourceHooks

_INDEX_ID = "000001.SH"
_TERM = "daily"


class AkshareIndexKlineHooks(DataSourceHooks):
    """绑定表 sys_data_index_klines。"""

    def on_after_mapping(
        self, context: Dict[str, Any], mapped_records: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """result_mapping 只搬了行情列。主键还差 id 和 term。"""
        _ = context
        rows = self.ensure_float_field(list(mapped_records), "close")
        kept = []
        for row in rows:
            if not row.get("date") or row.get("close") is None:
                continue
            row["id"] = _INDEX_ID
            row["term"] = _TERM
            kept.append(row)
        return kept
