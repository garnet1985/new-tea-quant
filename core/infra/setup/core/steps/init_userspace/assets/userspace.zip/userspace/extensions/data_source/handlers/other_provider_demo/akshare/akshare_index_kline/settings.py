"""上证指数日线。AKShare 返回的是腾讯行情表，钩子里补上 id 和周期。默认不启用。"""

from core.infra.utils import Utils

settings = {
    "table": "sys_data_index_klines",
    "needs_stock_grouping": False,
    "renew": {
        "type": "incremental",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
    },
    "apis": {
        "qfq": {
            "provider_name": "akshare",
            "method": "get_qfq_kline",
            "params": {
                "symbol": "sh000001",
                "adjust": "",
            },
            "result_mapping": {
                "date": "date",
                "open": "open",
                "high": "high",
                "low": "low",
                "close": "close",
                "amount": "amount",
            },
        },
    },
}
