"""个股前复权：建任务时改代码，返回后再把 id 和周期写回每一行。"""

from typing import Any, Dict, List

from core.modules.data_source.contracts import DataSourceHooks


def _to_tx_symbol(ts_code: str) -> str:
    """腾讯接口要 sz000001，股票列表里是 000001.SZ。"""
    text = str(ts_code or "").strip()
    if "." not in text:
        return text.lower()
    code, market = text.split(".", 1)
    return f"{market.lower()}{code}"


def _to_ts_code(tx_symbol: str) -> str:
    text = str(tx_symbol or "").strip().lower()
    if len(text) < 8:
        return text
    market, code = text[:2], text[2:]
    return f"{code}.{market.upper()}"


class AkshareStockKlineHooks(DataSourceHooks):
    """绑定表 sys_data_stock_klines。依赖 stock_list。"""

    def on_build_job_payload(self, entity_info: Any, apis: List[Any], context: Dict[str, Any]):
        """params_mapping 放进来的是 000001.SZ。这里改成腾讯代码 sz000001，返回时再写回 id。"""
        entity_id = super().on_build_job_payload(entity_info, apis, context)
        if not entity_id:
            return None
        for api in apis:
            api.params["symbol"] = _to_tx_symbol(entity_id)
        return entity_id

    def enrich_result_for_batch(
        self, context: Dict[str, Any], job_bundle: Any, raw_result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """行情表没有 id 和 term。映射之前补上，result_mapping 才能写进主键。"""
        _ = context
        symbol = ""
        for api in getattr(job_bundle, "apis", None) or []:
            symbol = str((getattr(api, "params", None) or {}).get("symbol") or "")
            if symbol:
                break
        frame = raw_result.get("qfq") if isinstance(raw_result, dict) else None
        if frame is None or not hasattr(frame, "copy"):
            return raw_result
        stamped = frame.copy()
        stamped["id"] = _to_ts_code(symbol)
        stamped["term"] = "daily"
        rewritten = dict(raw_result)
        rewritten["qfq"] = stamped
        return rewritten

    def on_bundle_execution_error(self, error: Exception, context: Dict[str, Any], apis: List[Any]) -> None:
        """整次抓取抛错时才会进来。单只失败由流水线记下，不会进这个钩子。"""
        _ = (context, apis)
        print(f"[akshare_stock_kline] 抓取中断: {error}", flush=True)
