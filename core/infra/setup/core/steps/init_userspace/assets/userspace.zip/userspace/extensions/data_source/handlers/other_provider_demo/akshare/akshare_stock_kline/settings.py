"""按股票拉前复权日线。代码格式在钩子里从 000001.SZ 改成 sz000001。默认不启用。"""

from core.infra.utils import Utils

settings = {
    "table": "sys_data_stock_klines",
    "needs_stock_grouping": True,
    "renew": {
        "type": "incremental",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
        "job_execution": {
            "list": "stock_list",
            "key": "id",
        },
    },
    "apis": {
        "qfq": {
            "provider_name": "akshare",
            "method": "get_qfq_kline",
            "params": {"adjust": "qfq"},
            "params_mapping": {
                "symbol": "id",
            },
            "result_mapping": {
                "id": "id",
                "term": "term",
                "date": "date",
                "open": "open",
                "high": "high",
                "low": "low",
                "close": "close",
                "amount": "amount",
            },
        },
    },
}
