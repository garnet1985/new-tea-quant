"""股票列表：缓存命中就不再请求；映射后的维度留在上下文里，写入前打上日期。"""

from typing import Any, Dict, List, Optional

from core.infra.utils import Utils
from core.modules.data_source.contracts import DataSourceHooks

_CACHE_KEY = "tushare_stock_list_demo_checked_at"


class TushareStockListHooks(DataSourceHooks):
    """绑定表 sys_data_stock_list。"""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """今天已经更新过就返回已有列表，后面的抓取全部跳过。"""
        if context.get("force_refresh"):
            return None
        manager = context.get("data_manager")
        if manager is None:
            return None
        try:
            cache = manager.db_cache.load(_CACHE_KEY, field="json") or {}
        except Exception:
            return None
        if not Utils.date.is_today(str(cache.get("checked_at") or "")):
            return None
        rows = manager.stock.list.load_all() or []
        print(f"[tushare_stock_list] 今日已更新，跳过，本地 {len(rows)} 只", flush=True)
        return {"data": rows}

    def on_after_mapping(
        self, context: Dict[str, Any], mapped_records: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """板块、市场、地域不是这张表的列，套用 schema 时会被丢掉。先留一份。"""
        context["_stock_list_raw"] = [dict(row) for row in mapped_records]
        return mapped_records

    def on_before_save(
        self, context: Dict[str, Any], normalized_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """没有代码的行丢掉，并给留下的行写上今天。"""
        rows = [
            row for row in (normalized_data or {}).get("data") or []
            if row.get("id")
        ]
        today = Utils.date.today()
        for row in rows:
            row["last_update"] = today
        raw_rows = context.get("_stock_list_raw") or []
        areas = {str(row.get("area") or "").strip() for row in raw_rows}
        areas.discard("")
        print(f"[tushare_stock_list] 本次 {len(rows)} 只，地域 {len(areas)} 个", flush=True)
        if context.get("is_dry_run"):
            return {"data": rows}
        manager = context.get("data_manager")
        if manager is not None:
            try:
                manager.db_cache.save(_CACHE_KEY, json={"checked_at": today})
            except Exception:
                pass
        return {"data": rows}
