"""股票列表。全量刷新。维度字段只在钩子里看，不写入这张表。默认不启用。"""

settings = {
    "table": "sys_data_stock_list",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
    },
    "apis": {
        "stock_list": {
            "provider_name": "tushare",
            "method": "get_stock_list_full",
            "params": {
                "fields": (
                    "ts_code,name,area,market,exchange,"
                    "list_status,list_date,delist_date"
                ),
            },
            "result_mapping": {
                "id": "ts_code",
                "name": "name",
                "list_status": "list_status",
                "list_date": "list_date",
                "delist_date": "delist_date",
                "board": "market",
                "market": "exchange",
                "area": "area",
            },
        },
    },
}
