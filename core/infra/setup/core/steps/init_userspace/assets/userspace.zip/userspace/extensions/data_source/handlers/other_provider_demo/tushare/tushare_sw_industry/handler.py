"""申万行业：on_before_run 决定要不要抓，on_before_save 丢掉空行。"""

from typing import Any, Dict, List, Optional

from core.infra.utils import Utils
from core.modules.data_source.contracts import DataSourceHooks

_CACHE_KEY = "tushare_sw_industry_demo_synced_at"


class TushareSwIndustryHooks(DataSourceHooks):
    """绑定表 sys_data_sw_industry。"""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """距上次同步不够天数就直接结束，不再请求。renew -f 时 force_refresh 为真。"""
        if context.get("force_refresh"):
            return None
        extra = context["config"].get_renew_extra()
        within = int(extra.get("skip_if_within_days") or 0)
        last = _last_sync_day(context)
        if not last or within <= 0:
            return None
        try:
            days = Utils.date.diff_days(last, Utils.date.today())
        except Exception:
            return None
        if days < within:
            print(f"[tushare_sw_industry] 距上次同步 {days} 天，跳过", flush=True)
            return {"data": []}
        return None

    def on_before_save(
        self, context: Dict[str, Any], normalized_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """NaN 清掉，没有 id 或 level 的行不写。返回的字典会代替原数据写入。"""
        rows = self.clean_nan_in_records((normalized_data or {}).get("data") or [])
        rows = [row for row in rows if row.get("id") and row.get("level")]
        _mark_synced(context)
        return {"data": rows}


def _last_sync_day(context: Dict[str, Any]) -> str:
    manager = context.get("data_manager")
    if not manager:
        return ""
    try:
        cache = manager.db_cache.load(_CACHE_KEY, field="json") or {}
    except Exception:
        return ""
    return str(cache.get("synced_at") or "").strip()


def _mark_synced(context: Dict[str, Any]) -> None:
    manager = context.get("data_manager")
    if not manager or context.get("is_dry_run"):
        return
    try:
        manager.db_cache.save(_CACHE_KEY, json={"synced_at": Utils.date.today()})
    except Exception:
        return
