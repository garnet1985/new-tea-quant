"""申万行业分类。整表刷新，映射时把代码收成文本。默认不启用。"""


def _code(row, field):
    """接口里的行业代码有时是整数。写成文本，避免变成 110000.0。"""
    value = row.get(field)
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


settings = {
    "table": "sys_data_sw_industry",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
        "extra": {
            "skip_if_within_days": 7,
        },
    },
    "apis": {
        "sw_industry": {
            "provider_name": "tushare",
            "method": "get_sw_industry_classify",
            "params": {"src": "SW2021"},
            "result_mapping": {
                "id": "index_code",
                "industry_code": lambda row: _code(row, "industry_code"),
                "name": "industry_name",
                "level": "level",
                "parent_code": lambda row: _code(row, "parent_code"),
                "is_pub": lambda row: int(row.get("is_pub") or 0),
                "src": lambda _row: "SW2021",
            },
        },
    },
}
