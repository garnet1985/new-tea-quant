"""从官网续传 sys_data_shibor。更新方式与原来的 shibor 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_shibor',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'rolling',
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_DAY,
        },
        'rolling': {
            'unit': Utils.date.PERIOD_DAY,
            'length': 30,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
