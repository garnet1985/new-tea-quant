"""股票-地域映射。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class StockAreaHooks(DataSourceHooks):
    """绑定表 sys_map_stock_area。"""
