"""从官网续传 sys_map_stock_board。更新方式与 sw_stock_industry 相同，接口换成 ntq。"""

settings = {
    "table": "sys_map_stock_board",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
