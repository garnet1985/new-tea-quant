"""从官网续传 sys_data_stock_indicators。更新方式与原来的 stock_indicators 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_stock_indicators',
    "needs_stock_grouping": True,
    "renew": {
        'type': 'rolling',
        'rolling': {
            'unit': Utils.date.PERIOD_DAY,
            'length': 7,
        },
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_DAY,
        },
        'job_execution': {
            'list': 'stock_list',
            'key': 'id',
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
            "params_mapping": {"id": "id"},
        },
    },
}
