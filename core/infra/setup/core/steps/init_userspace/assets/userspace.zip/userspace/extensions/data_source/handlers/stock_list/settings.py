"""从官网续传 sys_data_stock_list。更新方式与原来的 stock_list 相同，接口换成 ntq。"""

settings = {
    "table": 'sys_data_stock_list',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'refresh',
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
