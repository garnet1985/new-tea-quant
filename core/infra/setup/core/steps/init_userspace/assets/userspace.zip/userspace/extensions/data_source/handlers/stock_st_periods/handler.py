"""股票 ST 时段。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class StockStPeriodsHooks(DataSourceHooks):
    """绑定表 sys_data_stock_st_periods。"""
