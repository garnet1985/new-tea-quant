"""从官网续传 sys_data_sw_industry。更新方式与原来的 sw_industry 相同，接口换成 ntq。"""

settings = {
    "table": 'sys_data_sw_industry',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'refresh',
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
