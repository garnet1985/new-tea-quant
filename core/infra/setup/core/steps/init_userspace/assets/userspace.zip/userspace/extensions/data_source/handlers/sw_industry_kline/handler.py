"""申万一级行业日线。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class SwIndustryKlineHooks(DataSourceHooks):
    """绑定表 sys_data_sw_industry_kline。"""
