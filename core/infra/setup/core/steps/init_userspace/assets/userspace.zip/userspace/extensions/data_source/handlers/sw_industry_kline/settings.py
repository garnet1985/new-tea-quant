"""从官网续传 sys_data_sw_industry_kline。更新方式与原来的 sw_industry_kline 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_sw_industry_kline',
    "needs_stock_grouping": True,
    "renew": {
        'type': 'incremental',
        'last_update_info': {
            'date_field': 'date',
            'date_format': Utils.date.PERIOD_DAY,
        },
        'job_execution': {
            'list': 'sw_industry',
            'key': 'id',
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
            "params_mapping": {"id": "id"},
        },
    },
}
