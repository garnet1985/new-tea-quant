"""申万行业成分。从官网续传，更新方式在 settings.py。"""

from core.modules.data_source.contracts import DataSourceHooks


class SwStockIndustryHooks(DataSourceHooks):
    """绑定表 sys_map_sw_stock_industry。"""
