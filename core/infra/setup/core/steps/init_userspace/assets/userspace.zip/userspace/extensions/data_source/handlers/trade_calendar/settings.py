"""从官网续传 sys_data_trade_calendar。更新方式与原来的 trade_calendar 相同，接口换成 ntq。"""

from core.infra.utils import Utils

settings = {
    "table": 'sys_data_trade_calendar',
    "needs_stock_grouping": False,
    "renew": {
        'type': 'refresh',
        'date_format': Utils.date.PERIOD_DAY,
        'renew_if_over_days': {
            'value': 30,
        },
    },
    "apis": {
        "sync": {
            "provider_name": "ntq",
            "method": "sync",
        },
    },
}
