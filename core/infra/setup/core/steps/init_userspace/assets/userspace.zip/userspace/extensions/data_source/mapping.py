"""
数据源 mapping 配置。定义各 data source 的 handler、启用状态与依赖。

约定：
- handler 必须为「模块.类名」格式（如 kline.KlineHandler），框架从 handlers/<模块>/handler.py 加载该类。
- depends_on: 依赖列表，可为「其他 data source key」或「保留依赖关键字」。保留关键字（如 latest_completed_trading_date）由框架直接解析注入，不作为 data source 配置。
- data source key 不能使用保留关键字（见 core.modules.data_source.core.reserved_dependencies.RESERVED_DEPENDENCY_KEYS）。

发给用户的这一份按原来的表和更新方式从官网续传。接口是 ntq，不再按股票拆任务。
weight 越大越先执行。没写 weight 的源排在写了的后面。被依赖的源不能比依赖它的源更晚，否则启动时直接停止。
other_provider_demo 是接入 Tushare、AKShare 的例子，默认关闭。
handlers/_template/example 只作对照，不在这里登记。
中转站抓外部数据的 handler 在网站模块 ntq_data 的 crawl_handlers.zip。
"""
DATA_SOURCES = {
    "stock_list": {
        "handler": "stock_list.StockListHooks",
        "is_enabled": True,
        "weight": 100,
    },
    "boards": {
        "handler": "boards.BoardsHooks",
        "is_enabled": True,
        "weight": 89,
    },
    "markets": {
        "handler": "markets.MarketsHooks",
        "is_enabled": True,
        "weight": 88,
    },
    "areas": {
        "handler": "areas.AreasHooks",
        "is_enabled": True,
        "weight": 87,
    },
    "stock_board": {
        "handler": "stock_board.StockBoardHooks",
        "is_enabled": True,
        "weight": 86,
    },
    "stock_market": {
        "handler": "stock_market.StockMarketHooks",
        "is_enabled": True,
        "weight": 85,
    },
    "stock_area": {
        "handler": "stock_area.StockAreaHooks",
        "is_enabled": True,
        "weight": 84,
    },
    "stock_klines": {
        "handler": "stock_klines.StockKlinesHooks",
        "is_enabled": True,
        "weight": 95,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "stock_indicators": {
        "handler": "stock_indicators.StockIndicatorsHooks",
        "is_enabled": True,
        "weight": 94,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "stock_moneyflow": {
        "handler": "stock_moneyflow.StockMoneyflowHooks",
        "is_enabled": True,
        "weight": 93,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "corporate_finance": {
        "handler": "corporate_finance.CorporateFinanceHooks",
        "is_enabled": True,
        "weight": 92,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "stock_st_periods": {
        "handler": "stock_st_periods.StockStPeriodsHooks",
        "is_enabled": True,
        "weight": 91,
        "depends_on": ["stock_list"],
    },
    "adj_factor_event": {
        "handler": "adj_factor_event.AdjFactorEventHooks",
        "is_enabled": True,
        "weight": 90,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "sw_industry": {
        "handler": "sw_industry.SwIndustryHooks",
        "is_enabled": True,
        "weight": 80,
    },
    "sw_stock_industry": {
        "handler": "sw_stock_industry.SwStockIndustryHooks",
        "is_enabled": True,
        "weight": 75,
        "depends_on": ["sw_industry"],
    },
    "sw_industry_kline": {
        "handler": "sw_industry_kline.SwIndustryKlineHooks",
        "is_enabled": True,
        "weight": 70,
        "depends_on": ["sw_industry", "latest_completed_trading_date"],
    },
    "trade_calendar": {
        "handler": "trade_calendar.TradeCalendarHooks",
        "is_enabled": True,
        "weight": 60,
        "depends_on": ["latest_completed_trading_date"],
    },
    "index_klines": {
        "handler": "index_klines.IndexKlinesHooks",
        "is_enabled": True,
        "weight": 50,
        "depends_on": ["latest_completed_trading_date"],
    },
    "index_weight": {
        "handler": "index_weight.IndexWeightHooks",
        "is_enabled": True,
        "weight": 40,
        "depends_on": ["latest_completed_trading_date"],
    },
    "gdp": {
        "handler": "gdp.GdpHooks",
        "is_enabled": True,
        "weight": 30,
        "depends_on": ["latest_completed_trading_date"],
    },
    "cpi": {
        "handler": "cpi.CpiHooks",
        "is_enabled": True,
        "weight": 28,
        "depends_on": ["latest_completed_trading_date"],
    },
    "ppi": {
        "handler": "ppi.PpiHooks",
        "is_enabled": True,
        "weight": 26,
        "depends_on": ["latest_completed_trading_date"],
    },
    "pmi": {
        "handler": "pmi.PmiHooks",
        "is_enabled": True,
        "weight": 24,
        "depends_on": ["latest_completed_trading_date"],
    },
    "money_supply": {
        "handler": "money_supply.MoneySupplyHooks",
        "is_enabled": True,
        "weight": 22,
        "depends_on": ["latest_completed_trading_date"],
    },
    "shibor": {
        "handler": "shibor.ShiborHooks",
        "is_enabled": True,
        "weight": 20,
        "depends_on": ["latest_completed_trading_date"],
    },
    "lpr": {
        "handler": "lpr.LprHooks",
        "is_enabled": True,
        "weight": 18,
        "depends_on": ["latest_completed_trading_date"],
    },
    "tushare_sw_industry": {
        "handler": "other_provider_demo.tushare.tushare_sw_industry.TushareSwIndustryHooks",
        "is_enabled": False,
    },
    "tushare_stock_list": {
        "handler": "other_provider_demo.tushare.tushare_stock_list.TushareStockListHooks",
        "is_enabled": False,
    },
    "akshare_index_kline": {
        "handler": "other_provider_demo.akshare.akshare_index_kline.AkshareIndexKlineHooks",
        "is_enabled": False,
        "depends_on": ["latest_completed_trading_date"],
    },
    "akshare_stock_kline": {
        "handler": "other_provider_demo.akshare.akshare_stock_kline.AkshareStockKlineHooks",
        "is_enabled": False,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
}
