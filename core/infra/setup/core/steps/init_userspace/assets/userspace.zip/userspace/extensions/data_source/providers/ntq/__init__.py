"""NTQ 官网行情 Provider。"""

from .provider import NtqProvider

__all__ = ["NtqProvider"]
