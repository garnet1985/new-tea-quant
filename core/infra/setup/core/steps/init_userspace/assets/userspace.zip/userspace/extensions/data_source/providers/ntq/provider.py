"""
NTQ 官网行情同步。

小表一次请求是一页。大表先问要不要数据包，否则一次请求是一只股票的整段。
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

from core.infra.membership import Membership
from core.infra.utils.core.net.ssl_context import urlopen_https
from core.modules.data_source.contracts import BaseProvider
from core.modules.ntq_external.conf.site_target import base_url as site_base_url
from core.modules.data_source.core.data_class.error import ProviderError

logger = logging.getLogger(__name__)


class NtqProvider(BaseProvider):
    """从官网读接口拉取已经整理好的行情行。"""

    provider_name = "ntq"
    requires_auth = False
    auth_type = None
    api_limits = {"sync": 30}
    default_rate_limit = 30

    def _initialize(self) -> None:
        # 优先显式配置 / 环境变量；否则跟 membership.json 的官网 base_url
        configured = self.config.get("base_url") or os.getenv("NTQ_DATA_URL") or site_base_url()
        self.base_url = str(configured).rstrip("/")

    def plan_entities(self, table: str, stocks: list, pack: str) -> Dict[str, Any]:
        """把这张表每个代码缺的区间一次交给远端，拿回要下的文件和还要单股补的区间。"""
        name = str(table or "").strip()
        if not name:
            raise ProviderError(self.provider_name, "sync", ValueError("表名不能为空"))
        payload = json.dumps({"pack": pack, "stocks": stocks}, ensure_ascii=False).encode("utf-8")
        body = self._while_busy(name, lambda: self._post_plan(name, payload))
        files = body.get("files") if isinstance(body, dict) else None
        left = body.get("stocks") if isinstance(body, dict) else None
        if not isinstance(files, list) or not isinstance(left, list):
            raise RuntimeError("官网没有返回更新计划")
        return {"files": files, "stocks": left}

    def download(self, path: str) -> bytes:
        url = path if path.startswith("http") else f"{self.base_url}{path}"
        request = urllib.request.Request(
            url,
            headers={"Authorization": f"Bearer {self._token()}", "Accept": "text/csv"},
            method="GET",
        )
        with urlopen_https(request, timeout=120) as response:
            if response.status != 200:
                raise RuntimeError(f"数据包下载失败 HTTP {response.status}")
            return response.read()

    def sync(
        self,
        table: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        entity_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        请求一页。

        Returns:
            {"table", "rows", "next_start", "total"}。
            next_start 为空表示这一段已经结束。total 只在第一页返回，是这个区间的行数。
        """
        name = str(table or "").strip()
        if not name:
            raise ProviderError(self.provider_name, "sync", ValueError("表名不能为空"))
        return self._while_busy(name, lambda: self._sync_once(name, start, end, entity_id))

    def _while_busy(self, name: str, fetch):
        """排队等到一把锁空出来。等待时间和服务器占锁的时间一样。"""
        deadline = time.monotonic() + _SLOT_HOLD_SECONDS
        last_error: Optional[Exception] = None
        while True:
            try:
                return fetch()
            except _Busy as exc:
                last_error = exc
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                pause = min(exc.retry_after, remaining)
                print(
                    f"[ntq] 官网行情读取正忙，{pause:.0f} 秒后重试 {name}",
                    flush=True,
                )
                logger.info("官网行情读取正忙，%.0f 秒后重试 %s", pause, name)
                time.sleep(pause)
            except Exception as exc:
                raise self.handle_error(exc, "sync") from exc
        raise self.handle_error(last_error or RuntimeError("官网行情读取正忙"), "sync")

    def _token(self) -> str:
        token = self.config.get("token") or os.getenv("NTQ_TOKEN") or Membership.read()
        if not token:
            raise ValueError("还没有官网通用凭证。请在设置页保存会员中心的凭证。")
        return str(token).strip()

    def _sync_once(
        self,
        table: str,
        start: Optional[str],
        end: Optional[str],
        entity_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body = self._request_once(table, start, end, entity_id, None)
        if entity_id and str(body.get("id") or "") != str(entity_id):
            raise RuntimeError("官网没有按股票返回，已停止写入")
        rows = body.get("rows") if isinstance(body, dict) else None
        if not isinstance(rows, list):
            raise RuntimeError("官网返回的行情页没有 rows")
        next_start = body.get("next_start") if isinstance(body, dict) else None
        if next_start is not None:
            next_start = str(next_start)
        page = {
            "table": str(body.get("table") or table),
            "rows": rows,
            "next_start": next_start or None,
        }
        settled = body.get("settled_through") if isinstance(body, dict) else None
        if isinstance(settled, str) and settled.strip():
            page["settled_through"] = settled.strip()
        total = body.get("total") if isinstance(body, dict) else None
        if isinstance(total, int) and not isinstance(total, bool) and total >= 0:
            page["total"] = total
        return page

    def _request_once(
        self,
        table: str,
        start: Optional[str],
        end: Optional[str],
        entity_id: Optional[str],
        pack: Optional[str],
    ) -> Dict[str, Any]:
        query: Dict[str, str] = {}
        if start:
            query["start"] = _widen_month(str(start), is_end=False)
        if end:
            query["end"] = _widen_month(str(end), is_end=True)
        if entity_id:
            query["id"] = str(entity_id)
        if pack:
            query["pack"] = str(pack)
        url = f"{self.base_url}/api/v1/ntq-data/sync/{urllib.parse.quote(table)}"
        if query:
            url = f"{url}?{urllib.parse.urlencode(query)}"
        request = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {self._token()}",
                "Accept": "application/json",
            },
            method="GET",
        )
        try:
            with urlopen_https(request, timeout=_SLOT_HOLD_SECONDS) as response:
                status = response.status
                payload = response.read()
                retry_after = response.headers.get("Retry-After")
        except urllib.error.HTTPError as exc:
            status = exc.code
            payload = exc.read()
            retry_after = exc.headers.get("Retry-After") if exc.headers else None
        body = self._decode(payload)
        if status == 429:
            raise _Busy(_retry_seconds(retry_after))
        if status != 200:
            message = _error_message(body) or f"HTTP {status}"
            raise RuntimeError(message)
        if not isinstance(body, dict):
            raise RuntimeError("官网返回的行情页无法识别")
        return body

    def _post_plan(self, table: str, payload: bytes) -> Dict[str, Any]:
        url = f"{self.base_url}/api/v1/ntq-data/plan/{urllib.parse.quote(table)}"
        request = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Authorization": f"Bearer {self._token()}",
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urlopen_https(request, timeout=30) as response:
                status = response.status
                raw = response.read()
                retry_after = response.headers.get("Retry-After")
        except urllib.error.HTTPError as exc:
            status = exc.code
            raw = exc.read()
            retry_after = exc.headers.get("Retry-After") if exc.headers else None
        body = self._decode(raw)
        if status == 429:
            raise _Busy(_retry_seconds(retry_after))
        if status != 200:
            message = _error_message(body) or f"HTTP {status}"
            raise RuntimeError(message)
        if not isinstance(body, dict):
            raise RuntimeError("官网返回的更新计划无法识别")
        return body

    @staticmethod
    def _decode(payload: bytes) -> Any:
        if not payload:
            return {}
        return json.loads(payload.decode("utf-8"))


# 服务器上一把锁最多占这么久。客户端用同样的时间排队，并等这一次读取结束。
_SLOT_HOLD_SECONDS = 120.0


class _Busy(Exception):
    def __init__(self, retry_after: float):
        self.retry_after = retry_after
        super().__init__("官网行情读取正忙")


def _retry_seconds(header: Optional[str]) -> float:
    try:
        value = float(header or "2")
    except (TypeError, ValueError):
        value = 2.0
    return min(30.0, max(1.0, value))


def _widen_month(value: str, *, is_end: bool) -> str:
    """月份 YYYYMM 扩成同宽的日界，避免和会员窗口 YYYYMMDD 按整数比反。"""
    text = value.strip()
    if len(text) == 6 and text.isdigit():
        return text + ("31" if is_end else "01")
    return text


def _error_message(body: Any) -> str:
    if not isinstance(body, dict):
        return ""
    error = body.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or "")
    return ""
