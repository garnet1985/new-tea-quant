"""Tables the NTQ provider mirrors. Range columns match the Drupal catalog."""

from __future__ import annotations

from typing import Dict, Optional

# None means the whole table is synced by primary key. There is no date watermark.
TABLES: Dict[str, Optional[str]] = {
    "sys_data_adj_factor_events": "event_date",
    "sys_data_areas": None,
    "sys_data_boards": None,
    "sys_data_corporate_finance": "quarter",
    "sys_data_cpi": "date",
    "sys_data_gdp": "quarter",
    "sys_data_index_klines": "date",
    "sys_data_index_list": None,
    "sys_data_index_weight": "date",
    "sys_data_lpr": "date",
    "sys_data_markets": None,
    "sys_data_money_supply": "date",
    "sys_data_pmi": "date",
    "sys_data_ppi": "date",
    "sys_data_shibor": "date",
    "sys_data_stock_indicators": "date",
    "sys_data_stock_klines": "date",
    "sys_data_stock_list": None,
    "sys_data_stock_moneyflow": "date",
    "sys_data_stock_st_periods": None,
    "sys_data_sw_industry": None,
    "sys_data_sw_industry_kline": "date",
    "sys_data_trade_calendar": "cal_date",
    "sys_map_stock_area": None,
    "sys_map_stock_board": None,
    "sys_map_stock_market": None,
    "sys_map_sw_stock_industry": None,
}

# Shown in the renew log. The key stays the physical table name.
LABELS: Dict[str, str] = {
    "sys_data_adj_factor_events": "复权事件",
    "sys_data_areas": "地域",
    "sys_data_boards": "板块",
    "sys_data_corporate_finance": "公司财报",
    "sys_data_cpi": "CPI",
    "sys_data_gdp": "GDP",
    "sys_data_index_klines": "指数 K 线",
    "sys_data_index_list": "指数列表",
    "sys_data_index_weight": "指数权重",
    "sys_data_lpr": "LPR",
    "sys_data_markets": "市场",
    "sys_data_money_supply": "货币供应",
    "sys_data_pmi": "PMI",
    "sys_data_ppi": "PPI",
    "sys_data_shibor": "Shibor",
    "sys_data_stock_indicators": "股票指标",
    "sys_data_stock_klines": "股票 K 线",
    "sys_data_stock_list": "股票列表",
    "sys_data_stock_moneyflow": "个股资金流",
    "sys_data_stock_st_periods": "ST 时段",
    "sys_data_sw_industry": "申万行业",
    "sys_data_sw_industry_kline": "申万行业行情",
    "sys_data_trade_calendar": "交易日历",
    "sys_map_stock_area": "股票地域",
    "sys_map_stock_board": "股票板块",
    "sys_map_stock_market": "股票市场",
    "sys_map_sw_stock_industry": "申万行业成分",
}
