PROVIDER = {
    "base_url": "https://api.deepseek.com",
    "model": "deepseek-flash",
    "enabled": True,
}
