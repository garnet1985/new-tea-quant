# Post Process 扩展

后续处理是**全局**的：扫描任意策略结束后，自动跑所有 ``is_enabled: true`` 的 PostProcessor。
不在策略 ``settings.scanner`` 里配置。

```text
post_process/
├── adapters/
│   ├── tradable_opportunity.py
│   ├── report_template.py
│   ├── presenter/
│   ├── ntq_email/          # 官网代发（Membership）
│   ├── email_sender/
│   ├── wechat_sender/
│   ├── sms_sender/
│   └── demo_broker/
└── post_processors/
    ├── presenter/          # 仅展示（与 ntq_mail 互斥）
    ├── ntq_mail/           # 展示 + 官网邮件代发（默认开，dry_run）
    └── demo_handoff/       # 演示装配（默认关）
```

启用 / 关闭：改对应 ``post_processor.yaml`` 的 ``is_enabled``。
勿同时启用会重复跑 presenter / 发信的多套装配。

详见 `adapters/README.md` 与 `core/modules/post_process/docs/`。
