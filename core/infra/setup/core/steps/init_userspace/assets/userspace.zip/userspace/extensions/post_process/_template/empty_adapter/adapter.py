# 空白 Adapter。复制后改类名，实现 run。
from typing import Any, Dict

from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport


class EmptyAdapter(BaseAdapter):
    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> None:
        _ = config, deps
        for report in session.strategies:
            _ = report.strategy_name, len(report.opportunities)
