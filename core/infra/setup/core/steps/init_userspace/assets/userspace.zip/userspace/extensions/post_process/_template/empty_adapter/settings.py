"""Adapter 默认配置（可选）。"""

settings = {
    "display_name": "空 Adapter",
}
