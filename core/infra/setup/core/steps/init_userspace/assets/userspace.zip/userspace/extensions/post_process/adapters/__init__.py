"""userspace post_process adapters。

积木实现在子目录 ``<name>/adapter.py``；本包根另提供演示用
``TradableOpportunity``（可交易机会局部协议）。
"""

from userspace.extensions.post_process.adapters.tradable_opportunity import (
    SizeKind,
    TradableOpportunity,
)

__all__ = ["SizeKind", "TradableOpportunity"]
