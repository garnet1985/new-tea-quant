"""email_sender — 邮件通知（架子 / dry_run 默认开）。

正文来自 ``report.template.txt``；密钥放 ``token.txt``（见 ``token.example.txt``）。
"""

from __future__ import annotations

from typing import Any, Dict, List

from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport
from userspace.extensions.post_process.adapters.report_template import (
    adapter_dir,
    load_token,
    render_sender_report,
)


class EmailSenderAdapter(BaseAdapter):
    required_for_live = ("to",)
    required_files = ("token.txt",)

    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> Dict[str, Any]:
        dry_run = bool(config.get("dry_run", True))
        to_list: List[str] = []
        raw_to = config.get("to") or []
        if isinstance(raw_to, str) and raw_to.strip():
            to_list = [raw_to.strip()]
        elif isinstance(raw_to, list):
            to_list = [str(x).strip() for x in raw_to if str(x).strip()]

        body = render_sender_report(session, config, adapter_file=__file__)
        rows_hint = sum(len(r.opportunities) for r in session.strategies)
        subject = str(
            config.get("subject_template")
            or "[NTQ] 扫描完成（{scan_date}）· {opportunity_count} 个机会"
        ).format(
            scan_date=session.scan_date,
            opportunity_count=rows_hint,
            strategy_count=len(session.strategies),
        )

        directory = adapter_dir(__file__)
        token = load_token(directory)
        hist = deps.get("presenter")
        self.log_info(
            f"email_sender to={to_list or ['(unset)']} subject={subject!r} "
            f"dry_run={dry_run} token={'set' if token else 'unset'} "
            f"has_presenter_deps={hist is not None} body_lines={body.count(chr(10))+1}"
        )
        if dry_run:
            self.log_info("email_sender dry_run preview:\n" + body.rstrip())
            return {
                "channel": "email",
                "dry_run": True,
                "to": to_list,
                "subject": subject,
                "body": body,
                "opportunity_count": rows_hint,
            }

        if not to_list:
            raise RuntimeError("email_sender: 未配置 to")
        if not token:
            raise RuntimeError(
                "email_sender: 缺少 token.txt（先复制 token.example.txt → token.txt）"
            )
        # TODO: SMTP / 供应商 API 真发（token 作密码或 API Key）
        raise NotImplementedError("email_sender: 真发尚未实现，请保持 dry_run=true")
