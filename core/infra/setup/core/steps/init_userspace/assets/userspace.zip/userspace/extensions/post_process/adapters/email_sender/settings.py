settings = {
    "display_name": "邮件通知",
    "dry_run": True,
    "to": [],
    # "from_addr": "alerts@example.com",
    "subject_template": "[NTQ] 扫描完成（{scan_date}）· {opportunity_count} 个机会",
    # 留空则读同目录 report.template.txt / opportunity_line.template.txt
    "report_template": "",
    "line_template": "",
    # 建议仓位（机会 snapshot 未带 qty/weight/notional 时使用）
    "default_qty": 100,
    "default_weight": 0.05,
    "default_notional": None,
}
