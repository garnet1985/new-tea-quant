"""ntq_email — 经官网代发到会员注册邮箱（本地不存 token / 不写收件人）。

凭证：``Membership.read()``（唯一路径 membership_token.txt）。
官网按 Bearer 解析 uid，只发往账号注册邮箱；每账号终身额度 30 次。
正文由官网 HTML 模版渲染；本地只提交结构化 vars（日期 / 策略 / 机会表）。
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.infra.utils.core.net.ssl_context import urlopen_https
from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport
from userspace.extensions.post_process.adapters.report_template import (
    iter_opportunity_rows,
)


_MARKET_LABELS = {
    "SZ": "深市",
    "SH": "沪市",
    "BJ": "北交所",
    "HK": "港股",
    "US": "美股",
}


class NtqEmailAdapter(BaseAdapter):
    """依赖官网会员凭证；无 SMTP / 无本地收件人配置。"""

    # 与官网显示上限对齐：超出则截断并醒目标注（非按优劣排序，完整结果看本地）
    MAX_OPPORTUNITIES = 80

    def check_readiness(
        self,
        config: Dict[str, Any],
        *,
        adapter_directory: Optional[Path] = None,
    ) -> Tuple[bool, str]:
        del config, adapter_directory
        token = self._member_token()
        if not token:
            return False, "缺少：会员凭证（Membership）"
        return True, ""

    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> Dict[str, Any]:
        del deps
        dry_run = bool(config.get("dry_run", True))
        template = str(config.get("template") or "scan_report").strip() or "scan_report"

        strategies_full = self._strategies_payload(session, config)
        rows_total = sum(len(block["opportunities"]) for block in strategies_full)
        strategies, rows_shown, truncated = self._truncate_strategies(
            strategies_full, self.MAX_OPPORTUNITIES
        )
        scan_date_raw = str(session.scan_date or "")[:32]
        scan_date_label = self.format_date_zh(scan_date_raw)
        subject = str(
            config.get("subject_template")
            or "[NTQ] 扫描报告 · {scan_date} · {opportunity_count} 个机会"
        ).format(
            scan_date=scan_date_label,
            opportunity_count=rows_total,
            strategy_count=len(strategies_full),
        )
        if len(subject) > 120:
            subject = subject[:120]

        payload = {
            "template": template,
            "vars": {
                "scan_date": scan_date_raw,
                "opportunity_count": int(rows_total),
                "subject": subject,
                "strategies": strategies,
            },
        }

        token = self._member_token()
        preview = self._text_preview(
            scan_date_label, strategies, rows_total, truncated, rows_shown
        )
        self.log_info(
            f"ntq_email template={template!r} dry_run={dry_run} "
            f"token={'set' if token else 'unset'} opportunities={rows_total}"
            + (f" shown={rows_shown} truncated" if truncated else "")
        )
        if truncated:
            self.log_warning(
                f"ntq_email: 机会 {rows_total} 条超出邮件显示范围 "
                f"（展示 {rows_shown} 条，非优劣排序；请以本地完整结果为准）"
            )
        if dry_run:
            self.log_info("ntq_email dry_run preview:\n" + preview)
            return {
                "channel": "ntq_email",
                "dry_run": True,
                "template": template,
                "subject": subject,
                "strategies": strategies,
                "opportunity_count": rows_total,
                "shown": rows_shown,
                "truncated": truncated,
                "preview": preview,
            }

        if not token:
            raise RuntimeError(
                "ntq_email: 缺少会员凭证（请在设置页或 CLI 写入 membership_token.txt）"
            )

        result = self._post_send(token, payload)
        return {
            "channel": "ntq_email",
            "dry_run": False,
            "template": template,
            "subject": subject,
            "opportunity_count": rows_total,
            "shown": rows_shown,
            "truncated": truncated,
            "quota": result.get("quota"),
            "sent": bool(result.get("sent")),
        }

    @classmethod
    def _strategies_payload(
        cls,
        session: ScanSessionReport,
        config: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        display_by_key: Dict[str, str] = {}
        grouped: "OrderedDict[str, List[Dict[str, str]]]" = OrderedDict()
        for report in session.strategies:
            key = str(getattr(report, "strategy_name", "") or "").strip() or "未命名策略"
            display_by_key[key] = cls._strategy_display_name(key)
            grouped.setdefault(key, [])

        exchange_by_id: Dict[str, str] = {}
        for report in session.strategies:
            for opp in report.opportunities:
                eid = str(getattr(opp, "entity_id", "") or "").strip()
                exch = str(getattr(opp, "entity_exchange", "") or "").strip()
                if eid and exch:
                    exchange_by_id[eid] = exch

        for row in iter_opportunity_rows(session, config):
            key = str(row.get("strategy_name") or "").strip() or "未命名策略"
            display_by_key.setdefault(key, cls._strategy_display_name(key))
            grouped.setdefault(key, [])
            entity_id = str(row.get("code") or "")
            code, market = cls.parse_entity_id(
                entity_id,
                exchange=exchange_by_id.get(entity_id, ""),
            )
            grouped[key].append(
                {
                    "name": str(row.get("name") or "")[:64],
                    "code": code[:32],
                    "market": market[:16],
                    "price": str(row.get("price") or "")[:64],
                    "qty": str(row.get("qty") or "")[:64],
                    "notional": str(row.get("notional") or "")[:64],
                    "trigger_date": str(row.get("trigger_date") or "")[:32],
                }
            )

        return [
            {
                "name": display_by_key.get(key, key),
                "display_name": display_by_key.get(key, key),
                "key": key,
                "opportunities": opps,
            }
            for key, opps in grouped.items()
        ]

    @staticmethod
    def _strategy_display_name(key: str) -> str:
        needle = str(key or "").strip()
        if not needle:
            return "未命名策略"
        try:
            from core.modules.strategy import Strategy

            info = Strategy.find(needle)
            if isinstance(info, dict):
                label = str(info.get("display_name") or "").strip()
                if label:
                    return label
        except Exception:
            pass
        return needle

    @staticmethod
    def format_date_zh(raw: str) -> str:
        text = str(raw or "").strip()
        m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})", text)
        if m:
            return f"{int(m.group(1))}年{int(m.group(2))}月{int(m.group(3))}日"
        m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", text)
        if m:
            return f"{int(m.group(1))}年{int(m.group(2))}月{int(m.group(3))}日"
        return text or "—"

    @staticmethod
    def parse_entity_id(
        entity_id: str,
        *,
        exchange: str = "",
    ) -> Tuple[str, str]:
        raw = str(entity_id or "").strip()
        exch = str(exchange or "").strip().upper()
        code = raw
        market_code = ""
        if "." in raw:
            left, right = raw.rsplit(".", 1)
            code = left.strip()
            market_code = right.strip().upper()
        if not market_code and exch:
            market_code = exch
        # Common aliases from entity_exchange
        alias = {
            "XSHE": "SZ",
            "XSHG": "SH",
            "BSE": "BJ",
            "SSE": "SH",
            "SZSE": "SZ",
        }
        market_code = alias.get(market_code, market_code)
        label = _MARKET_LABELS.get(market_code, market_code)
        return code or raw or "—", label

    @staticmethod
    def _truncate_strategies(
        strategies: List[Dict[str, Any]],
        limit: int,
    ) -> Tuple[List[Dict[str, Any]], int, bool]:
        cap = max(1, int(limit))
        shown = 0
        truncated = False
        out: List[Dict[str, Any]] = []
        for block in strategies:
            name = str(block.get("name") or "")
            key = str(block.get("key") or "")
            kept: List[Dict[str, str]] = []
            for row in block.get("opportunities") or []:
                if shown >= cap:
                    truncated = True
                    break
                kept.append(row)
                shown += 1
            out.append(
                {
                    "name": name,
                    "display_name": name,
                    "key": key,
                    "opportunities": kept,
                }
            )
            if shown >= cap:
                if not truncated:
                    for rest in strategies[len(out) :]:
                        if rest.get("opportunities"):
                            truncated = True
                            break
                break
        return out, shown, truncated

    @classmethod
    def _text_preview(
        cls,
        scan_date_label: str,
        strategies: List[Dict[str, Any]],
        count: int,
        truncated: bool = False,
        shown: int = 0,
    ) -> str:
        names = [str(b.get("name") or "") for b in strategies]
        lines = [
            "NTQ 扫描报告",
            f"扫描日期：{scan_date_label}",
            f"策略：{'、'.join(names) if names else '（未指定）'}",
            f"总机会数：{count}",
        ]
        if truncated:
            lines.append("")
            lines.append("【重要】结果过多，超出邮件显示范围")
            lines.append(
                f"本次共 {count} 个机会；邮件仅展示其中 {shown} 条，且不是按优劣排序。"
            )
            lines.append("完整名单请在 NTQ 本地扫描结果中查看，以免遗漏。")
        lines.append("")
        for block in strategies:
            for row in block.get("opportunities") or []:
                market = str(row.get("market") or "").strip()
                code_line = str(row.get("code") or "")
                if market:
                    code_line = f"{code_line} · {market}"
                lines.append(
                    f"- {row.get('name')}（{code_line}）"
                    f" 建议买入 {row.get('price')} × {row.get('qty')} 股"
                    f"｜投资成本 {row.get('notional')} 元"
                )
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    @staticmethod
    def _member_token() -> Optional[str]:
        from core.infra.membership import Membership

        return Membership.read()

    @staticmethod
    def _post_send(token: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        from core.modules.ntq_external.conf.site_target import member_mail_send_url

        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            member_mail_send_url(),
            data=data,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
                "Content-Type": "application/json; charset=utf-8",
                "User-Agent": "NTQ-post-process/ntq_email",
            },
            method="POST",
        )
        try:
            with urlopen_https(request, timeout=20) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                out = json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = ""
            code = ""
            try:
                err_body = exc.read().decode("utf-8", errors="replace")
                parsed = json.loads(err_body) if err_body else {}
                if isinstance(parsed, dict):
                    detail = str(parsed.get("detail") or "")
                    code = str(parsed.get("code") or "")
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                detail = ""
            msg = detail or f"HTTP {exc.code}"
            if code:
                raise RuntimeError(f"ntq_email: {msg} ({code})") from exc
            raise RuntimeError(f"ntq_email: {msg}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise RuntimeError(f"ntq_email: 官网不可达 — {exc}") from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError("ntq_email: 官网返回非 JSON") from exc

        if not isinstance(out, dict):
            raise RuntimeError("ntq_email: 官网响应格式错误")
        return out
