settings = {
    "display_name": "NTQ 官网邮件",
    "dry_run": True,
    # 服务端 HTML 模版 id（客户端不得指定收件人 / 不得传 HTML）
    "template": "scan_report",
    # {scan_date} 由 adapter 填成「2025年12月31日」
    "subject_template": "[NTQ] 扫描报告 · {scan_date} · {opportunity_count} 个机会",
    "default_qty": 100,
    "default_weight": 0.05,
    "default_notional": None,
}
