"""presenter adapter 默认配置。"""

settings = {
    "display_name": "终端展示",
    "print": True,
    "show_history": True,
}
