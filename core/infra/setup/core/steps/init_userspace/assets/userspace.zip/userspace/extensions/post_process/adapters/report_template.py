"""扫描通知报告模版：供 email / wechat / sms 等 sender 共用。"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from core.modules.post_process.contracts import ScanSessionReport

DEFAULT_REPORT_TEMPLATE = (
    "当前扫描已经完成（{scan_date}），共发现{opportunity_count}个投资机会\n"
    "{opportunity_lines}"
)

DEFAULT_LINE_TEMPLATE = (
    "- {name}（{code}）- 当前价格：{price}，"
    "建议买入{qty}股｜仓位{weight_pct}%｜{notional}元"
)


def adapter_dir(file_dunder: str) -> Path:
    return Path(file_dunder).resolve().parent


def load_text(path: Path, *, default: str = "") -> str:
    if not path.is_file():
        return default
    try:
        return path.read_text(encoding="utf-8").strip("\n")
    except OSError:
        return default


def load_token(adapter_directory: Path) -> str:
    """读取同目录 ``token.txt``（一行密钥 / webhook；见 ``token.example.txt``）。"""
    raw = load_text(adapter_directory / "token.txt")
    if not raw:
        return ""
    return raw.splitlines()[0].strip()


def load_report_templates(
    adapter_directory: Path,
    config: Dict[str, Any],
) -> tuple[str, str]:
    """优先 config 字符串，其次同目录模版文件，最后内置默认。"""
    report = str(config.get("report_template") or "").strip()
    if not report:
        report = load_text(
            adapter_directory / "report.template.txt",
            default=DEFAULT_REPORT_TEMPLATE,
        )
    line = str(config.get("line_template") or "").strip()
    if not line:
        line = load_text(
            adapter_directory / "opportunity_line.template.txt",
            default=DEFAULT_LINE_TEMPLATE,
        )
    return report or DEFAULT_REPORT_TEMPLATE, line or DEFAULT_LINE_TEMPLATE


def _fmt_price(value: Any) -> str:
    try:
        return f"{float(value):.2f}"
    except (TypeError, ValueError):
        return str(value or "—")


def _fmt_qty(value: Any) -> str:
    try:
        q = float(value)
        return str(int(q)) if q == int(q) else f"{q:g}"
    except (TypeError, ValueError):
        return "—"


def _fmt_weight_pct(weight: Any) -> str:
    try:
        w = float(weight)
        if w <= 1.0:
            w *= 100.0
        return f"{w:.0f}" if abs(w - round(w)) < 1e-9 else f"{w:.1f}"
    except (TypeError, ValueError):
        return "—"


def _fmt_notional(value: Any) -> str:
    try:
        n = float(value)
        return str(int(round(n))) if abs(n - round(n)) < 1e-6 else f"{n:.2f}"
    except (TypeError, ValueError):
        return "—"


def _suggest_size(
    *,
    price: float,
    config: Dict[str, Any],
    snapshot: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    snap = snapshot or {}
    qty = snap.get("qty", config.get("default_qty", 100))
    weight = snap.get("weight", config.get("default_weight", 0.05))
    notional = snap.get("notional", config.get("default_notional"))
    try:
        p = float(price or 0.0)
        q = float(qty) if qty is not None else None
        if notional is None and p > 0 and q is not None:
            notional = p * q
    except (TypeError, ValueError):
        pass
    return {"qty": qty, "weight": weight, "notional": notional}


def iter_opportunity_rows(
    session: ScanSessionReport,
    config: Dict[str, Any],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for report in session.strategies:
        for opp in report.opportunities:
            price = float(getattr(opp, "trigger_price", 0.0) or 0.0)
            size = _suggest_size(
                price=price,
                config=config,
                snapshot=dict(getattr(opp, "snapshot", None) or {}),
            )
            name = str(getattr(opp, "entity_name", "") or "").strip() or str(
                getattr(opp, "entity_id", "") or ""
            )
            rows.append(
                {
                    "name": name,
                    "code": str(getattr(opp, "entity_id", "") or ""),
                    "price": _fmt_price(price),
                    "qty": _fmt_qty(size["qty"]),
                    "weight_pct": _fmt_weight_pct(size["weight"]),
                    "notional": _fmt_notional(size["notional"]),
                    "strategy_name": str(getattr(report, "strategy_name", "") or ""),
                    "trigger_date": str(getattr(opp, "trigger_date", "") or ""),
                }
            )
    return rows


def render_report(
    session: ScanSessionReport,
    config: Dict[str, Any],
    *,
    report_template: str,
    line_template: str,
) -> str:
    rows = iter_opportunity_rows(session, config)
    if rows:
        lines = [line_template.format(**row) for row in rows]
        opportunity_lines = "\n".join(lines)
    else:
        opportunity_lines = "（本次无投资机会）"

    return report_template.format(
        scan_date=session.scan_date,
        opportunity_count=len(rows),
        strategy_count=len(session.strategies),
        opportunity_lines=opportunity_lines,
    ).rstrip() + "\n"


def render_sender_report(
    session: ScanSessionReport,
    config: Dict[str, Any],
    *,
    adapter_file: str,
) -> str:
    directory = adapter_dir(adapter_file)
    report_tpl, line_tpl = load_report_templates(directory, config)
    return render_report(
        session,
        config,
        report_template=report_tpl,
        line_template=line_tpl,
    )


__all__ = [
    "DEFAULT_LINE_TEMPLATE",
    "DEFAULT_REPORT_TEMPLATE",
    "adapter_dir",
    "iter_opportunity_rows",
    "load_report_templates",
    "load_text",
    "load_token",
    "render_report",
    "render_sender_report",
]
