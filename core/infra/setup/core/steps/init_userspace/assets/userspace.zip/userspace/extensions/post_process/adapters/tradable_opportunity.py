"""可交易机会 — userspace 演示用局部协议（不属于 modules.post_process 三层出口）。

仅供交易类 adapter（如 demo_broker）使用：在标准 Opportunity 之上补仓位。
止损 / 止盈 / 持有等默认遵守 ``StrategyScanReport.goal``；若要改必须在 adapter 里显式改。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional

SizeKind = Literal["notional", "qty", "weight"]


@dataclass
class TradableOpportunity:
    """演示用可交易机会。

    相对标准机会，至少多一项仓位：``notional``（金额）/ ``qty``（股数或手数）/
    ``weight``（占仓比），且 ``size_kind`` 指明以谁为准。
    """

    # ----- 来自标准机会的关键字段（可直接拷贝）-----
    opportunity_id: str
    entity_id: str
    trigger_date: str
    trigger_price: float
    entity_name: str = ""
    strategy_name: str = ""
    snapshot: Dict[str, Any] = field(default_factory=dict)

    # ----- 仓位（至少一个非空，并由 size_kind 选定）-----
    size_kind: SizeKind = "notional"
    notional: Optional[float] = None
    qty: Optional[float] = None
    weight: Optional[float] = None

    # ----- 策略目标摘要（默认遵守，勿静默改写）-----
    goal: Dict[str, Any] = field(default_factory=dict)

    # ----- 扩展袋 -----
    extensions: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> tuple[bool, str]:
        if not str(self.opportunity_id or "").strip():
            return False, "opportunity_id 不能为空"
        if not str(self.entity_id or "").strip():
            return False, "entity_id 不能为空"
        if not str(self.trigger_date or "").strip():
            return False, "trigger_date 不能为空"
        kind = str(self.size_kind or "").strip()
        if kind not in ("notional", "qty", "weight"):
            return False, "size_kind 须为 notional | qty | weight"
        chosen = getattr(self, kind, None)
        if chosen is None:
            return False, f"size_kind={kind} 但对应字段为空"
        try:
            if float(chosen) <= 0:
                return False, f"{kind} 须 > 0"
        except (TypeError, ValueError):
            return False, f"{kind} 须为数字"
        return True, ""

    @classmethod
    def from_opportunity(
        cls,
        opportunity: Any,
        *,
        strategy_name: str = "",
        goal: Optional[Dict[str, Any]] = None,
        size_kind: SizeKind = "notional",
        notional: Optional[float] = None,
        qty: Optional[float] = None,
        weight: Optional[float] = None,
    ) -> "TradableOpportunity":
        """从协议 Opportunity（或 duck-type）构造；仓位由调用方填。"""
        return cls(
            opportunity_id=str(getattr(opportunity, "id", "") or ""),
            entity_id=str(getattr(opportunity, "entity_id", "") or ""),
            entity_name=str(getattr(opportunity, "entity_name", "") or ""),
            trigger_date=str(getattr(opportunity, "trigger_date", "") or ""),
            trigger_price=float(getattr(opportunity, "trigger_price", 0.0) or 0.0),
            strategy_name=str(strategy_name or ""),
            snapshot=dict(getattr(opportunity, "snapshot", None) or {}),
            size_kind=size_kind,
            notional=notional,
            qty=qty,
            weight=weight,
            goal=dict(goal or {}),
        )


__all__ = ["SizeKind", "TradableOpportunity"]
