# series_relation 用户场景

每个子目录一份 `settings.py`，跑批产物写在该目录的 `results/`。

```bash
python cli.py srel --list
python cli.py srel cn_index_vs_lpr
```

示例：
- `cn_index_vs_lpr/` — 沪深300 close vs LPR 1Y
- `banks_vs_baijiu/` — 民生银行 / 上海银行 vs 金种子酒
- `demo_portfolio_vs_hs300/` — 策略组合权益（`strategy_sim`）vs 沪深300（示范；跟谁比由 settings 决定）
- `market_mv_vs_rates/` — 全市场总市值（用户 CSV contract）vs LPR 1Y vs Shibor 1Y

`series[]` 可混用契约 `data_key` 与回测 `source: strategy_sim`（`portfolio.equity` / `price.cum_exit_roi`）。  
约定见 `core/modules/series_relation/docs/DECISIONS.md`。本波无 UI。
