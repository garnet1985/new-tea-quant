"""空白序列关系模板。复制后改 meta.key / series。"""

settings = {
    "meta": {
        "key": "empty_relation",
        "display_name": "空序列关系",
    },
    "series": [
        {
            "data_key": "index.kline.daily",
            "entity_id": "000300.SH",
            "field": "close",
            "label": "序列 A",
        },
        {
            "data_key": "macro.lpr",
            "field": "lpr_1_y",
            "label": "序列 B",
        },
    ],
    "range": {
        "start_date": "",
        "end_date": "",
    },
    "normalize": "zscore",
    "fill": "none",
    "analyze": True,
}
