# Persisted by SeriesRelation (BFF / Facade).
# Manual edits are allowed; next save may reformat this file.

settings = {
    "meta": {"key": "banks_vs_baijiu", "display_name": "民生/上海银行 vs 金种子酒"},
    "series": [
        {
            "source": "data_key",
            "data_key": "stock.kline.daily",
            "field": "close",
            "entity_id": "600016.SH",
            "label": "民生银行",
            "scope": "per_entity",
            "transform": "none",
        },
        {
            "source": "data_key",
            "data_key": "stock.kline.daily",
            "field": "close",
            "entity_id": "601229.SH",
            "label": "上海银行",
            "scope": "per_entity",
            "transform": "none",
        },
        {
            "source": "data_key",
            "data_key": "stock.kline.daily",
            "field": "close",
            "entity_id": "600199.SH",
            "label": "金种子酒",
            "scope": "per_entity",
            "transform": "none",
        },
    ],
    "range": {"start_date": "20230101", "end_date": ""},
    "normalize": "zscore",
    "fill": "none",
    "analyze": True,
}
