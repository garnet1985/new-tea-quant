"""示例：沪深300 日线收盘 vs LPR 1Y。

跑批::

    python cli.py srel cn_index_vs_lpr

需库内已有 ``index.kline.daily``（000300.SH）与 ``macro.lpr``。
"""

settings = {
    "meta": {
        "key": "cn_index_vs_lpr",
        "display_name": "沪深300 vs LPR 1Y",
    },
    "series": [
        {
            "data_key": "index.kline.daily",
            "entity_id": "000300.SH",
            "field": "close",
            "label": "沪深300",
        },
        {
            "data_key": "macro.lpr",
            "field": "lpr_1_y",
            "label": "LPR 1Y",
        },
    ],
    "range": {
        "start_date": "",
        "end_date": "",
    },
    "normalize": "zscore",
    "fill": "none",
    "analyze": True,
}
