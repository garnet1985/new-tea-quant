"""示例：策略组合权益（回测产物）vs 沪深300。

抽象：``source=strategy_sim`` 只负责引入回测序列；和谁比由本文件 ``series[]`` 决定。

跑批前请先对该策略跑过组合层（``so`` / ``sim``）。``version`` 省略 = latest。

::

    python cli.py srel demo_portfolio_vs_hs300
"""

settings = {
    "meta": {
        "key": "demo_portfolio_vs_hs300",
        "display_name": "示例：组合权益 vs 沪深300",
    },
    "series": [
        {
            "source": "strategy_sim",
            # 推荐填策略 meta.key；也可用相对路径（别名字段 strategy）
            "strategy_key": "demo/regression/rsi/rsi_v1_baseline",
            "layer": "portfolio",
            "metric": "equity",
            "label": "策略组合权益",
            "transform": "returns",
        },
        {
            "data_key": "index.kline.daily",
            "entity_id": "000300.SH",
            "field": "close",
            "label": "沪深300",
            "transform": "returns",
        },
    ],
    "range": {
        "start_date": "",
        "end_date": "",
    },
    "normalize": "zscore",
    "fill": "none",
    "analyze": True,
}
