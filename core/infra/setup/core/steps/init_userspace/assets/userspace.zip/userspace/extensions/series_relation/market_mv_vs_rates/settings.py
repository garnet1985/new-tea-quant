# Persisted by SeriesRelation (BFF / Facade).
# Manual edits are allowed; next save may reformat this file.

settings = {
    "meta": {"key": "market_mv_vs_rates", "display_name": "全市场总市值 vs LPR / Shibor"},
    "series": [
        {
            "source": "data_key",
            "data_key": "market.total_mv",
            "field": "total_market_value",
            "entity_id": "",
            "label": "全市场总市值",
            "scope": "global",
            "transform": "none",
        },
        {
            "source": "data_key",
            "data_key": "macro.lpr",
            "field": "lpr_1_y",
            "entity_id": "",
            "label": "LPR 1Y",
            "scope": "global",
            "transform": "none",
        },
        {
            "source": "data_key",
            "data_key": "macro.shibor",
            "field": "one_year",
            "entity_id": "",
            "label": "Shibor 1Y",
            "scope": "global",
            "transform": "none",
        },
    ],
    "range": {"start_date": "20230101", "end_date": "20251231"},
    "normalize": "zscore",
    "fill": "ffill",
    "analyze": True,
}
