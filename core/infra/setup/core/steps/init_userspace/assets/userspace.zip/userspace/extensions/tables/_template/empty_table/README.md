# 空白用户表模板（`_template/empty_table/`）

仅用于复制到 `userspace/extensions/tables/<name>/`。**不会**被 discovery 当成业务表（跳过 `_` 开头目录）。

## 约定

- 只放在 **userspace**，不要改 `core/tables`
- 表名必须是 `cust_{kind}_主题`（`kind`：`data` / `map` / `cache` / `tmp` / `meta`）
- 系统表（`sys_*` / `core/tables`）的结构性变更不走本模板

## 文件

| 文件 | 作用 |
|------|------|
| `schema.py` | 表结构（`schema` 字典） |
| `model.py` | `DbBaseModel` 子类，覆盖 `load_schema` |

[← 用户表说明](../../README.md)
