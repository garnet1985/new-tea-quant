"""空白用户表 Model。复制后请重命名类，并按需增加 load / upsert 方法。"""

from core.infra.db import DbBaseModel

from .schema import schema as _schema


class EmptyTableModel(DbBaseModel):
    def load_schema(self):
        return _schema

    def __init__(self, db=None):
        super().__init__(_schema["name"], db)
