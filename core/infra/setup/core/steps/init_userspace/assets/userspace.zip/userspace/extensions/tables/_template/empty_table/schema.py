"""空白用户表模板。复制后请改 name / kind / 字段；表名须为 cust_{kind}_主题。"""

schema = {
    "storage_domain": "strategy",
    "kind": "data",
    "name": "cust_data_empty_table",
    "primaryKey": "id",
    "fields": [
        {
            "name": "id",
            "type": "varchar",
            "length": 64,
            "isRequired": True,
            "nullable": False,
            "description": "主键",
        },
        {
            "name": "note",
            "type": "text",
            "isRequired": True,
            "nullable": True,
            "description": "备注",
        },
    ],
}
