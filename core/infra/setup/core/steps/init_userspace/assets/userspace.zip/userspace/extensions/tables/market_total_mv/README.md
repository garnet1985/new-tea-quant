# 全市场总市值（用户表）

演示：**在用户空间扩展一张数据库表**（`cust_data_market_total_mv`），与 data contract 读 CSV 是另一条路。

| 项 | 值 |
|----|-----|
| 表名 | `cust_data_market_total_mv` |
| 主键 | `date` |
| 字段 | `total_market_value`（万元）、`stock_count` |

建物理表并把 contract 目录里的 CSV 导入（需当前进程能独占打开本机 DuckDB）：

```bash
./venv/bin/python userspace/extensions/tables/market_total_mv/load_from_csv.py
```

对照：[`../../data_contract/market_total_mv/`](../../data_contract/market_total_mv/)（不建表，直接读 CSV）。
