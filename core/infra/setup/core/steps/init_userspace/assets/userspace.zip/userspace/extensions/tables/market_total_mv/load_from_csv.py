#!/usr/bin/env python3
"""确保 cust_data_market_total_mv 物理表存在，并从 data contract 目录 CSV 导入。

用法（仓库根目录）::

    ./venv/bin/python userspace/extensions/tables/market_total_mv/load_from_csv.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path
from typing import Any, Dict, List

_REPO = Path(__file__).resolve().parents[4]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

_CSV = (
    _REPO
    / "userspace"
    / "extensions"
    / "data_contract"
    / "market_total_mv"
    / "market_total_mv_daily_2023_2025.csv"
)


def main() -> int:
    from core.modules.data_manager import DataManager
    from core.modules.data_manager.core.user_tables.ops import UserTableOps

    if not _CSV.is_file():
        print(f"缺少 CSV: {_CSV}", flush=True)
        return 1

    dm = DataManager()
    ensured = UserTableOps.ensure_physical(dm, key="market_total_mv")
    if not ensured.get("ok"):
        print(f"建表失败: {ensured}", flush=True)
        return 1
    print(ensured.get("note") or "物理表已就绪", flush=True)

    model = dm.get_table("cust_data_market_total_mv")
    if model is None:
        print("注册后仍拿不到 cust_data_market_total_mv", flush=True)
        return 1

    rows = _read_csv(_CSV)
    n = model.upsert_rows(rows)
    print(f"已 upsert {n} 行（CSV {len(rows)} 行）→ cust_data_market_total_mv", flush=True)
    return 0


def _read_csv(path: Path) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8", newline="") as fh:
        filtered = (line for line in fh if line.strip() and not line.lstrip().startswith("#"))
        reader = csv.DictReader(filtered)
        for raw in reader:
            day = str(raw.get("date") or "").strip()
            if not day:
                continue
            try:
                total = float(raw.get("total_market_value"))
            except (TypeError, ValueError):
                continue
            row: Dict[str, Any] = {"date": day, "total_market_value": total}
            sc = raw.get("stock_count")
            if sc not in (None, ""):
                try:
                    row["stock_count"] = int(float(sc))
                except (TypeError, ValueError):
                    pass
            out.append(row)
    return out


if __name__ == "__main__":
    sys.exit(main())
