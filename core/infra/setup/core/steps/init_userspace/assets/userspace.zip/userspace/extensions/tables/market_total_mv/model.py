"""全市场日频总市值用户表 Model。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.infra.db import DbBaseModel

from .schema import schema as _schema


class MarketTotalMvModel(DbBaseModel):
    def load_schema(self):
        return _schema

    def __init__(self, db=None):
        super().__init__(_schema["name"], db)

    def load_by_date_range(
        self,
        start_date: str = "",
        end_date: str = "",
        *,
        order_by: str = "date ASC",
    ) -> List[Dict[str, Any]]:
        start = str(start_date or "").strip()
        end = str(end_date or "").strip()
        clauses = ["1=1"]
        params: List[Any] = []
        if start:
            clauses.append("date >= %s")
            params.append(start)
        if end:
            clauses.append("date <= %s")
            params.append(end)
        return self.load(
            " AND ".join(clauses),
            tuple(params),
            order_by=order_by,
        ) or []

    def upsert_rows(self, rows: List[Dict[str, Any]]) -> int:
        if not rows:
            return 0
        return self.upsert_many(rows, unique_keys=["date"])
