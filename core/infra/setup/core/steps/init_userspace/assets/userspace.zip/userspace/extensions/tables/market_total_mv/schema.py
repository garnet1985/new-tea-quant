"""全市场日频总市值用户表：演示在用户空间扩展数据库表。"""

schema = {
    "storage_domain": "data",
    "kind": "data",
    "name": "cust_data_market_total_mv",
    "primaryKey": ["date"],
    "fields": [
        {
            "name": "date",
            "type": "varchar",
            "length": 8,
            "isRequired": True,
            "nullable": False,
            "description": "交易日期 YYYYMMDD",
        },
        {
            "name": "total_market_value",
            "type": "float",
            "isRequired": True,
            "nullable": False,
            "description": "全市场总市值合计（万元）",
        },
        {
            "name": "stock_count",
            "type": "int",
            "isRequired": True,
            "nullable": True,
            "description": "当日参与合计的股票只数",
        },
    ],
    "indexes": [
        {"name": "idx_date", "fields": ["date"]},
    ],
}
