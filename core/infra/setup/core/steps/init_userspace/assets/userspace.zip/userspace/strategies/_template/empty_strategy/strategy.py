#!/usr/bin/env python3
"""空白策略模板 — 复制后在此实现 is_opportunity 等钩子。"""

from __future__ import annotations

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


class EmptyStrategy(StrategyHooks):
    """复制到新目录后重命名本类，并实现 ``is_opportunity``。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = (ctx, records)
        return False
