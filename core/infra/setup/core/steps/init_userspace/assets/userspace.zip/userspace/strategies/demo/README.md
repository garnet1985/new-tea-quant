# 内置演示策略（`demo/`）

一组说明清楚、便于修改的演示策略，用来跑通回测并对照常见功能写法。**不是投资建议。**

> 与 [DISCLAIMER.md](../../../DISCLAIMER.md) 一致：演示结果不保证未来可复现。

## 怎么开始？

1. 仓库根目录执行：`python launcher.py`
2. 顶栏打开 **制定策略**，按展示名选择一条演示
3. 按顺序运行：**枚举机会** → **价格回测** → **组合模拟**
4. 命令行可用策略短名，例如：`python cli.py se --strategy dual_ma`

## 当前演示

| 策略 | 短名 | 演示的功能 | 外部依赖 |
|------|------|------------|----------|
| [演示1 - 双均线金叉](dual_ma/) | `dual_ma` | 逐股回测；参数归因；滚动对照 | 无 |
| [演示2 - 追近月强势](chase_heat/) | `chase_heat` | 按日切片（横截面）排序选股 | 无 |
| [演示3 - 分三步下跌后再买入](three_wave/) | `three_wave` | 跨日状态；多段止盈 | 无 |
| [演示4a - 低价股（仅幸存者）](low_price_survivor/) | `low_price_survivor` | 股票列表过滤 | 无 |
| [演示4b - 低价股（含退市）](low_price/) | `low_price` | 与 4a 对照：不过滤上市状态 | 无 |
| [演示5 - 低估值与利率条件](cheap_pe_lpr/) | `cheap_pe_lpr` | 全局数据键 + 逐股数据键 | 无 |
| [演示6 - 领先滞后跟随](lead_lag/) | `lead_lag` | 股票池白名单；切片内多标的条件 | 无 |
| [演示7a - 低市值找低点（当场算市值）](near_low_cap/) | `near_low_cap` | 策略内读指标、自行判断市值区间 | 无 |
| [演示7b - 低市值找低点（读标签）](near_low_cap_tagged/) | `near_low_cap_tagged` | 同一套规则，改为读标签结论 | 先跑标签 `market_cap_tier` |

演示 7a / 7b **买卖规则相同**（靠近低点 + 低市值），差别只在市值条件怎么写：  
7a 引入日频指标里的总市值并在钩子里判断；7b 不引市值数据，直接读已算好的标签。7b 依赖 [`market_cap_tier`](../../extensions/tags/demo/market_cap_tier/)：

```bash
python cli.py t --scenario market_cap_tier
```

自定义表格或数据契约、利率与市值合计的序列关系另线完成。

## 更多

- [../README.md](../README.md) — 策略用户空间入门  
- [../USER_GUIDE.md](../USER_GUIDE.md) — 完整操作说明  
- [../settings_example.py](../settings_example.py) — 字段说明  
