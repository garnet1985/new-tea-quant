# 归因：一次只改一轴。不进回测指纹。

attribution = {
    "inputs": {
        "lookback_days": {"values": [10, 20, 40]},
        "top_n": {"values": [5, 10, 20]},
        "stop_loss": {"values": [-0.1, -0.15, -0.2]},
    },
    "cross": False,
}
