# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "chase_heat",
        "display_name": "演示2 - 追近月强势",
        "description": """\
        有不少交易者会追寻市场热度来进行交易。
        当前策略假设热度就是最近一段时间内市场涨幅比较大的股票。
        然后加入追逐，通过追随趋势而试图盈利。当我们需要对市场中股票热度排序，那么股票之间就产生了相互依赖的关系，这个时候我们就需要用到切片模式。
        演示目的：展示横截面切片（slice_based）模式。
        """,
        "category": "演示 · 横截面",
        "keywords": ["追涨", "强势", "涨幅排序", "横截面", "月度换仓"],
        "details": {
            "entry": [
                "只在每月第一个开市日挑选一次",
                "计算每只股票近 20 个交易日的涨跌幅",
                "按涨幅从高到低排序，买入前 10 名",
            ],
            "exit": ["亏损达到约 15% 时止损离场", "大约持有 30 个开市日到期离开，下月初再选"],
        },
        "is_enabled": True,
    },
    "core": {"lookback_days": 20, "top_n": 10},
    "data": {"base": {"data_key": "stock.kline.daily"}, "min_required_records": 40},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.15}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "slice_based", "start_date": ""}},
}
