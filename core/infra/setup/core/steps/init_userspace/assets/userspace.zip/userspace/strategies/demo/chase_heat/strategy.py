#!/usr/bin/env python3
"""追近月强势：每月挑出近期涨幅靠前的股票。"""

from __future__ import annotations

from typing import List, Tuple

from core.modules.strategy.contracts import (
    CalendarSlice,
    Records,
    StrategyContext,
    StrategyHooks,
)


class ChaseHeatStrategy(StrategyHooks):
    """月初按近若干日涨幅排序，取涨幅最高的若干只。"""

    def on_calendar_slice(
        self, ctx: StrategyContext, calendar_slice: CalendarSlice
    ) -> List[str]:
        # 不是每月第一个开市日：不产生新名单
        if not calendar_slice.is_first_open_of_month:
            return []

        lookback = int(ctx.core["lookback_days"])
        top_n = int(ctx.core["top_n"])

        ranked: List[Tuple[str, float]] = []
        for sid in calendar_slice.ids():
            records = calendar_slice.records_of(sid)
            # 近 lookback 根日线的涨跌幅；历史不足则跳过（pct_change 挂在 Series 上）
            change = records.series().pct_change("close", lookback)
            if change is None:
                continue
            ranked.append((sid, float(change)))

        # 涨幅高的在前；涨幅相同则按股票代码排序，保证结果稳定
        ranked.sort(key=lambda item: (-item[1], item[0]))
        return [sid for sid, _ in ranked[:top_n]]

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        # 能进入本函数的，已是上面名单中的股票
        _ = (ctx, records)
        return True
