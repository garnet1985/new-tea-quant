# 归因：一次只改一轴。不进回测指纹。

attribution = {
    "inputs": {
        "max_lpr": {"values": [3.2, 3.45, 3.7]},
        "max_pe": {"values": [15.0, 25.0, 40.0]},
        "top_n": {"values": [5, 10, 20]},
    },
    "cross": False,
}
