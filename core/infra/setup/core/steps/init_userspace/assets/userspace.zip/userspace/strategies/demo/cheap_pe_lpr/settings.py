# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "cheap_pe_lpr",
        "display_name": "演示5 - 低估值与利率条件",
        "description": """\
这是把全市场利率和单只股票估值放在一起用的例子。
一年期贷款市场报价利率用来作为当前例子中的宏观条件的测量标尺。
只有大环境相对温和的时候策略才会投资，否则就先停下。
演示目的：说明如何同时使用全局数据和个股数据。
""",
        "category": "演示 · 估值与宏观",
        "keywords": ["低估值", "市盈率", "贷款市场报价利率", "宏观", "横截面"],
        "details": {
            "entry": [
                "只在每月第一个开市日挑选一次",
                "先看全局：一年期贷款市场报价利率高于上限则本月不选股",
                "再看逐股：滚动市盈率大于 0 且不超过上限的股票才进入候选",
                "按市盈率从低到高排序，买入前 10 名",
            ],
            "exit": ["亏损约 15% 时止损离场", "大约持有 30 个开市日到期离开，下月初再选"],
        },
        "is_enabled": True,
    },
    "core": {"max_lpr": 3.45, "max_pe": 25, "top_n": 10},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 20,
        "required": [{"data_key": "stock.indicators.daily"}, {"data_key": "macro.lpr"}],
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.15}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "slice_based", "start_date": ""}},
}
