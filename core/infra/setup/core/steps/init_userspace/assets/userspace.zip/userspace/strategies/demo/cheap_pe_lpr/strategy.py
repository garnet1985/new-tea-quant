#!/usr/bin/env python3
"""低估值与利率条件：一年期贷款市场报价利率不高时，按市盈率从低到高选股。"""

from __future__ import annotations

from typing import List, Tuple

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.strategy.contracts import (
    CalendarSlice,
    Records,
    StrategyContext,
    StrategyHooks,
)

# 数据键请用常量，不要手写字符串。全部可用键：python cli.py ls datakeys
RATE_DATA_KEY = DATA_KEY.MACRO_LPR
INDICATOR_DATA_KEY = DATA_KEY.STOCK_INDICATORS_DAILY


class CheapPeLprStrategy(StrategyHooks):
    """月初：先检查全市场利率，再按市盈率从低到高取前若干名。"""

    def on_calendar_slice(
        self, ctx: StrategyContext, calendar_slice: CalendarSlice
    ) -> List[str]:
        if not calendar_slice.is_first_open_of_month:
            return []

        ids = calendar_slice.ids()
        if not ids:
            return []

        max_lpr = float(ctx.core["max_lpr"])
        max_pe = float(ctx.core["max_pe"])
        top_n = int(ctx.core["top_n"])

        # 利率是全局序列，任意一只股票的记录里都能读到同一份。
        # 字段 lpr_1_y：一年期贷款市场报价利率（该数据键对应表中的列名）。
        rate = calendar_slice.records_of(ids[0]).field("lpr_1_y", RATE_DATA_KEY)
        if rate is None or float(rate) > max_lpr:
            # 利率高于上限：本月不选股
            return []

        candidates: List[Tuple[str, float]] = []
        for sid in ids:
            # 字段 pe_ttm：滚动市盈率（该数据键对应表中的列名）。
            pe = calendar_slice.records_of(sid).field("pe_ttm", INDICATOR_DATA_KEY)
            if pe is None:
                continue
            pe_f = float(pe)
            # 市盈率无效（小于等于 0）或高于上限：不参选
            if pe_f <= 0 or pe_f > max_pe:
                continue
            candidates.append((sid, pe_f))

        candidates.sort(key=lambda item: (item[1], item[0]))
        return [sid for sid, _ in candidates[:top_n]]

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = (ctx, records)
        return True
