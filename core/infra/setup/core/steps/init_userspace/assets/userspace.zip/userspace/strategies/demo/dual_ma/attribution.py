# 归因：一次只改一轴，对比止损 / 止盈松紧。不进回测指纹。

attribution = {
    "inputs": {
        "stop_loss": {"values": [-0.08, -0.1, -0.15]},
        "take_profit": {"values": [0.15, 0.2, 0.3]},
    },
    "cross": False,
}
