# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "dual_ma",
        "display_name": "演示1 - 双均线金叉",
        "description": """\
短期均线从下往上穿过长期均线，习惯上叫做金叉。当前策略就是扫描并抓住金叉的情景进行投资。
演示目的：最基本例子说明如何写策略，配置参数，以及做参数归因和滚动对照。
""",
        "category": "演示 · 入门",
        "keywords": ["双均线", "金叉", "均线", "入门", "逐股"],
        "details": {
            "entry": [
                "算出每只股票的 10 日均线（短）和 30 日均线（长）",
                "当短线从下方穿过长线时，记为一次买入机会",
            ],
            "exit": [
                "亏损达到约 10% 时止损离场",
                "盈利达到约 20% 时止盈离场",
                "最多持有约 30 个开市日，到期也离开",
            ],
        },
        "is_enabled": True,
    },
    "core": {},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {
                "ma": [{"alias": "ma10", "length": 10}, {"alias": "ma30", "length": 30}]
            },
        },
        "min_required_records": 60,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.1}]},
        "take_profit": {"stages": [{"close_invest": True, "ratio": 0.2}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "entity_based", "start_date": ""}},
}
