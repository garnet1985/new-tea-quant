#!/usr/bin/env python3
"""双均线金叉：短期均线从下方穿过长期均线时买入。"""

from __future__ import annotations

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


class DualMaCrossStrategy(StrategyHooks):
    """10 日均线从下方穿过 30 日均线时，记为买入机会。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = ctx
        # 当日短均线从下方穿过长均线（穿越判断挂在 Series 上）
        return records.series().crossed_above("ma10", "ma30")
