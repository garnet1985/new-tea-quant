# 归因：一次只改一轴。不进回测指纹。

attribution = {
    "inputs": {
        "lookback_days": {"values": [3, 5, 10]},
        "min_lead_return": {"values": [0.02, 0.03, 0.05]},
        "stop_loss": {"values": [-0.08, -0.1, -0.15]},
    },
    "cross": False,
}
