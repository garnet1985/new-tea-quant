# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "lead_lag",
        "display_name": "演示6 - 领先滞后跟随",
        "description": """\
两只走势相关的股票里，有时一只可能会先涨，另一只过几天再涨。
我们可以通过高级功能「序列关系」观察到这种情况。
当原本每次都是同向趋势的股票突然出现一个先动的情况，策略就会捕获然后投资那个迟滞的股票。
演示目的：说明如何使用辅助工具类似序列关系一同制定策略。
""",
        "category": "演示 · 序列关系",
        "keywords": ["领先滞后", "配对", "银行", "序列关系"],
        "details": {
            "entry": [
                "股票池只保留先动、后动两只股票",
                "每天看先动股票近 5 个交易日的涨跌幅",
                "涨幅达到约 2% 时，对后动股票记一次买入机会",
            ],
            "exit": ["亏损约 10% 时止损离场", "大约持有 15 个开市日到期离开"],
            "howto": [
                "可先执行 python cli.py srel --list，列出并运行序列关系场景以观察股票对",
                "再修改配置 core 中的 lead_id（先动股票）与 lag_id（后动股票）",
            ],
        },
        "is_enabled": True,
    },
    "core": {
        "lag_id": "603323.SH",
        "lead_id": "601288.SH",
        "lookback_days": 5,
        "min_lead_return": 0.02,
    },
    "data": {"base": {"data_key": "stock.kline.daily"}, "min_required_records": 30},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 15, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.1}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 2,
            "max_weight_per_stock": 1,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "sampling": {
        "pool": {"stock_ids": ["601288.SH", "603323.SH"]},
        "strategy": "pool",
        "use_sampling": True,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "slice_based", "start_date": ""}},
}
