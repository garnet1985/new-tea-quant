#!/usr/bin/env python3
"""领先滞后：先动股票近期涨幅达到条件时，买入后动股票。"""

from __future__ import annotations

from typing import List

from core.modules.strategy.contracts import (
    CalendarSlice,
    Records,
    StrategyContext,
    StrategyHooks,
)


class LeadLagFollowStrategy(StrategyHooks):
    """看先动股票近若干日涨幅；达标则只对后动股票产生机会。"""

    def on_calendar_slice(
        self, ctx: StrategyContext, calendar_slice: CalendarSlice
    ) -> List[str]:
        lead_id = str(ctx.core["lead_id"])
        lag_id = str(ctx.core["lag_id"])
        lookback = int(ctx.core["lookback_days"])
        min_ret = float(ctx.core["min_lead_return"])

        if not calendar_slice.has(lead_id) or not calendar_slice.has(lag_id):
            return []

        # 先动股票近 lookback 根日线的涨跌幅（pct_change 挂在 Series 上）
        change = (
            calendar_slice.records_of(lead_id).series().pct_change("close", lookback)
        )
        if change is None or float(change) < min_ret:
            return []

        # 只买入后动股票，不买入先动股票本身
        return [lag_id]

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = (ctx, records)
        return True
