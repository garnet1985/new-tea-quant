# 归因：一次只改一轴。不进回测指纹。

attribution = {
    "inputs": {
        "min_close": {"values": [1.0, 2.0, 3.0]},
        "max_close": {"values": [4.0, 5.0, 8.0]},
        "top_n": {"values": [5, 10, 20]},
    },
    "cross": False,
}
