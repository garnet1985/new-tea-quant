# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price",
        "display_name": "演示4b - 低价股（含退市）",
        "description": """\
我们从公开行情中看到低价股往往有巨大涨幅。但是，容易忽略的是，其实这些低价股都是还活着的股票，很可能很多股票都没能从低价中挺过来从而最终退市。本条把回测期间退市的股票也放进股票池，再跑一次结果。与 4a 的差别就是这次纳入了退市股票（退市股票行情一般默认是不展示的）。
演示目的：通过与演示 4a 对照，展示幸存者偏差可能会带来很大的结果差异。
""",
        "category": "演示 · 横截面",
        "keywords": ["低价股", "横截面", "退市", "幸存者偏差"],
        "details": {
            "entry": [
                "只在每月第一个开市日挑选一次",
                "收盘价落在约 2 到 5 元区间内的股票才进入候选",
                "按收盘价从低到高排序，买入最便宜的前 10 名",
                "股票池不按当前是否仍上市过滤，包含退市样本",
            ],
            "exit": ["大约持有 30 个自然日到期离开，下月初再选"],
        },
        "is_enabled": True,
    },
    "core": {"max_close": 5, "min_close": 2, "top_n": 10},
    "data": {"base": {"data_key": "stock.kline.daily"}, "min_required_records": 1},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {"expiration": {"fixed_window_in_days": 30, "mode": "natural_day"}},
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "slice_based", "start_date": ""}},
}
