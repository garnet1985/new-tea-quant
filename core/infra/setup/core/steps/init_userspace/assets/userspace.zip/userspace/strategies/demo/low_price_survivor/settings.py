# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_survivor",
        "display_name": "演示4a - 低价股（仅幸存者）",
        "description": """\
在行情软件或网站上，您可能会看到很多股票在价格很低的时候之后可能会出现极其夸张的涨幅。那么如果我们试图交易这些低价股，是不是会有不错的盈利空间？
本策略在月初于约 2 到 5 元区间里买入最便宜的一批，大约持有一个月后到期卖出，再重复。
演示目的：展示用股票列表过滤限制股票池；请再对照运行演示 4b。
""",
        "category": "演示 · 横截面",
        "keywords": ["低价股", "横截面", "幸存者", "对照", "退市"],
        "details": {
            "entry": [
                "只在每月第一个开市日挑选一次",
                "收盘价落在约 2 到 5 元区间内的股票才进入候选",
                "按收盘价从低到高排序，买入最便宜的前 10 名",
                "股票池只保留上市状态为「上市」的股票",
            ],
            "exit": ["大约持有 30 个自然日到期离开，下月初再选"],
        },
        "is_enabled": True,
    },
    "core": {"max_close": 5, "min_close": 2, "top_n": 10},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 1,
        "stock_list_filter": {"include": {"list_status": ["L"]}},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {"expiration": {"fixed_window_in_days": 30, "mode": "natural_day"}},
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "slice_based", "start_date": ""}},
}
