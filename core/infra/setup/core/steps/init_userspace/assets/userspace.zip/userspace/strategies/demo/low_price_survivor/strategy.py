#!/usr/bin/env python3
"""低价股（仅幸存者）：选股规则与演示 4b 相同，股票池只保留仍上市的股票。"""

from __future__ import annotations

from typing import List, Tuple

from core.modules.strategy.contracts import (
    CalendarSlice,
    Records,
    StrategyContext,
    StrategyHooks,
)


class LowPriceSurvivorStrategy(StrategyHooks):
    """月初按收盘价从低到高选取，且价格须落在上下限之间。"""

    def on_calendar_slice(
        self, ctx: StrategyContext, calendar_slice: CalendarSlice
    ) -> List[str]:
        if not calendar_slice.is_first_open_of_month:
            return []

        min_close = float(ctx.core["min_close"])
        max_close = float(ctx.core["max_close"])
        top_n = int(ctx.core["top_n"])

        candidates: List[Tuple[str, float]] = []
        for sid in calendar_slice.ids():
            bar = calendar_slice.records_of(sid).latest
            if not isinstance(bar, dict):
                continue
            try:
                close = float(bar["close"])
            except (KeyError, TypeError, ValueError):
                continue
            if min_close <= close <= max_close:
                candidates.append((sid, close))

        candidates.sort(key=lambda item: (item[1], item[0]))
        return [sid for sid, _ in candidates[:top_n]]

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = (ctx, records)
        return True
