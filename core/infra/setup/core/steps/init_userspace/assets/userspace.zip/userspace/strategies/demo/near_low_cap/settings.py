# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "near_low_cap",
        "display_name": "演示7a - 低市值找低点（当场算市值）",
        "description": """\
收盘价靠近近一段低点时买入，同时要求当日总市值不超过低市值上限。本条在策略里直接读日频指标的总市值字段做区间判断。与演示 7b 买卖规则相同，差别只在市值条件怎么写。
演示目的：展示不复用标签时，策略要自己引入市值数据并在钩子里校验。
""",
        "category": "演示 · 标签与过滤",
        "keywords": ["低点", "低市值", "指标", "对照"],
        "details": {
            "entry": [
                "引入日频指标数据，读取总市值字段",
                "总市值（亿元）不超过上限时才继续",
                "收盘价落在近 40 个交易日最低价附近（约 5% 以内）时买入",
            ],
            "exit": ["亏损约 12% 时止损离场", "大约持有 40 个开市日到期离开"],
        },
        "is_enabled": True,
    },
    "core": {"lookback": 40, "max_market_cap_yi": 30, "near_low_pct": 0.05},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 40,
        "required": [{"data_key": "stock.indicators.daily"}],
        "stock_list_filter": {"include": {"list_status": ["L"]}},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 40, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.12}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "entity_based", "start_date": ""}},
}
