#!/usr/bin/env python3
"""低市值找低点：当场读总市值做区间判断，再在靠近低点时买入。"""

from __future__ import annotations

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks

# 数据键请用常量。全部可用键：python cli.py ls datakeys
INDICATOR_KEY = DATA_KEY.STOCK_INDICATORS_DAILY


class NearLowCapStrategy(StrategyHooks):
    """总市值不超过上限，且靠近近 lookback 日最低价时买入。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        max_yi = float(ctx.core["max_market_cap_yi"])
        # 库内 total_market_value：万元；配置上限：亿元
        cap_wan = records.field("total_market_value", INDICATOR_KEY)
        if cap_wan is None or float(cap_wan) <= 0:
            return False
        if float(cap_wan) / 10_000.0 > max_yi:
            return False

        lookback = int(ctx.core["lookback"])
        near_low_pct = float(ctx.core["near_low_pct"])
        series = records.series()
        close = series.at("close")
        low = series.min_of("close", lookback)
        if close is None or low is None or low <= 0:
            return False
        return float(close) <= float(low) * (1.0 + near_low_pct)
