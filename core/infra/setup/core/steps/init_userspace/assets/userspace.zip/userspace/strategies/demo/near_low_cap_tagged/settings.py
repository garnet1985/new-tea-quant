# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "near_low_cap_tagged",
        "display_name": "演示7b - 低市值找低点（读标签）\n",
        "description": """\
与演示 7a 买卖规则相同：靠近近一段低点，且当前属于低市值。本条不引入带总市值的指标数据，只读取标签场景 
市值分档标签（market_cap_tier） 的结果。请先运行该标签，再跑本策略。
演示目的：展示可积累、可复用的标签——同一套判断写一次，策略直接读结论。
""",
        "category": "演示 · 标签与过滤",
        "keywords": ["低点", "低市值", "标签", "对照"],
        "details": {
            "entry": [
                "请先计算标签：python cli.py t --scenario market_cap_tier",
                "当前标签为「低市值」时才继续（不必再读总市值字段）",
                "收盘价落在近 40 个交易日最低价附近（约 5% 以内）时买入",
            ],
            "exit": ["亏损约 12% 时止损离场", "大约持有 40 个开市日到期离开"],
        },
        "is_enabled": True,
    },
    "core": {"lookback": 40, "near_low_pct": 0.05, "tag_name": "low_cap"},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 40,
        "required": [{"data_key": "tag", "params": {"tag_scenario": "market_cap_tier"}}],
        "stock_list_filter": {"include": {"list_status": ["L"]}},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 40, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.12}]},
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "entity_based", "start_date": ""}},
}
