#!/usr/bin/env python3
"""低市值找低点：读市值档标签，再在靠近低点时买入。"""

from __future__ import annotations

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks

TAG_KEY = DATA_KEY.TAG


class NearLowCapTaggedStrategy(StrategyHooks):
    """当前为低市值标签，且靠近近 lookback 日最低价时买入。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        tag_name = str(ctx.core.get("tag_name") or "low_cap").strip()
        # 市值档只在变化日写入：截至当日最后一条才是「当前」档位
        if _latest_tag_name(records) != tag_name:
            return False

        lookback = int(ctx.core["lookback"])
        near_low_pct = float(ctx.core["near_low_pct"])
        series = records.series()
        close = series.at("close")
        low = series.min_of("close", lookback)
        if close is None or low is None or low <= 0:
            return False
        return float(close) <= float(low) * (1.0 + near_low_pct)


def _latest_tag_name(records: Records) -> str:
    """取 as-of 可见标签序列里最近一条的 tag_name。"""
    if not records.has(TAG_KEY):
        return ""
    rows = list(records.series(TAG_KEY))
    for row in reversed(rows):
        if not isinstance(row, dict):
            continue
        name = str(row.get("tag_name") or "").strip()
        if name:
            return name
    return ""
