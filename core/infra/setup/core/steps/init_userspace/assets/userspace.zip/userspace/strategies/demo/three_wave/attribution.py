# 归因：一次只改一轴。不进回测指纹。

attribution = {
    "inputs": {
        "drop_pct": {"values": [0.05, 0.08, 0.12]},
        "stop_loss": {"values": [-0.08, -0.12, -0.18]},
    },
    "cross": False,
}
