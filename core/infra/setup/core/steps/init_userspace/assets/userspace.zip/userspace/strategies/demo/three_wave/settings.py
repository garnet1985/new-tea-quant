# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "three_wave",
        "display_name": "演示3 - 分三步下跌后再买入",
        "description": """\
我们的策略假设一波行情都是分三步走的，那么：
用策略按三步推进，并用跨日状态记住每只股票已经走到哪一步，而不是每个交易日都从第一步重新判断。
卖出也拆成三段止盈，按盈利比例分批减仓。
演示目的：展示跨日状态（按股票保存进度），以及多段止盈配置。
""",
        "category": "演示 · 跨日状态",
        "keywords": ["分步", "均线", "跨日状态", "分批止盈"],
        "details": {
            "entry": [
                "第 1 步：收盘跌破 30 日均线，记为已跌破长期均线",
                "第 2 步：相对第 1 步时的价位再下跌约 8%，记为已继续下跌",
                "第 3 步：收盘重新高于 10 日均线则买入，状态清零后重新等待",
            ],
            "exit": [
                "亏损约 12% 时止损离场",
                "盈利约 8% 时先卖掉约三成",
                "盈利约 15% 时再卖掉约三成",
                "盈利约 25% 时清仓；或最多持有约 40 个开市日到期离开",
            ],
        },
        "is_enabled": True,
    },
    "core": {"drop_pct": 0.08},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {
                "ma": [{"alias": "ma10", "length": 10}, {"alias": "ma30", "length": 30}]
            },
        },
        "min_required_records": 60,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 40, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.12}]},
        "take_profit": {
            "stages": [
                {"exit_ratio": 0.3, "ratio": 0.08},
                {"exit_ratio": 0.3, "ratio": 0.15},
                {"close_invest": True, "ratio": 0.25},
            ]
        },
    },
    "portfolio": {
        "allocation": {
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
    },
    "scanner": {"enabled": True},
    "simulation": {"execution": {"end_date": "", "mode": "entity_based", "start_date": ""}},
}
