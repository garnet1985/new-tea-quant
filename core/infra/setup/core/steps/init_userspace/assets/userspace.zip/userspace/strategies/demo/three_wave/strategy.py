#!/usr/bin/env python3
"""分三步下跌后再买入：用跨日状态记住每只股票当前走到第几步。"""

from __future__ import annotations

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks

# 三步状态，按股票代码存在跨日状态里
WATCH = "watch"  # 等待
WEAK = "weak"  # 已跌破长期均线
DEEP = "deep"  # 已相对参考价再下跌一截


class ThreeWaveDipStrategy(StrategyHooks):
    """等待 → 跌破长期均线 → 再下跌一截 → 站上短期均线后买入，然后回到等待。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        close = records.field("close")
        ma10 = records.field("ma10")
        ma30 = records.field("ma30")
        if close is None or ma10 is None or ma30 is None:
            return False

        # 每只股票单独一份状态（同一回测里上下文会在多只股票间共用）
        st = ctx.state.setdefault(
            records.entity_id,
            {"phase": WATCH, "ref_high": None},
        )
        phase = st["phase"]
        drop_pct = float(ctx.core["drop_pct"])

        if phase == WATCH:
            # 第 1 步：收盘跌破 30 日均线
            if close < ma30:
                st["phase"] = WEAK
                st["ref_high"] = float(close)
            return False

        if phase == WEAK:
            # 重新站上 30 日均线：取消本轮，回到等待
            if close >= ma30:
                st["phase"] = WATCH
                st["ref_high"] = None
                return False
            ref = float(st["ref_high"] or close)
            st["ref_high"] = ref
            # 第 2 步：相对第 1 步时的价位再下跌设定比例
            if close <= ref * (1.0 - drop_pct):
                st["phase"] = DEEP
            return False

        # 第 3 步：收盘重新高于 10 日均线则买入，并清空状态
        if close > ma10:
            st["phase"] = WATCH
            st["ref_high"] = None
            ctx.capture("phase", DEEP)
            ctx.capture("close", close)
            return True

        return False
