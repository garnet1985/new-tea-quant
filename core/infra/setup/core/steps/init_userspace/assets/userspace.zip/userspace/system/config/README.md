# 用户配置目录（`userspace/system/config/`）

本地配置会**深度合并**到 `core/default_config/`，一般只改需要覆盖的字段。

一次性偏好 / UI 状态（同意上报、反馈开关、helper 关闭账本）在 **`userspace/system/prefs/`**，不放本目录，也不放 `.ntq/`（清缓存会丢）。

## 目录结构

```text
userspace/system/config/
├── data.json                  # 数据相关（可选）
├── market.json                # 市场相关（可选）
├── system.json                # 系统相关（可选）
├── worker.json                # 调度/worker 覆盖（可选）
└── database/                  # 数据库（可选）
    ├── common.json
    ├── postgresql.json
    ├── mysql.json
    └── duckdb.json

userspace/system/prefs/        # 偏好与一次性状态（非 default_config 合并）
├── trace_consent.json
├── feedback_prefs.json
└── ui_helper.json
```

`*.example.json` 可作模板；实际 `*.json` 通常已 gitignore。

## 优先级

1. **环境变量**（最高）
2. **`userspace/system/config/`**
3. **`core/default_config/`**

## 常用配置

### 数据库类型（`database/common.json`）

```json
{
  "database_type": "duckdb"
}
```

默认 DuckDB 库文件在 **`userspace/system/db/`**（`data.duckdb` / `tag.duckdb` / `strategy.duckdb`）。  
PostgreSQL / MySQL 可在对应 json 中只写用户名密码，其余用默认；敏感信息也可用 `DB_POSTGRESQL_*` 等环境变量。

### 数据（`data.json`）

```json
{
  "default_start_date": "20100101",
  "use_sample_stock_list": 500
}
```

**`use_sample_stock_list`（开发样本池）**

- 正整数 N → 使用 `core/modules/data_manager/core/dev/sample_stock_list/stratified_N.csv` 作为全局股票池
- 读 `stock.list`、写 per-stock 表会按池过滤（经 `DataManager.sample_universe`）
- 生成 / 激活样本名单（维护者）：

```bash
python devcli.py ssp 500    # 分层抽样样本名单
python devcli.py pc         # 取消样本名单（清配置侧约定，见 cli 帮助）
```

- 若 DB 里已有池外历史数据，需自行 SQL 清理，例如：

```sql
DELETE FROM sys_data_stock_moneyflow
WHERE id NOT IN (SELECT id FROM sys_data_stock_list);
```

回测选股不靠本文件单独配置：用 ListService 窗口查询，或策略 `sampling` / Tag。详见 `core/modules/data_manager` 文档。

### Worker（`worker.json`）

可覆盖 `core/default_config/worker.json` 中的段（如 tag 的 `job_pipeline`）。策略 / 标签 `settings.py` **不要**写 `performance` 块。

## 注意

- 改配置后通常需**重启**进程才生效
- 可用 `_comment` 字段写注释（程序忽略）
- 默认配置目录：`core/default_config/`（仓库内）；总览见根 [`docs/project_overview.md`](../../../docs/project_overview.md) 与各模块 README
