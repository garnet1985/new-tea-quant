# 输出适配器（`userspace/extensions/adapters/`）

这里是**扫描结果的出口层**：策略先算出机会（`Opportunity` 列表），Adapter 再决定这些机会如何展示或发送到别的地方。

- Strategy 的扫描负责「找机会」
- Adapter 负责「机会之后怎么处理」（打印、推送、落文件、接外部系统等）

当前能力仍偏基础，可按需自扩展。

---

## 一分钟上手（用现有 `console`）

1. 打开策略配置（例如 `userspace/strategies/demo/random/random_v1_null_baseline/settings.py`）
2. 确认 `scanner.adapters` 里包含 `console`
3. 运行扫描：

```bash
python cli.py c --strategy demo/random/random_v1_null_baseline
```

只要策略扫到机会，`console` adapter 就会在终端打印结果。

---

## 从 0 创建一个新 Adapter

### Step 1）创建目录

```text
userspace/extensions/adapters/my_adapter/
├── adapter.py
└── settings.py
```

目录名 `my_adapter` 即策略 `scanner.adapters` 里填写的名字。

### Step 2）写 `settings.py`（可选但推荐）

```python
settings = {
    "name": "my_adapter",
    "format": "json",
}
```

### Step 3）写 `adapter.py`

```python
from typing import Any, Dict, List

from core.modules.adapter.contracts import BaseOpportunityAdapter
from core.modules.strategy.contracts import Opportunity


class MyAdapter(BaseOpportunityAdapter):
    def process(self, opportunities: List[Opportunity], context: Dict[str, Any]) -> None:
        strategy = context.get("strategy_name", "unknown")
        self.log_info(f"[{strategy}] opportunities={len(opportunities)}")
        for opp in opportunities:
            print(f"{opp.stock_id} {opp.stock_name} @ {opp.trigger_date}")
```

### Step 4）在策略里启用

```python
"scanner": {
    "adapters": ["console", "my_adapter"],
}
```

### Step 5）运行验证

```bash
python cli.py c --strategy demo/random/random_v1_null_baseline
```

---

## 当前内置示例

- `console/`：控制台打印 + 历史统计展示
- `example/`：最小示例（json/csv 输出演示）

## 更多说明

- 完整使用说明见 [USER_GUIDE.md](USER_GUIDE.md)
- 模块侧设计见 [core/modules/adapter/README.md](../../core/modules/adapter/README.md)
