#!/usr/bin/env python3
"""
Console Adapter - 控制台输出适配器

职责：
- 在控制台打印扫描结果
- 显示机会信息 + 历史胜率统计（由 strategy 经 context 推送）
"""
from core.infra.cmd_layout import i

from typing import List, Dict, Any

from core.modules.adapter.contracts import BaseOpportunityAdapter
from core.modules.strategy.contracts import Opportunity


class ConsoleAdapter(BaseOpportunityAdapter):
    """控制台输出适配器"""

    def process(
        self,
        opportunities: List[Opportunity],
        context: Dict[str, Any],
    ) -> None:
        date = context.get("date", "unknown")
        strategy_name = context.get("strategy_name", "unknown")
        summary = context.get("scan_summary", {})
        date_meta = (
            context.get("date_meta")
            if isinstance(context.get("date_meta"), dict)
            else {}
        )
        price_history = (
            context.get("price_history")
            if isinstance(context.get("price_history"), dict)
            else {}
        )

        print("\n" + "=" * 80)
        print(f"{i('bar_chart')} 扫描结果 - {strategy_name}")
        print("=" * 80)
        print(f"扫描日期: {date}")
        self._print_date_mode(date_meta)
        print(f"发现机会: {len(opportunities)} 个")
        print(f"涉及股票: {summary.get('total_stocks', 0)} 只")
        print("=" * 80)

        if not opportunities:
            print("\n没有发现任何机会")
            print("=" * 80)
            return

        for i, opp in enumerate(opportunities, 1):
            print(f"\n【机会 {i}】")
            print(f"  股票: {opp.stock_name} ({opp.stock_id})")
            print(f"  触发日期: {opp.trigger_date}")
            print(f"  触发价格: {opp.trigger_price:.2f}")

            if opp.signal_snapshot:
                print(f"  信号快照: {opp.signal_snapshot}")

        print("\n" + "=" * 80)

        show_history = self.get_config("show_history", True)
        if show_history and opportunities:
            self._print_history_statistics(opportunities, price_history)

        print("\n" + "=" * 80)

    @staticmethod
    def _print_date_mode(date_meta: Dict[str, Any]) -> None:
        if not date_meta:
            return
        mode_label = str(date_meta.get("mode_label") or "").strip()
        detail = str(date_meta.get("source_detail") or "").strip()
        if mode_label:
            print(f"日期模式: {mode_label}")
        if detail:
            print(f"日期来源: {detail}")

    def _print_history_statistics(
        self,
        opportunities: List[Opportunity],
        price_history: Dict[str, Any],
    ) -> None:
        print(f"\n{i('bar_chart')} 历史统计信息")
        print("-" * 80)

        session_summary = price_history.get("session_summary")
        if isinstance(session_summary, dict) and session_summary:
            win_rate = session_summary.get("win_rate", 0)
            avg_roi = session_summary.get("avg_roi", 0) * 100

            total_investments = session_summary.get("total_investments", 0)
            total_win = session_summary.get("total_win_investments", 0)
            total_loss = session_summary.get("total_loss_investments", 0)

            print("整体表现:")
            if total_investments > 0:
                print(
                    f"  总投资次数: {total_investments} "
                    f"(盈利: {total_win}, 亏损: {total_loss})"
                )
                print(f"  胜率: {win_rate:.1f}%")
                print(f"  平均收益率: {avg_roi:.2f}%")

                annual_return = session_summary.get("annual_return", 0)
                if annual_return:
                    print(f"  年化收益率: {annual_return:.2f}%")
            else:
                print("  暂无历史投资记录")

        by_stock = price_history.get("by_stock")
        if not isinstance(by_stock, dict):
            by_stock = {}

        stock_stats = {}
        for opp in opportunities:
            stock_id = opp.stock_id
            if stock_id in stock_stats:
                continue
            history = by_stock.get(stock_id)
            if history:
                stock_stats[stock_id] = {
                    "stock_name": opp.stock_name,
                    "history": history,
                }

        if stock_stats:
            print(f"\n按股票统计（共 {len(stock_stats)} 只）:")
            for stock_id, stats in stock_stats.items():
                history = stats["history"]
                stock_name = stats["stock_name"]

                win_rate = history.get("win_rate", 0)
                avg_return = history.get("avg_return", 0)
                completed = history.get("completed_investments", 0)
                win_count = history.get("win_count", 0)
                loss_count = history.get("loss_count", 0)

                win_rate_pct = win_rate * 100
                avg_return_pct = avg_return * 100

                win_icon = i('success') if win_rate >= 0.5 else i('warning')
                return_icon = i('line_chart') if avg_return > 0 else i('downward_trend')

                print(f"  {win_icon} {stock_name} ({stock_id}):")
                print(
                    f"    完成投资: {completed} 次 "
                    f"(盈利: {win_count}, 亏损: {loss_count})"
                )
                print(
                    f"    {return_icon} 胜率: {win_rate_pct:.1f}%, "
                    f"平均收益: {avg_return_pct:.2f}%"
                )

                max_return = history.get("max_return", 0)
                min_return = history.get("min_return", 0)
                if max_return != 0 or min_return != 0:
                    print(
                        f"    收益区间: {min_return*100:.2f}% "
                        f"~ {max_return*100:.2f}%"
                    )
