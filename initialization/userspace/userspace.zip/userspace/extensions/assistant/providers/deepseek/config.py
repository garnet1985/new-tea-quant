PROVIDER = {
    "base_url": "https://api.deepseek.com",
    "model": "deepseek-chat",
    "enabled": True,
}
