PROVIDER = {
    "base_url": "https://api.moonshot.cn/v1",
    "model": "moonshot-v1-8k",
    "enabled": True,
}
