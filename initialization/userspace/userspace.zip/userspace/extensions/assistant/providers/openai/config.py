PROVIDER = {
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4o-mini",
    "enabled": True,
}
