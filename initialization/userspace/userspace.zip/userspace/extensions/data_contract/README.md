# 用户自定义 Contract 示例

## 目录结构

```
userspace/extensions/data_contract/
├── data_keys.py           # 用户自定义 data keys 注册表
├── contract_example/      # contract 示例目录
│   ├── declaration.py     # contract declaration
│   ├── loader.py          # contract loader
│   └── README.md          # 使用说明
└── ...                    # 其他自定义 contract
```

## 使用步骤

### 1. 注册 Data Key

在 `data_keys.py` 中定义 USER_DATA_KEY 类：

```python
class USER_DATA_KEY:
    MY_CUSTOM_DATA = "my.custom.data"
    MY_FINANCE_DATA = "my.finance.data"
    
    @classmethod
    def all_keys(cls) -> list:
        return [cls.MY_CUSTOM_DATA, cls.MY_FINANCE_DATA]
```

### 2. 创建 Contract 目录

为每个自定义 contract 创建一个目录：

```
contract_example/
├── declaration.py  # 必需
├── loader.py       # 必需
└── README.md       # 可选
```

### 3. 定义 Declaration

在 `declaration.py` 中定义 contract declaration：

```python
from userspace.extensions.data_contract.data_keys import USER_DATA_KEY

MY_CUSTOM_DATA_DECLARATION = {
    "meta": {
        "key": USER_DATA_KEY.MY_CUSTOM_DATA,  # 使用常量，避免硬字符串
        "type": "non_time_series",  # 或 "time_series"
        "scope": "global",  # 或 "per_entity"
        "display_name": "我的自定义数据",
        "description": "用户自定义数据的示例",
        "loader": None,  # 在 loader.py 中定义
    },
    "params": {
        "data_source": "custom_source",
    },
}
```

### 4. 实现 Loader

在 `loader.py` 中实现数据加载逻辑：

```python
from core.modules.data_contract.core.base.base_loader import BaseDataContractLoader

class MyCustomDataLoader(BaseDataContractLoader):
    def load(self, params):
        # 实现数据加载逻辑
        return [{"id": "xxx", "value": 123}, ...]
    
    def load_batch(self, entity_ids, params):
        # 批量加载（per_entity scope 需要）
        return {"entity_id": data}
```

### 5. 使用 Contract

```python
from core.modules.data_contract import ContractIssuer, DATA_KEY

# 加载自定义数据
contract = ContractIssuer.issue(DATA_KEY.MY_CUSTOM_DATA, fill_in_data=True)
data = contract.get_data()
```

## 注意事项

1. **必须使用常量**：declaration.py 中的 `meta.key` 必须使用 `USER_DATA_KEY.xxx`，避免硬字符串
2. **注册验证**：如果 key 没有在 USER_DATA_KEY 中注册，discovery 时会报错
3. **命名规范**：key 使用点分隔符（如 "my.custom.data"）
4. **目录命名**：contract 目录名建议与 key 最后部分一致（如 "my_custom_data"）

## 错误提示示例

如果 key 未注册，会收到清晰的错误提示：

```
您的 contract key 'xxx' 没有在 userspace/data_keys.py 的 USER_DATA_KEY 类中枚举注册，
请按照 SYS_DATA_KEY 的方式在 USER_DATA_KEY 中添加对应的常量。
示例：class USER_DATA_KEY:
    MY_CUSTOM_DATA = 'xxx'  # 在此处添加
```

## 参考系统 Contract

查看系统 contract 示例：
- `core/modules/data_contract/core/data_contracts/stock_list/`
- `core/modules/data_contract/core/data_contracts/stock_kline_daily/`