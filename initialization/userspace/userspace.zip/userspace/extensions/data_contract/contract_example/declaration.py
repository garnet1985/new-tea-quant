"""用户自定义 contract declaration 示例。

使用说明：
- meta.key 必须使用 USER_DATA_KEY.xxx（避免硬字符串）
- type: "time_series" 或 "non_time_series"
- scope: "global" 或 "per_entity"
- loader 必须继承 BaseDataContractLoader
"""

from core.modules.data_contract.contracts import SYS_DATA_KEY
from userspace.extensions.data_contract.data_keys import USER_DATA_KEY

# 示例：自定义数据 contract declaration
MY_CUSTOM_DATA_DECLARATION = {
    "meta": {
        "key": USER_DATA_KEY.MY_CUSTOM_DATA,  # 使用常量，避免硬字符串
        "type": "non_time_series",  # 或 "time_series"
        "scope": "global",  # 或 "per_entity"
        "display_name": "我的自定义数据",
        "description": "用户自定义数据的示例",
        "loader": None,  # 需要在 loader.py 中定义
    },
    
    # params（可选）：loader 需要的参数
    "params": {
        # 示例参数
        "data_source": "custom_source",
    },
    
    # specific（可选）：contract 特有字段
    "specific": {
        # 示例：特有字段
        "source": "custom",
    },
}

__all__ = ['MY_CUSTOM_DATA_DECLARATION']