"""用户自定义 contract loader 示例。

使用说明：
- 必须继承 BaseDataContractLoader
- 实现 load() 方法（单个 entity）
- 实现 load_batch() 方法（多个 entity，可选）
"""

import logging
from typing import Dict, Any, List

from core.modules.data_contract.contracts import BaseDataContractLoader

logger = logging.getLogger(__name__)


class MyCustomDataLoader(BaseDataContractLoader):
    """自定义数据 loader 示例。"""
    
    def load(self, params: Dict[str, Any]) -> Any:
        """加载单个数据。
        
        Args:
            params: loader 参数（从 declaration.params + runtime 合并）
            
        Returns:
            数据（格式根据 contract 定义）
        
        示例：
            # Global scope
            return [{"id": "xxx", "value": 123}, ...]
            
            # Per entity scope
            return [{"date": "20200101", "value": 123}, ...]
        """
        logger.info(f"加载自定义数据: params={params}")
        
        # 示例：从文件或数据库加载数据
        # TODO: 实现实际的数据加载逻辑
        
        # 示例数据
        data = [
            {"id": "example_1", "value": 100, "description": "示例数据1"},
            {"id": "example_2", "value": 200, "description": "示例数据2"},
        ]
        
        return data
    
    def load_batch(self, entity_ids: List[str], params: Dict[str, Any]) -> Dict[str, Any]:
        """批量加载多个 entity 的数据。
        
        Args:
            entity_ids: Entity ID 列表
            params: loader 参数
            
        Returns:
            Dict[entity_id: data] 格式的数据
        
        注意：
        - 只有 per_entity scope 的 contract 才需要实现
        - 如果不实现，系统会默认调用 load() 多次
        """
        logger.info(f"批量加载自定义数据: entity_ids={entity_ids}, params={params}")
        
        # 示例：批量加载
        data_dict = {}
        for entity_id in entity_ids:
            # TODO: 实现实际的批量加载逻辑
            data_dict[entity_id] = [
                {"date": "20200101", "value": 100},
                {"date": "20200102", "value": 110},
            ]
        
        return data_dict


__all__ = ['MyCustomDataLoader']