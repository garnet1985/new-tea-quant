# 申万行业 + 个股资金流：数据层与 Trend Demo 实施计划

**状态：** 已决策，待实现  
**记录日期：** 2026-06-14  
**读者：** 后续负责接数据 handler / 表 / `demo/trend/` 策略的 agent 或开发者  

本文档汇总行业分类与资金流向相关的调研结论与**唯一推荐技术路线**。实现时请以此为准，避免再接 `stock_basic.industry`、`moneyflow_ind_ths` 等与主口径混用的数据源。

**相关文档：**

- [DEMO_CURRICULUM.md](../../../strategies/demo/DEMO_CURRICULUM.md) — 演示策略课程表（§3.3 趋势族）
- [STOCK_DIMENSIONS.md](../../../../core/modules/data_manager/docs/STOCK_DIMENSIONS.md) — 现有 `sys_industries` / `sys_boards` 说明
- [Data Source DESIGN.md](../../../../core/modules/data_source/docs/DESIGN.md) — handler / config 约定

---

## 1. 背景：为什么乱

Tushare 内并存多套「行业 / 板块」口径，**不能按名字硬 join**：

| 来源 | 含义 | 与策略主维度的关系 |
|------|------|-------------------|
| `stock_basic.industry` → 现有 `sys_industries` | Tushare 扁平粗分类（~110 名） | ❌ 无行业资金流 API；与同花顺/申万对不齐 |
| `stock_basic.market` → 现有 `sys_boards` | 上市板块（主板/创业板/科创板/北交所） | ✅ 保留，语义清晰，与行业无关 |
| 同花顺 `moneyflow_ind_ths` + `ths_member` | ~90 个 THS 行业板块 | 可选，但需 6000 积分且与申万是另一套 |
| 东财 `moneyflow_ind_dc` + `dc_member` | 行业+概念+地域混合 | 可选，维护成本高 |
| **申万 2021** `index_classify` + `index_member_all` | 31 / 134 / 346 层级 | ✅ **选定为主行业体系** |

社区惯例（Tushare 教程 Issue、BigQuant 等）：严肃行业分析用**申万**；`stock_basic.industry` 仅作展示粗标签。

---

## 2. 已决策方案（一句话）

**申万 2021 做行业主数据 + `sw_daily` 看行业热度 + 个股 `moneyflow` 做资金确认；暂不聚合行业净流入。**

不维护 THS/东财/`stock_basic.industry` 作为 trend 策略维度。

---

## 3. 明确不做的事

| 项 | 原因 |
|----|------|
| 用 `sys_industries` 对接板块资金流 | 名字与申万/THS/东财均对不齐 |
| 默认接 `moneyflow_ind_ths` | 与申万成分两套口径；非「大家认可的分类」 |
| 用 `activity-ratio20` Tag 做 trend v1 主信号 | 20 日成交额 MA 过慢，用户已否决 |
| 现阶段做「按申万 SUM 个股 net_mf_amount」聚合表 | 用户接受暂不聚合；v1 用 `sw_daily` + 个股 `moneyflow` 即可 |
| 把 doc 293/294 当行业 API | `cyq_perf` / `cyq_chips` 是**个股筹码**，与行业无关 |

---

## 4. Tushare API 清单（本方案仅用这些）

### 4.1 行业分类与映射（2000 积分）

| 文档 | 接口 | 用途 |
|------|------|------|
| [doc 181](https://tushare.pro/document/2?doc_id=181) | `index_classify` | 申万 2021 行业树；`src='SW2021'`，`level` = L1/L2/L3 |
| [doc 335](https://tushare.pro/document/2?doc_id=335) | `index_member_all` | 股票 ↔ 申万 L1/L2/L3；含 `in_date` / `out_date` / `is_new` |

示例：

```python
pro.index_classify(level='L1', src='SW2021')
pro.index_member_all(ts_code='000001.SZ')
pro.index_member_all(l3_code='850531.SI')
```

### 4.2 行业指数日线（5000 积分）

| 文档 | 接口 | 用途 |
|------|------|------|
| [doc 327](https://tushare.pro/document/2?doc_id=327) | `sw_daily` | 申万行业指数：`pct_change`、`amount`（成交额）、`pe`、`pb`、`total_mv` 等 |

**注意：** `sw_daily` 提供的是行业指数**行情/成交额**，**没有**净流入字段。行业「热度」用 `pct_change` / `amount`，资金用个股 `moneyflow`。

按 `trade_date` 一次可拉当日全部申万指数行（需过滤 L1/L2/L3，可与 `index_classify` 的 `index_code` 对齐，格式 `801xxx.SI`）。

### 4.3 个股资金流（2000 积分）

| 文档 | 接口 | 用途 |
|------|------|------|
| [doc 170](https://tushare.pro/document/2?doc_id=170) | `moneyflow` | 全市场个股 `net_mf_amount`（万元），2010 年起；大/中/小/特大单 |

Provider 现状：仅封装了 `get_moneyflow_ind_ths`；**需新增 `get_moneyflow`**（及可选 `get_sw_daily`、`get_index_classify`、`get_index_member_all`）。

### 4.4 与本方案无关但用户曾提到的 API

| 文档 | 接口 | 说明 |
|------|------|------|
| [doc 293](https://tushare.pro/document/2?doc_id=293) | `cyq_perf` | 个股筹码胜率；5000 积分；**future v2+ 可选** |
| [doc 294](https://tushare.pro/document/2?doc_id=294) | `cyq_chips` | 个股筹码分布；数据量大 |

---

## 5. 建议落库表（4 张）

遵循现有模式：`core/tables` 或 `userspace/extensions/tables` + `userspace/extensions/data_source/handlers/<name>/`。

### 5.1 `sys_sw_industry`（字典，低频 refresh）

来源：`index_classify(src='SW2021')`，L1/L2/L3 均可入库，建议字段：

| 字段 | 说明 |
|------|------|
| `index_code` | 主键，如 `801010.SI` |
| `industry_name` | 行业名 |
| `level` | L1 / L2 / L3 |
| `parent_code` | 父级 index_code（L1 可为空） |
| `is_pub` | 是否发布指数（classify 返回） |
| `last_update` | 同步时间 |

`update_key` 建议：`stock_sw_industry`。

### 5.2 `sys_sw_stock_map`（股票 ↔ 申万，周更或随 stock_list）

来源：`index_member_all(is_new='Y')` 或全量带历史。

| 字段 | 说明 |
|------|------|
| `stock_id` | `ts_code` |
| `l1_code` / `l1_name` | 一级 |
| `l2_code` / `l2_name` | 二级 |
| `l3_code` / `l3_name` | 三级 |
| `in_date` / `out_date` | 纳入/剔除（回测 PIT 用） |
| `is_new` | Y/N |

主键策略：`(stock_id, l3_code)` 或 `(stock_id, is_new)` 视是否保留历史而定。  
**回测严谨性：** 应用 `trade_date` 落在 `[in_date, out_date]` 的映射（`index_member_all` 支持历史字段）。

`update_key` 建议：`stock_sw_stock_map`。

### 5.3 `sys_stock_moneyflow`（日更）

来源：`moneyflow(trade_date=...)` 全市场。

| 字段 | 说明 |
|------|------|
| `stock_id` | `ts_code` |
| `trade_date` | YYYYMMDD |
| `net_mf_amount` | 净流入额（万元） |
| 可选 | `buy_lg_amount`、`sell_lg_amount` 等，按策略需要 |

主键：`(stock_id, trade_date)`。  
`update_key` 建议：`stock_moneyflow`。  
renew：按交易日 global 一次（~5000–6000 行/日）。

### 5.4 `sys_sw_daily`（日更）

来源：`sw_daily(trade_date=...)`。

| 字段 | 说明 |
|------|------|
| `index_code` | `ts_code` from API |
| `trade_date` | |
| `name` | 指数名称 |
| `pct_change` | 涨跌幅 |
| `amount` | 成交额（万元） |
| 可选 | `close`、`vol`、`pe`、`pb`、`total_mv` |

主键：`(index_code, trade_date)`。  
策略侧筛 **L1** 时：join `sys_sw_industry` where `level='L1'`。  
`update_key` 建议：`stock_sw_daily`。

---

## 6. Handler / Provider 待办（给实现 agent）

### 6.1 Provider（`userspace/extensions/data_source/providers/tushare/provider.py`）

| 方法 | Tushare API | `api_limits` 建议 |
|------|-------------|-------------------|
| `get_index_classify` | `index_classify` | 200/min（宏观类） |
| `get_index_member_all` | `index_member_all` | 200/min |
| `get_sw_daily` | `sw_daily` | 200/min |
| `get_moneyflow` | `moneyflow` | 200/min 或沿用宏观 200 |

已有：`get_moneyflow_ind_ths` — **trend 线不必用**，可保留给别处。

### 6.2 Handler 草图

| Handler 目录 | 表 | renew 类型 |
|--------------|-----|------------|
| `sw_industry` | `sys_sw_industry` | `refresh`（低频） |
| `sw_stock_map` | `sys_sw_stock_map` | `refresh` |
| `stock_moneyflow` | `sys_stock_moneyflow` | 按日 `global` / `date_range` |
| `sw_daily` | `sys_sw_daily` | 按日 `global` |

参考现有：`handlers/stock_list/`（维度映射）、`handlers/gdp/`（简单 pass-through）。

### 6.3 DataContract / DataKey

需在 `core/modules/data_contract/` 增加键，例如（命名待与 `contract_const.py` 风格统一）：

- `stock.sw.industry` 或 `stock.industry.sw`
- `stock.sw.map` / 成分映射
- `stock.moneyflow.daily`
- `stock.sw.daily`

实现 agent 应阅读现有 `stock.kline.daily` 拆分方式，保持 `data.base / data.required` / `extra_required_data_sources` 一致。

### 6.4 `stock_list` handler

- **不删除** `industry` → `sys_industries` 写入（兼容展示、`load_with_latest_price`）。
- **文档注明：** 策略行业过滤应读 `sys_sw_*`，不读 `sys_industries`。
- 长期可选：在 `STOCK_DIMENSIONS.md` 标注 `sys_industries` 为 legacy display。

---

## 7. Trend Demo 策略逻辑（规划，替代原 activity-ratio20 方案）

目录规划（更新 DEMO_CURRICULUM §3.3）：

| 路径 | 状态 | 逻辑 |
|------|------|------|
| `demo/trend/sw_hot_v1_sector_pool` | ⬜ | `sw_daily` L1 按 `pct_change` 或 `amount` Top N → `sys_sw_stock_map` 成分池 → `moneyflow.net_mf_amount > 0` → 可选 `close > pre_close` |
| `demo/trend/sw_hot_v2_volume_confirm` | ⬜ | v1 + `stock.indicators.daily`（如 `volume_ratio`） |
| `demo/trend/sw_hot_v3_trailing_exit` | ⬜ | v2 + `goal.dynamic_loss` / 移动止盈（对照 `bb_v3_managed_exit`） |

**叙事：** 自上而下（申万行业热度）+ 个股资金确认；不说「行业净流入 XX 亿」。

**对照实验：** 与同区间 `demo/regression/rsi/rsi_v1_without_value_anchor`（抄底）对比。

**Tag：** 可选后续 `sector-sw-rank` 通用场景；**不用** `activity-ratio20` 作主信号。

---

## 8. 数据流（实现时对照）

```text
                    index_classify (SW2021)
                            │
                            ▼
                    sys_sw_industry
                            │
         index_member_all   │
                ┌───────────┴───────────┐
                ▼                       │
        sys_sw_stock_map                │
                │                       │
    trade_date  │                       │ trade_date
                ▼                       ▼
         moneyflow ──────────►   sys_stock_moneyflow
                │                       │
                │              sw_daily │
                │                       ▼
                │               sys_sw_daily
                │                       │
                └───────────┬───────────┘
                            ▼
                  trend strategy worker
                  (行业 Top N → 成分股 → 个股资金流过滤)
```

---

## 9. 积分与调用量（估算）

| API | 最低积分 | 日 renew 量级 |
|-----|----------|---------------|
| `index_classify` | 2000 | 极低（月/季） |
| `index_member_all` | 2000 | 低（周）；全市场可按股票循环 |
| `moneyflow` | 2000 | 1 次/交易日（全市场） |
| `sw_daily` | 5000 | 1 次/交易日 |

用户 token 已验证可调用 `moneyflow`、`moneyflow_ind_ths` 等；实现前再测 `index_classify` / `index_member_all` / `sw_daily`。

---

## 10. 实现检查清单（Copy for agent）

- [x] 表 schema：`sys_stock_moneyflow`（`core/tables/stock/stock_moneyflow/`）
- [x] TushareProvider `get_moneyflow`
- [x] handler `stock_moneyflow` + `DATA_SOURCES` mapping
- [x] DataKey `stock.moneyflow.daily` + loader + `dm.stock.moneyflow`
- [ ] CLI renew：`python cli.py r <handler_key>` 文档
- [ ] 更新 [DEMO_CURRICULUM.md](../../../strategies/demo/DEMO_CURRICULUM.md) §3.3 路径与叙事
- [ ] 实现 `demo/trend/sw_hot_v1_*` settings + worker
- [ ] 测试：样本股申万映射 + 单日 moneyflow + sw_daily join 冒烟

### 刻意延后

- [ ] 按申万层级聚合 `sys_sw_industry_moneyflow`（SUM `net_mf_amount`）
- [ ] 废弃或迁移 `sys_industries` 策略引用
- [ ] `cyq_perf` 筹码过滤
- [ ] THS / 东财板块线

---

## 11. 现有代码锚点

| 区域 | 路径 |
|------|------|
| stock_list 维度写入 | `userspace/extensions/data_source/handlers/stock_list/` |
| Tushare Provider | `userspace/extensions/data_source/providers/tushare/provider.py` |
| 行业维度文档 | `core/modules/data_manager/docs/STOCK_DIMENSIONS.md` |
| BB v3 出场参考 | `userspace/strategies/demo/regression/bb/bb_v3_managed_exit/` |
| DataKey 常量 | `core/modules/data_contract/contract_const.py` |

---

## 12. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-06-14 | 初版：申万 + moneyflow + sw_daily；不聚合；否决 THS/stock_basic.industry/activity-ratio20 主路线 |
