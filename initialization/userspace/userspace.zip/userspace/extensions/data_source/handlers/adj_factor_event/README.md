# Adj Factor Event Handler 文档

**版本**: 2.4  
**最后更新**: 2026-06-11（L0 交易日门控 + L1 窄窗 factor 探测）

## 概述

`AdjFactorEventHandler` 负责计算和存储股票的复权因子事件数据。复权因子事件记录了股票除权除息日期的复权因子变化，用于后续的 K 线数据复权计算。

## 数据源信息

- **数据源名称**: `adj_factor_event`
- **框架 renew 类型**: `incremental`（每股写库为 touch / append / 全量 refresh，见下文）
- **数据格式**: 事件数据（按除权日期记录）
- **API 提供方**:
  - Tushare (`adj_factor` 接口)
  - Tushare (`daily_kline` 接口，用于获取原始收盘价)
  - **AKShare / 腾讯财经** (`stock_zh_a_hist_tx`，`adjust="qfq"`，经 `AKShareProvider.get_qfq_kline`)
- **API 限流**:
  - Tushare `adj_factor`: 800 次/分钟
  - Tushare `daily_kline`: 700 次/分钟
  - **AKShare `get_qfq_kline`**: 80 次/分钟（腾讯接口，限流较东财宽松）

> **说明**：东方财富 `EastMoneyProvider.get_qfq_kline` 仍可用于日历等场景，但本 Handler **不**使用东财作为前复权 SOT。新浪 `SinaProvider.get_daily_kline` 为**未复权**日线，不参与本 Handler。

## 数据表结构

### 主键
- `(id, event_date)` 复合主键
  - `id`: varchar(16) - 股票代码（如 "000001.SZ"）
  - `event_date`: varchar(16) - 除权日期（YYYYMMDD 格式）

### 数据字段（`core/tables/stock/adj_factor_events/schema.py`）

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | varchar(16) PK | 股票代码 |
| `event_date` | varchar(8) PK | 事件日 YYYYMMDD |
| `factor` | DECIMAL(12,4) | Tushare 绝对 F(t) |
| `qfq_anchor` | DECIMAL(12,3) | 事件日前复权价快照 |
| `raw_anchor` | DECIMAL(12,3) | 事件日 raw 快照 |
| `qfq_diff` | DECIMAL(12,4) | 可选缓存 delta |

精度由 handler 内 `precision.py`（Tushare/AKShare 爬取边界，**非** tables/infra）处理；默认见 `core/default_config/data.json` → `decimal_places.adj_factor_event`，用户可在 `userspace/system/config/data.json` 覆盖 `factor_places` / `price_places` / `diff_places`，写库前经 `normalize_event_row` 舍入。
| `last_update` | datetime NULL | renew 门控时间戳 |

索引：`idx_id`、`idx_event_date`、`idx_id_last_update`（+ 主键）

### 消费公式（KlineService，方案 B）

**主路径**（贴近腾讯、支持 incremental append；实现见 `core/.../kline_service.py`）：

```text
qfq(t) = raw(t) × F(段) / F(最新) + C

C = qfq_anchor_最新 - raw_anchor_最新 × F_最新事件 / F(最新)
```

- `F(段)`：当日生效复权事件（`event_date ≤ t` 的最近一条）的 `factor`。
- `F(最新)`：**消费时**该股最新事件的 `factor`（append 新除权后自动更新，历史 anchor 行无需重写）。
- `C`：**仅**用最新一条事件的 `qfq_anchor` / `raw_anchor` 折算；老事件的 anchor 入库留档，**不参与定价**。
- 段内涨跌斜率由 Tushare 因子链（`F(段)/F(最新)`）承担；`C` 修正 Tushare 乘积与腾讯 qfq 的系统性平移，并在 append 时随最新 anchor 整体重定标（类似腾讯全历史重算）。

**应急 fallback**（非主路径）：

```text
qfq(t) = raw(t) × F(段) / F(最新) + qfq_diff
```

- 仅当**最新**复权事件缺少 `qfq_anchor` 或 `raw_anchor` 时，回退段内 `qfq_diff`（旧 CSV / 迁移数据）。

**与旧 per-segment anchor 的区别**（v2.2–v2.4 曾用）：

```text
# 已废弃于消费端（会导致 append 后老段相对腾讯漂移、除权断崖）
qfq(t) = qfq_anchor_段 + (raw(t) - raw_anchor_段) × F(段) / F(最新)
```

验证：`experiments/qfq_baseline/方案B_tencent_validation.json`（系统 `load_qfq_split` vs AKShare 腾讯 qfq）。

## 核心算法

### 复权因子计算原理

复权因子事件的计算基于以下数据源：

1. **Tushare `adj_factor`**: 提供每个交易日的复权因子（相对于上市首日）
2. **Tushare `daily_kline`**: 提供原始收盘价（未复权）
3. **腾讯前复权 K 线**（经 AKShare）: 提供前复权收盘价（`adjust="qfq"`）

**入库逻辑**（每个事件日）:
- 找出所有 `adj_factor` 发生变化的日期（除权除息日）
- 获取事件日 `raw_anchor`（Tushare daily_kline，非交易日向前找最近交易日）
- 获取事件日 `qfq_anchor`（腾讯 qfq K 线，非交易日向前找最近交易日）
- 缓存 `qfq_diff = qfq_anchor - raw_anchor × F(段) / F(最新入库时)`

**特殊处理**:
- **第一根 K 线日期**: 即使没有 `adj_factor` 变化，也会为第一根 K 线日期创建一个事件
- **非交易日处理**: 事件日非交易日时，raw/qfq 均向前找最近交易日
- **整股 qfq 缺失**: 若腾讯 qfq 解析后为空，**跳过该股票**（不写库、不更新 `last_update`）
- **单事件 qfq 缺失**: 该事件 `qfq_anchor=None`；无 anchor 时无法 append，需 refresh 补齐

## 数据更新策略

### 设计目标

1. **最小化腾讯 API 调用**（主要瓶颈，80 次/分钟）
2. **Tail append**：新除权只追加尾部事件，不重写历史 anchor
3. **`last_update` 语义**：记录「上次检查到哪天」，而非「上次除权是哪天」

### 四层漏斗（L0→L3，v2.4）

依赖 `mapping.py` 中的 `latest_completed_trading_date`（保留依赖 → `context["latest_completed_trading_date"]`）；交易日判断走 DB `sys_trade_calendar`（不每股打 API）。

```text
L0（Handler on_after_build_jobs；已关闭框架 renew_if_over_days，避免与交易日门控重复）
  每股 MAX(last_update) + 交易日历 → 筛 renew 候选（掉队股）
  → 候选 0 股 → 整 job 0 API
  → 候选 N 股 → 仅这 N 股建 adj_factor job（其余跳过）

L1（窄窗 Tushare adj_factor + has_factor_change_in_range）
  探测窗 = [上次已检查开市日的下一开市日, latest]
  → 窗内无 factor 变化 → 只戳 last_update，0 次腾讯

L2（有变化：扩展 adj_factor 至最早 event_date + 前链校验）
  verify_event_chain_prefix
    → 前链不一致 / 无 anchor → 全量 refresh（3 API）

L3（前链一致 + 有尾部新事件）
  → 窄窗 raw（``sys_stock_klines`` 优先，不足 fallback Tushare daily）+ 腾讯 qfq → append 尾部
  → 无尾部 → 只戳 last_update
```

前链校验**只靠 Tushare**；尾部 append 才按需打腾讯。

#### 为什么用 `last_update` 而不是 `last_event_date`

| 场景 | 用 `last_event_date` | 用 `last_update` |
|------|---------------------|------------------|
| 10 天前除权，5 天前 renew 确认无新事件 | 仍探测 10 天窗口 | 只探测最近 5 天 |
| 今天已跑过 renew | 可能仍进任务 | 第一层直接跳过 |
| 表达「这段已查过」 | 否 | 是 |

示例：上次除权在 10 天前，但 `last_update` 在 5 天前（当时已探测 10→5 天区间）。今日 renew 只需 Tushare 查 `[5天前, today]`；无新除权则只戳 `last_update`，不打腾讯。

### 写库模式：append vs refresh

| 条件 | 行为 |
|------|------|
| 库中前缀 `(event_date, factor)` 与重建结果一致，且全部行有 anchor，尾部有新事件 | **append** 仅写尾部 |
| 无历史 / 无 anchor / 前缀不一致 / Tushare 历史修正 | **refresh**：`delete` 该股 + 全量 `save` |
| `renew -f`（`force_refresh`） | 一律全量拉取 + refresh |

### API 调用范围（已实现）

| 场景 | bundle adj_factor | daily + 腾讯 qfq |
|------|-------------------|------------------|
| L0 renew 候选 0 股 | 0 | 0 |
| 日常 incremental（L1 无变化） | 窄窗（1 次/股） | 0 |
| 日常 incremental（L3 有尾部） | 窄窗探测 + 必要时扩展前链 | raw：DB 或 Tushare；qfq：腾讯窄窗 ±7 日 |
| 前链失败 / 无 anchor / 新股 | 全历史 | save 阶段全量拉取后 refresh |
| `renew -f` | 全历史 | bundle 内全量 |

日常多数股票：**1 次窄窗 Tushare adj_factor + 0 次腾讯**。

### 更新流程

#### 步骤 0: CSV 导入（表为空时）

- 表为空且存在有效季度 CSV 时，从 CSV 冷启动（`DataAdjFactorEventModel.import_from_csv`）
- CSV 格式：`id`, `event_date`, `factor`, `qfq_anchor`, `raw_anchor`, `qfq_diff`, `last_update`
- **契约过滤**（`data.json`）：
  - `use_sample_stock_list`：仅保留池内 `id`；池内缺股允许，renew 补全
  - `as_of_latest_completed_trading_date`：丢弃更晚事件；已导入股戳 `last_update` 至 as_of（除权日稀疏，`max(event)<as_of` 仍 L0 跳过）
  - `default_start_date` + `sys_stock_list.list_date`：老股须 `min(event_date) <= default_start`；窗口内新股（`list_date > default_start`）首笔除权可晚于上市日；起点未覆盖的股**跳过**，其余照常导入（renew 全量 refresh 补）
- 导出范围：默认 **库内 MIN(event_date) ~ MAX(event_date)**（全量，非写死 2020）

#### 步骤 1: 创建 ApiJobs + Handler L0

- 框架 `incremental` 建 job；**L0 交易日门控**筛 renew 候选（不用 `renew_if_over_days`）
- 日常 bundle **仅含** `adj_factor`；`renew -f` 含 3 个 API

#### 步骤 2: Tushare 前链校验（`helper.verify_event_chain_prefix`）

1. 从 adj_factor 构建期望链 `build_event_factor_chain`
2. 与库内 `(event_date, factor)` 前缀比对
3. 计算尾部新链节 `tail_keys = expected[len(existing):]`

#### 步骤 3: 分支保存

| 分支 | 动作 |
|------|------|
| 无历史 / 前链失败 / 无 anchor | `_save_full_refresh`：全量 daily+qfq → delete+save |
| 前链一致、无尾部 | `update_adj_factor_last_update` |
| 前链一致、有尾部 | 窄窗 daily+qfq → `build_events_for_chain_keys` → append |

#### 步骤 4: CSV 导出（`on_after_normalize`）

- 按季度导出备份 CSV

## 配置参数

见 `config.py`：

- `renew.type`: **`incremental`**
- `renew.last_update_info.date_field`: `last_update`
- ~~`renew_if_over_days`~~：已移除，由 Handler L0（交易日历）替代
- `save_mode`: `immediate`
- `apis.qfq_kline.provider_name`: **`akshare`**

## 数据质量保证

- `adj_factor` 或 `daily_kline` 为空 → 跳过该股票，**保留旧数据，不更新 `last_update`**
- `qfq_kline` 解析后为空 → 跳过该股票（同上）
- 某事件日无原始收盘价 → 跳过该事件（不写入该行）
- 非交易日事件日 → `get_raw_price_for_date` / `get_qfq_price_for_date` 向前找最近交易日

## 消费端（KlineService）

- **方案 B**：`raw×F(段)/F(最新)+C`，`C` 由**最新事件** anchor 折算（见上文公式）。
- 各事件 `qfq_anchor` / `raw_anchor`：入库与 append 校验用；定价只用最新一条。
- 最新事件缺 anchor → 应急回退 `qfq_diff`。
- `strict=False`（默认）：查询起点前无事件时，用该股**最早事件**向前补偿（`is_inferred=True`）。

## 失败案例与处理策略

以下为需要产品/实现层面达成共识的场景（§ 表示建议在实现第二层 renew 时一并处理）。

### A. API 拉取失败

| 案例 | 当前行为 | 建议 |
|------|----------|------|
| Tushare `adj_factor` 空/超时 | 跳过该股，旧数据保留 | 不更新 `last_update`，次日 `renew_if_over_days` 后重试 |
| Tushare `daily_kline` 空/超时 | 同上 | 同上 |
| 腾讯 qfq 空/限速 | 同上 | 同上；**有探测到新除权但腾讯失败时，切勿更新 `last_update`**，否则会漏补 |
| AKShare 解析异常 | 视为 qfq 空，跳过 | 同上 |

### B. 部分成功 / 数据不一致

| 案例 | 风险 | 建议 |
|------|------|------|
| Tushare 探测有新除权，但仅拉了窄窗 adj_factor 去做 refresh | **delete 后只剩窄窗事件，历史丢失** | refresh fallback 必须回退全量 3 API；窄窗仅用于「无变化」或「append 成功」路径 |
| Tushare 修正历史 `factor`（前缀 `(event_date, factor)` 不一致） | append 失败 → refresh | 接受 per-stock 全量 refresh；可打日志标记 `factor_revision` |
| 单事件无 `raw_anchor`（raw 缺失） | 该事件不入库 | 若为新除权日，尾部缺一行；下次全量 refresh 补齐 |
| 单事件 `qfq_anchor=None` | 行可能入库但无 anchor | `events_support_append` 为 false，下次走 refresh |

### C. `last_update` 语义边界

| 案例 | 说明 | 建议 |
|------|------|------|
| 探测区间无新除权 | 应只戳 `last_update` | 已实现 `update_last_update_for_stock()`；探测路径需调用 |
| 探测区间有除权但已在库中（重复跑同一天） | `split_append_tail` → tail 为空 | 仍应更新 `last_update`，避免每日重复探测 |
| `last_update` 为 NULL（新导入 CSV 无戳） | 框架视为需更新 | 走全量 refresh 并写入 anchor |
| `last_update` 日历日 = today，但 job 因其他原因失败 | 第一层可能明天才再进 | 失败时不更新 `last_update`（与 A 一致） |

### D. 消费 / 回测侧

| 案例 | 影响 | 说明 |
|------|------|------|
| 库内无该股任何事件 | 未复权 raw | 正常 |
| 仅有 legacy 行（无 anchor） | 用 `qfq_diff` + 动态 `F(最新)` | 新除权 append 后 offset 可能对 legacy 段略偏，需 `-f` 迁移 |
| 最早事件向前 fallback（`strict=False`） | 用 earliest 的 anchor 动态 offset | 与 `qfq_diff` 存法无关；append 后 `F(最新)` 变更有利 |
| anchor 动态 offset vs 存 `qfq_diff` 性能 | 每段多一次 float 运算 | 相对 DB IO 可忽略（见实验 `kline_batch_io`） |

### E. 运维

| 案例 | 操作 |
|------|------|
| 迁移加列 `qfq_anchor` / `raw_anchor` | `ALTER TABLE` 后 `renew sys_adj_factor_events -f` |
| 怀疑整表公式/数据源切换 | 季度 CSV 备份 + `-f` 全量 |
| 单股数据可疑 | 对该股 `-f` 或 delete 后重爬 |

## 依赖关系

- **数据源依赖**: 无
- **数据库**: `sys_adj_factor_events`、`sys_stock_klines`（可选，窄窗 raw 来源）

## 注意事项

1. **建表**：删表后由框架 `create_table` 或 migration 按 schema 重建；勿依赖旧 CSV（无 anchor 列会触发 refresh 补齐）。
2. **旧 CSV / 旧 `qfq_diff` 定义**：须全量 refresh 后再用 anchor 消费。
3. **腾讯 vs 东财**：本 Handler 以腾讯为 SOT。
4. **`last_update` ≠ `last_event_date`**：renew 探测起点用前者（v2.3）。

## 版本历史

- **v2.5** (2026-06-11):
  - 消费端改为**方案 B**：`raw×F(段)/F(最新)+C`，`C` 仅由最新事件 anchor 折算；per-segment anchor 不再用于定价
  - 目的：append incremental 的同时贴近腾讯 qfq，避免老段漂移与除权断崖
- **v2.3** (2026-06-08):
  - `renew.type` 改为 `incremental`；日常 bundle 仅 adj_factor
  - Tushare 前链校验 `verify_event_chain_prefix`；尾部窄窗 append
  - 异常降级全量 refresh（save 阶段拉全量 daily+qfq，禁止窄窗 delete+save）
  - 失败不写库、不戳 `last_update`（有尾部待补时）
- **v2.2** (2026-06-08):
  - 新增 `qfq_anchor` / `raw_anchor`；消费端动态 offset，支持 tail append
  - 估算模型不变：`raw×F段/F最新 + offset`
- **v2.1** (2026-06-08):
  - 前复权 SOT 明确为腾讯财经（AKShare `stock_zh_a_hist_tx`）
  - `qfq_diff` 语义统一为：外部 qfq - raw×F(段)/F(最新)
- **v2.0** (2025-12-23):
  - 全量 API 调用模式、immediate 保存、CSV 备份
