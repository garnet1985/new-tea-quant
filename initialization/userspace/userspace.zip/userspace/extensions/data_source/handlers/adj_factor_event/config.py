"""
Adj Factor Event Handler 配置。绑定表 sys_adj_factor_events。

特点：incremental + Tushare 前链校验；尾部 append / 异常全量 refresh。前复权 SOT 为腾讯。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_adj_factor_events",
    # immediate 模式：每个结果单独处理，避免 batch 中 1 个全量保存（qfq_kline 30s）阻塞整批 20 个
    # 否则中断时大量结果尚未执行 save，下次 run 仍会重复
    "save_mode": "immediate",
    "ignore_fields": [
        "id",
        "event_date",
        "factor",
        "qfq_anchor",
        "raw_anchor",
        "qfq_diff",
        "last_update",
    ],
    "renew": {
        "type": "incremental",
        "last_update_info": {
            "date_field": "last_update",
            "date_format": Utils.date.PERIOD_DAY,
        },
        # 交易日门控由 Handler L0 负责（per-stock + sys_trade_calendar），不用日历天 renew_if_over_days
        "job_execution": {
            "list": "stock_list",
            "key": "id",
        },
    },
    "apis": {
        "adj_factor": {
            "provider_name": "tushare",
            "method": "get_adj_factor",
            "params_mapping": {
                "ts_code": "id",
            },
        },
        "daily_kline": {
            "provider_name": "tushare",
            "method": "get_daily_kline",
            "params_mapping": {
                "ts_code": "id",
            },
        },
        # 前复权 SOT：腾讯财经（AKShare stock_zh_a_hist_tx, adjust=qfq）
        "qfq_kline": {
            "provider_name": "akshare",
            "method": "get_qfq_kline",
            "params_mapping": {
                "symbol": "id",  # handler 转为 sz000001/sh600000
            },
        },
    },
}
