"""
复权因子事件 Handler 的辅助函数集合

将复杂的业务逻辑拆分为语义化的静态方法，便于测试和维护。
"""
from typing import List, Dict, Any, Optional, Set, Tuple
import logging
import pandas as pd
from datetime import date

from core.utils.date.date_utils import DateUtils
from .precision import factor_tolerance, normalize_event_row, round_factor


logger = logging.getLogger(__name__)


class AdjFactorEventHandlerHelper:
    """复权因子事件处理器的辅助函数集合"""
    
    # ========== 数据转换类 ==========
    
    @staticmethod
    def convert_to_eastmoney_secid(stock_id: str) -> str:
        """
        转换股票代码为东方财富格式
        
        Tushare: 000001.SZ -> 东方财富: 0.000001
        Tushare: 600000.SH -> 东方财富: 1.600000
        """
        if '.' not in stock_id:
            return stock_id
        
        code, market = stock_id.split('.')
        
        if market == 'SZ':
            return f"0.{code}"
        elif market == 'SH':
            return f"1.{code}"
        elif market == 'BJ':
            return f"5.{code}"
        else:
            logger.warning(f"未知交易所 {market} for {stock_id}")
            return stock_id
    
    @staticmethod
    def convert_to_akshare_symbol(stock_id: str) -> str:
        """
        转换股票代码为 AKShare 格式（6 位纯数字）
        
        Tushare: 000001.SZ -> AKShare: 000001
        Tushare: 600000.SH -> AKShare: 600000
        """
        if '.' in stock_id:
            return stock_id.split('.')[0]
        return stock_id
    
    @staticmethod
    def convert_to_tx_symbol(stock_id: str) -> str:
        """
        转换股票代码为腾讯格式（stock_zh_a_hist_tx）
        
        Tushare: 000001.SZ -> 腾讯: sz000001
        Tushare: 600000.SH -> 腾讯: sh600000
        """
        if '.' not in stock_id:
            return stock_id
        code, market = stock_id.split('.')
        if market == 'SZ':
            return f"sz{code}"
        elif market == 'SH':
            return f"sh{code}"
        elif market == 'BJ':
            return f"bj{code}"
        return stock_id
    
    # ========== 数据解析类 ==========
    
    @staticmethod
    def parse_akshare_qfq_price_map(akshare_df: Any) -> Dict[str, float]:
        """
        解析腾讯前复权 K 线 DataFrame，构建日期 -> QFQ 收盘价的映射
        
        Args:
            akshare_df: AKShare stock_zh_a_hist_tx(adjust="qfq") 返回的 DataFrame
                       列：date(YYYY-MM-DD)、close 等
        
        Returns:
            Dict[str, float]: 日期（YYYYMMDD格式） -> 前复权收盘价的映射
        """
        qfq_map = {}
        try:
            if akshare_df is None or (isinstance(akshare_df, pd.DataFrame) and akshare_df.empty):
                return qfq_map
            df = pd.DataFrame(akshare_df) if not isinstance(akshare_df, pd.DataFrame) else akshare_df
            # AKShare 列名：日期、收盘
            date_col = '日期' if '日期' in df.columns else 'date'
            close_col = '收盘' if '收盘' in df.columns else 'close'
            if date_col not in df.columns or close_col not in df.columns:
                logger.debug(f"AKShare DataFrame 缺少日期/收盘列: {list(df.columns)}")
                return qfq_map
            for _, row in df.iterrows():
                date_val = str(row.get(date_col, ''))
                close_val = float(row.get(close_col, 0))
                date_ymd = date_val.replace('-', '') if date_val else ''
                if len(date_ymd) == 8 and date_ymd.isdigit() and close_val > 0:
                    qfq_map[date_ymd] = close_val
        except Exception as e:
            logger.warning(f"解析 AKShare 前复权数据失败: {e}")
        return qfq_map
    
    
    @staticmethod
    def parse_eastmoney_qfq_price_map(eastmoney_result: Any) -> Dict[str, float]:
        """
        解析东方财富 API 返回的全量前复权价格，构建日期 -> QFQ 价格的映射。

        供 CalendarService 等场景使用；adj_factor_event Handler 使用 parse_akshare_qfq_price_map（腾讯）。
        
        Args:
            eastmoney_result: 东方财富 Provider 返回的 JSON 数据（dict）
        
        Returns:
            Dict[str, float]: 日期（YYYYMMDD格式） -> 前复权收盘价的映射
        """
        qfq_map = {}
        
        try:
            if not isinstance(eastmoney_result, dict):
                logger.debug("东方财富 API 返回的数据不是 dict 类型")
                return qfq_map
            
            # 检查 API 返回的错误码
            rc = eastmoney_result.get('rc')
            if rc != 0:
                # rc: 102 可能表示参数错误或数据不存在，这是正常的（某些股票可能没有数据）
                if rc == 102:
                    logger.debug(f"东方财富 API 返回 rc=102（数据不存在或参数错误），可能是股票代码无效或日期范围无数据")
                else:
                    logger.warning(f"东方财富 API 返回错误码: {rc}, 消息: {eastmoney_result.get('rt')}")
                return qfq_map
            
            data = eastmoney_result.get('data')
            if not data:
                logger.debug(f"东方财富 API 返回的 data 为空，完整响应: {eastmoney_result}")
                return qfq_map
            
            klines = data.get('klines', [])
            if not klines:
                logger.debug(f"东方财富 API 返回的 klines 为空，data: {data}")
                return qfq_map
            
            # klines 格式：["2024-12-15,11.46", "2024-12-14,11.45", ...]
            # 第一个字段是日期（YYYY-MM-DD），第二个字段是收盘价
            parsed_count = 0
            failed_count = 0
            sample_dates = []  # 记录前几个解析成功的日期，用于调试
            
            for kline_str in klines:
                if not isinstance(kline_str, str):
                    failed_count += 1
                    continue
                    
                parts = kline_str.split(',')
                if len(parts) >= 2:
                    date_str = parts[0].strip()  # YYYY-MM-DD，去除空格
                    try:
                        close_price = float(parts[1].strip())
                        # 转换为 YYYYMMDD 格式
                        date_ymd = date_str.replace('-', '')
                        
                        # 验证日期格式（应该是8位数字）
                        if len(date_ymd) == 8 and date_ymd.isdigit():
                            qfq_map[date_ymd] = close_price
                            parsed_count += 1
                            # 记录前3个日期用于调试
                            if len(sample_dates) < 3:
                                sample_dates.append(date_ymd)
                        else:
                            logger.debug(f"日期格式不正确: {date_str} -> {date_ymd}")
                            failed_count += 1
                    except (ValueError, IndexError) as e:
                        logger.debug(f"解析东方财富 kline 数据失败: {kline_str}, 错误: {e}")
                        failed_count += 1
                        continue
                else:
                    failed_count += 1
            
            # 记录解析统计信息
            # if parsed_count > 0:
                # earliest = min(qfq_map.keys()) if qfq_map else 'N/A'
                # latest = max(qfq_map.keys()) if qfq_map else 'N/A'
                # logger.debug(
                #     f"成功解析东方财富数据: {parsed_count} 条，失败: {failed_count} 条，"
                #     f"日期范围: {earliest} ~ {latest}, 样本日期: {sample_dates}"
                # )
            # else:
            #     logger.warning(
            #         f"东方财富数据解析失败: 总数据 {len(klines)} 条，全部解析失败。"
            #         f"前3条原始数据: {klines[:3] if len(klines) >= 3 else klines}"
            #     )
                
        except Exception as e:
            logger.warning(f"解析东方财富 API 数据失败: {e}")
            import traceback
            logger.debug(traceback.format_exc())
        
        return qfq_map
    
    @staticmethod
    def build_raw_price_map(daily_kline_df: pd.DataFrame) -> Dict[str, float]:
        """
        从日线 DataFrame 构建日期 -> 原始收盘价映射。

        支持 Tushare（``trade_date``）或 DB（``date``）列名。
        """
        raw_price_map: Dict[str, float] = {}

        if daily_kline_df is None or daily_kline_df.empty:
            return raw_price_map

        df = daily_kline_df.copy()
        if "trade_date" not in df.columns and "date" in df.columns:
            df["trade_date"] = df["date"]

        if "trade_date" not in df.columns:
            return raw_price_map

        df = df.sort_values("trade_date", ascending=True)
        for _, row in df.iterrows():
            trade_date = str(row.get("trade_date", ""))[:8]
            close_price = float(row.get("close", 0) or 0)
            if trade_date and close_price > 0:
                raw_price_map[trade_date] = close_price

        return raw_price_map

    @staticmethod
    def build_raw_price_map_from_db_rows(rows: List[Dict[str, Any]]) -> Dict[str, float]:
        """从 ``sys_stock_klines`` 日 K 行构建 raw 收盘价映射。"""
        raw_price_map: Dict[str, float] = {}
        for row in rows or []:
            term = str(row.get("term") or "daily").strip() or "daily"
            if term != "daily":
                continue
            date_ymd = str(row.get("date") or "")[:8]
            close_price = float(row.get("close") or 0)
            if len(date_ymd) == 8 and close_price > 0:
                raw_price_map[date_ymd] = close_price
        return raw_price_map

    @staticmethod
    def db_daily_klines_to_dataframe(rows: List[Dict[str, Any]]) -> pd.DataFrame:
        """DB 日 K 行 → Tushare 兼容 DataFrame（``trade_date`` / ``close``）。"""
        records = []
        for row in rows or []:
            term = str(row.get("term") or "daily").strip() or "daily"
            if term != "daily":
                continue
            date_ymd = str(row.get("date") or "")[:8]
            close_price = float(row.get("close") or 0)
            if len(date_ymd) == 8 and close_price > 0:
                records.append({"trade_date": date_ymd, "close": close_price})
        if not records:
            return pd.DataFrame(columns=["trade_date", "close"])
        return pd.DataFrame(records).sort_values("trade_date", ascending=True)

    @staticmethod
    def db_daily_klines_cover_range(
        rows: List[Dict[str, Any]],
        start_ymd: str,
        end_ymd: str,
    ) -> bool:
        """DB 日 K 是否覆盖请求区间端点（含边界）。"""
        start = str(start_ymd or "")[:8]
        end = str(end_ymd or "")[:8]
        if not start or not end or start > end:
            return False
        dates = [
            str(r.get("date") or "")[:8]
            for r in (rows or [])
            if str(r.get("term") or "daily").strip() in ("", "daily")
            and str(r.get("date") or "")[:8].isdigit()
        ]
        if not dates:
            return False
        return min(dates) <= start and max(dates) >= end

    @staticmethod
    def raw_price_map_covers_event_dates(
        raw_price_map: Dict[str, float],
        event_dates: List[str],
    ) -> bool:
        """事件日（含非交易日向前找）是否都能解析 raw 收盘价。"""
        for event_date_ymd in event_dates or []:
            if (
                AdjFactorEventHandlerHelper.get_raw_price_for_date(
                    raw_price_map, str(event_date_ymd)[:8]
                )
                is None
            ):
                return False
        return True
    
    # ========== 复权因子计算类 ==========
    
    @staticmethod
    def get_factor_changing_dates(adj_factor_df: pd.DataFrame) -> List[str]:
        """
        找出复权因子变化的日期
        
        Args:
            adj_factor_df: Tushare adj_factor API 返回的 DataFrame
        
        Returns:
            List[str]: 因子变化的日期列表（YYYYMMDD格式）
        """
        if adj_factor_df is None or adj_factor_df.empty:
            return []
        
        adj_factor_df = adj_factor_df.sort_values('trade_date', ascending=True)
        
        changing_dates = []
        prev_factor = None
        
        for _, row in adj_factor_df.iterrows():
            current_factor = float(row.get('adj_factor', 0))
            trade_date = str(row.get('trade_date', ''))
            
            if not trade_date:
                continue
            
            # 只有当因子真正发生变化时才记录日期（考虑浮点数精度）
            if prev_factor is not None:
                prev_r = round_factor(prev_factor)
                curr_r = round_factor(current_factor)
                if prev_r is not None and curr_r is not None and prev_r != curr_r:
                    changing_dates.append(trade_date)
            
            prev_factor = current_factor
        
        return changing_dates

    @staticmethod
    def has_factor_change_in_range(
        adj_factor_df: pd.DataFrame,
        start_ymd: str,
        end_ymd: str,
    ) -> bool:
        """
        检查 [start_ymd, end_ymd] 区间内是否有复权因子变化。
        start_ymd/end_ymd 为 YYYYMMDD 格式。
        """
        changing = AdjFactorEventHandlerHelper.get_factor_changing_dates(adj_factor_df)
        if not changing:
            return False
        for d in changing:
            if start_ymd <= d <= end_ymd:
                return True
        return False

    @staticmethod
    def last_update_to_probe_start(last_update_raw: Any) -> Optional[str]:
        """将 last_update（datetime 或日期串）规范为探测起点 YYYYMMDD（含当天）。"""
        if not last_update_raw:
            return None
        text = str(last_update_raw).strip()
        if " " in text:
            text = text.split(" ", 1)[0]
        normalized = DateUtils.normalize_str(text)
        if normalized:
            return normalized
        compact = text.replace("-", "")[:8]
        return compact if len(compact) == 8 and compact.isdigit() else None

    # ========== 交易日门控（L0：DB last_update + sys_trade_calendar）==========

    @staticmethod
    def last_checked_open_day(
        last_update_raw: Any,
        trade_calendar_model: Any,
    ) -> str:
        """``last_update`` 所在自然日及之前最近的开市日（已检查到的交易日锚点）。"""
        checked_ymd = AdjFactorEventHandlerHelper.last_update_to_probe_start(
            last_update_raw
        )
        if not checked_ymd or trade_calendar_model is None:
            return ""
        try:
            return str(
                trade_calendar_model.load_max_cal_date_on_or_before(
                    checked_ymd,
                    is_open_only=True,
                )
                or ""
            ).strip()[:8]
        except Exception:
            return ""

    @staticmethod
    def has_pending_trading_days_since_last_update(
        last_update_raw: Any,
        latest_ymd: str,
        *,
        trade_calendar_model: Any,
    ) -> bool:
        """
        ``last_update`` 之后是否还有未覆盖的开市日（至 ``latest_ymd`` 含）。

        无 ``last_update``（新股/从未成功）→ 需要处理。
        """
        latest = str(latest_ymd or "").strip()[:8]
        if not latest:
            return True
        if not last_update_raw:
            return True
        last_checked_open = AdjFactorEventHandlerHelper.last_checked_open_day(
            last_update_raw, trade_calendar_model
        )
        if not last_checked_open:
            return True
        if last_checked_open >= latest:
            return False
        next_day = DateUtils.add_days(last_checked_open, 1)
        if next_day > latest:
            return False
        try:
            open_rows = trade_calendar_model.load_range(
                next_day, latest, is_open=1
            )
        except Exception:
            return True
        return bool(open_rows)

    @staticmethod
    def filter_stocks_with_pending_trading_days(
        stock_ids: List[str],
        last_update_by_stock: Dict[str, Any],
        latest_ymd: str,
        *,
        trade_calendar_model: Any,
    ) -> Set[str]:
        """返回仍需 renew 的股票 id（断点重跑：``last_update`` 落后会自动入选）。"""
        pending: Set[str] = set()
        for sid in stock_ids:
            sid_s = str(sid or "").strip()
            if not sid_s:
                continue
            if AdjFactorEventHandlerHelper.has_pending_trading_days_since_last_update(
                last_update_by_stock.get(sid_s),
                latest_ymd,
                trade_calendar_model=trade_calendar_model,
            ):
                pending.add(sid_s)
        return pending

    @staticmethod
    def resolve_adj_factor_probe_start(
        last_update_raw: Any,
        latest_ymd: str,
        *,
        trade_calendar_model: Any,
    ) -> str:
        """
        窄窗 adj_factor 探测起点：上次已检查开市日的**下一开市日**。

        无 ``last_update`` 时由调用方回退全历史 ``default_start``。
        """
        latest = str(latest_ymd or "").strip()[:8]
        last_checked_open = AdjFactorEventHandlerHelper.last_checked_open_day(
            last_update_raw, trade_calendar_model
        )
        if not last_checked_open or not latest:
            return latest
        if last_checked_open >= latest:
            return latest
        next_day = DateUtils.add_days(last_checked_open, 1)
        try:
            open_rows = trade_calendar_model.load_range(
                next_day, latest, is_open=1
            )
        except Exception:
            return next_day
        if open_rows:
            return str(open_rows[0].get("cal_date") or next_day).strip()[:8]
        return latest

    @staticmethod
    def resolve_chain_verify_fetch_start(
        existing: List[Dict[str, Any]],
        default_start: str,
    ) -> str:
        """前链校验需拉取的 adj_factor 起点（库内最早 event_date，否则 default_start）。"""
        if not existing:
            return str(default_start or "").strip()
        dates = [
            str(e.get("event_date") or "")[:8]
            for e in existing
            if e.get("event_date")
        ]
        if not dates:
            return str(default_start or "").strip()
        return min(dates)

    @staticmethod
    def collect_event_dates(
        adj_factor_df: pd.DataFrame,
        first_kline_ymd: Optional[str],
    ) -> List[str]:
        """收集事件日期列表（因子变化日 + 首根 K 线日），与 build_adj_factor_events 一致。"""
        if adj_factor_df is None or adj_factor_df.empty:
            return [first_kline_ymd] if first_kline_ymd else []

        changing_dates = AdjFactorEventHandlerHelper.get_factor_changing_dates(adj_factor_df)
        if first_kline_ymd:
            if first_kline_ymd not in changing_dates:
                changing_dates.insert(0, first_kline_ymd)
            else:
                changing_dates.remove(first_kline_ymd)
                changing_dates.insert(0, first_kline_ymd)
        elif not changing_dates:
            return []

        return changing_dates

    @staticmethod
    def build_event_factor_chain(
        adj_factor_df: pd.DataFrame,
        first_kline_ymd: Optional[str],
    ) -> List[tuple]:
        """
        仅从 Tushare adj_factor 构建期望事件链：[(event_date, factor), ...]。
        用于前链校验，不依赖腾讯/raw。
        """
        if adj_factor_df is None or adj_factor_df.empty:
            return []

        adj_factor_df = adj_factor_df.sort_values("trade_date", ascending=True)
        first_factor = float(adj_factor_df.iloc[0].get("adj_factor", 1.0))
        event_dates = AdjFactorEventHandlerHelper.collect_event_dates(
            adj_factor_df, first_kline_ymd
        )
        chain: List[tuple] = []
        for event_date_ymd in event_dates:
            factor = AdjFactorEventHandlerHelper.get_factor_for_date(
                adj_factor_df, event_date_ymd, first_factor
            )
            rounded = round_factor(factor)
            chain.append((str(event_date_ymd)[:8], float(rounded if rounded is not None else factor)))
        return chain

    @staticmethod
    def _chain_keys_equal(
        left: List[tuple],
        right: List[tuple],
    ) -> bool:
        if len(left) != len(right):
            return False
        for (d1, f1), (d2, f2) in zip(left, right):
            if str(d1)[:8] != str(d2)[:8]:
                return False
            rf1 = round_factor(f1)
            rf2 = round_factor(f2)
            if rf1 is None or rf2 is None:
                return False
            if rf1 != rf2:
                return False
        return True

    @staticmethod
    def verify_event_chain_prefix(
        existing: List[Dict[str, Any]],
        adj_factor_df: pd.DataFrame,
        first_kline_ymd: Optional[str],
    ) -> tuple:
        """
        用 Tushare 全量 adj_factor 校验库内前链是否与期望一致。

        Returns:
            (ok, reason, expected_chain)
        """
        expected = AdjFactorEventHandlerHelper.build_event_factor_chain(
            adj_factor_df, first_kline_ymd
        )
        if not expected:
            return False, "empty_expected_chain", expected

        existing_sorted = sorted(
            existing or [],
            key=lambda r: str(r.get("event_date") or ""),
        )
        existing_keys = [
            (str(r.get("event_date") or "")[:8], r.get("factor") or 0.0)
            for r in existing_sorted
        ]
        if not existing_keys:
            return True, "no_existing", expected

        if len(expected) < len(existing_keys):
            return False, "expected_shorter_than_db", expected

        prefix = expected[: len(existing_keys)]
        if not AdjFactorEventHandlerHelper._chain_keys_equal(existing_keys, prefix):
            return False, "prefix_mismatch", expected

        return True, "ok", expected

    @staticmethod
    def resolve_first_kline_ymd(
        existing: List[Dict[str, Any]],
        adj_factor_df: pd.DataFrame,
        daily_kline_df: Optional[pd.DataFrame] = None,
        qfq_map: Optional[Dict[str, float]] = None,
    ) -> Optional[str]:
        """解析首根 K 线日：优先库内最早事件，否则 daily/qfq/adj 序列起点。"""
        if existing:
            earliest = sorted(existing, key=lambda r: str(r.get("event_date") or ""))[0]
            event_date = str(earliest.get("event_date") or "")[:8]
            if event_date:
                return event_date

        if qfq_map:
            return min(qfq_map.keys())

        if daily_kline_df is not None and not daily_kline_df.empty:
            if "trade_date" in daily_kline_df.columns:
                return AdjFactorEventHandlerHelper.normalize_date_to_yyyymmdd(
                    str(daily_kline_df["trade_date"].min())
                )

        if adj_factor_df is not None and not adj_factor_df.empty:
            sorted_df = adj_factor_df.sort_values("trade_date", ascending=True)
            return str(sorted_df.iloc[0].get("trade_date", ""))[:8]

        return None

    @staticmethod
    def date_range_for_event_dates(
        event_dates: List[str],
        buffer_days: int = 7,
        end_date_cap: Optional[str] = None,
    ) -> Optional[tuple]:
        """为新事件日计算窄窗拉取范围（含 buffer）。"""
        valid = [str(d)[:8] for d in (event_dates or []) if str(d)[:8].isdigit()]
        if not valid:
            return None
        start = DateUtils.add_days(min(valid), -buffer_days)
        end = end_date_cap or max(valid)
        return start, end

    @staticmethod
    def build_events_for_chain_keys(
        stock_id: str,
        adj_factor_df: pd.DataFrame,
        raw_price_map: Dict[str, float],
        qfq_map: Dict[str, float],
        chain_keys: List[tuple],
    ) -> List[Dict[str, Any]]:
        """为指定 (event_date, factor) 链构建事件记录（含 anchor）。"""
        if not chain_keys or adj_factor_df is None or adj_factor_df.empty:
            return []

        adj_factor_df = adj_factor_df.sort_values("trade_date", ascending=True)
        factor_latest = float(adj_factor_df.iloc[-1].get("adj_factor", 1.0))
        events: List[Dict[str, Any]] = []

        for event_date_ymd, factor in chain_keys:
            raw_close = AdjFactorEventHandlerHelper.get_raw_price_for_date(
                raw_price_map, event_date_ymd
            )
            if raw_close is None or raw_close == 0:
                return []

            qfq_price = AdjFactorEventHandlerHelper.get_qfq_price_for_date(
                qfq_map, event_date_ymd, stock_id
            )
            if qfq_price is None:
                return []

            qfq_diff = AdjFactorEventHandlerHelper.calculate_qfq_diff(
                raw_close,
                qfq_price,
                factor_event=float(factor),
                factor_latest=factor_latest,
            )
            events.append(
                AdjFactorEventHandlerHelper._pack_event_row(
                    stock_id=stock_id,
                    event_date_ymd=event_date_ymd,
                    factor=float(factor),
                    qfq_price=qfq_price,
                    raw_close=raw_close,
                    qfq_diff=qfq_diff,
                )
            )

        return events

    @staticmethod
    def _pack_event_row(
        *,
        stock_id: str,
        event_date_ymd: str,
        factor: float,
        qfq_price: Optional[float],
        raw_close: float,
        qfq_diff: float,
    ) -> Dict[str, Any]:
        return normalize_event_row(
            {
                "id": stock_id,
                "event_date": event_date_ymd,
                "factor": factor,
                "qfq_anchor": float(qfq_price) if qfq_price is not None else None,
                "raw_anchor": float(raw_close),
                "qfq_diff": qfq_diff,
            }
        )

    @staticmethod
    def get_factor_for_date(adj_factor_df: pd.DataFrame, event_date_ymd: str, default_factor: float = 1.0) -> float:
        """
        获取指定日期的复权因子
        
        Args:
            adj_factor_df: Tushare adj_factor API 返回的 DataFrame
            event_date_ymd: 事件日期（YYYYMMDD格式）
            default_factor: 默认因子（如果找不到数据，通常用于第一根K线早于所有复权因子数据的情况）
        
        Returns:
            float: 复权因子
        """
        if adj_factor_df is None or adj_factor_df.empty:
            return default_factor
        
        # 查找该事件日的复权因子
        event_row = adj_factor_df[adj_factor_df['trade_date'] == event_date_ymd]
        if not event_row.empty:
            return float(event_row.iloc[0]['adj_factor'])
        
        # 如果事件日不在复权因子数据中（如第一根日线早于所有复权因子数据），
        # 使用该日期之前最近的因子
        prev_rows = adj_factor_df[adj_factor_df['trade_date'] <= event_date_ymd]
        if not prev_rows.empty:
            return float(prev_rows.iloc[-1]['adj_factor'])
        
        # 如果该日期之前也没有数据（第一根K线早于所有复权因子数据），
        # 使用第一个可用的复权因子（而不是默认因子1.0）
        # 这样可以确保第一根K线使用正确的初始复权因子
        if not adj_factor_df.empty:
            first_row = adj_factor_df.iloc[0]
            return float(first_row.get('adj_factor', default_factor))
        
        # 如果完全没有数据，使用默认因子
        return default_factor
    
    @staticmethod
    def get_raw_price_for_date(raw_price_map: Dict[str, float], event_date_ymd: str) -> Optional[float]:
        """
        获取指定日期的原始收盘价
        
        如果事件日不是交易日（如周末、节假日），查找该日期之前最近的交易日收盘价
        
        Args:
            raw_price_map: 日期 -> 原始收盘价的映射（YYYYMMDD格式）
            event_date_ymd: 事件日期（YYYYMMDD格式）
        
        Returns:
            float: 原始收盘价，如果找不到返回 None
        """
        # 首先尝试直接获取事件日的收盘价
        raw_close = raw_price_map.get(event_date_ymd)
        if raw_close is not None and raw_close > 0:
            return raw_close
        
        # 如果事件日没有收盘价（可能不是交易日），查找该日期之前最近的交易日
        # 将日期字符串转换为整数进行比较
        event_date_int = int(event_date_ymd)
        
        # 找到所有早于或等于事件日的日期，按降序排序，取第一个
        available_dates = [
            (int(date_str), price) 
            for date_str, price in raw_price_map.items() 
            if price > 0 and int(date_str) <= event_date_int
        ]
        
        if available_dates:
            # 按日期降序排序，取最近的交易日
            available_dates.sort(reverse=True)
            return available_dates[0][1]
        
        # 如果找不到任何数据，返回 None
        return None
    
    @staticmethod
    def get_qfq_price_for_date(qfq_map: Dict[str, float], event_date_ymd: str, stock_id: str = None) -> Optional[float]:
        """
        从日期 -> 前复权收盘价映射中，获取指定事件日的价格。
        
        如果事件日不是交易日（如周末、节假日），查找该日期之前最近的交易日价格。
        
        Args:
            qfq_map: 日期 -> 前复权收盘价的映射（YYYYMMDD格式，通常来自腾讯 qfq K 线）
            event_date_ymd: 事件日期（YYYYMMDD格式）
            stock_id: 股票代码（可选，用于日志）
        
        Returns:
            float: 前复权收盘价，如果找不到返回 None
        """
        if not qfq_map:
            return None
        
        # 首先尝试直接获取事件日的价格
        qfq_price = qfq_map.get(event_date_ymd)
        if qfq_price is not None:
            # 检查价格类型，如果不是数字类型则尝试转换
            if not isinstance(qfq_price, (int, float)):
                try:
                    qfq_price = float(qfq_price)
                except (ValueError, TypeError):
                    logger.error(f"{stock_id or 'Unknown'} {event_date_ymd}: 无法将价格转换为 float: {qfq_price}")
                    return None
            return float(qfq_price)
        
        # 如果事件日没有价格（可能不是交易日），查找该日期之前最近的交易日
        # 将日期字符串转换为整数进行比较
        event_date_int = int(event_date_ymd)
        
        # 找到所有早于或等于事件日的日期，按降序排序，取第一个
        # 注意：即使价格为 0 或负数，也包含在内（可能是有效数据）
        available_dates = [
            (int(date_str), price) 
            for date_str, price in qfq_map.items() 
            if price is not None and int(date_str) <= event_date_int
        ]
        
        if available_dates:
            # 按日期降序排序，取最近的交易日
            available_dates.sort(reverse=True)
            return available_dates[0][1]
        
        # 如果找不到任何数据，返回 None
        return None

    # 兼容旧名（文档/外部引用）
    get_eastmoney_qfq_for_date = get_qfq_price_for_date
    
    @staticmethod
    def segment_offset(
        *,
        factor_event: float,
        factor_latest: float,
        qfq_anchor: Optional[float] = None,
        raw_anchor: Optional[float] = None,
        stored_qfq_diff: Optional[float] = None,
    ) -> float:
        """
        段内 offset：``qfq_anchor - raw_anchor×F(段)/F(最新)``。

        估算模型不变；``F(最新)`` 取消费时该股最新事件 factor，故历史 anchor 无需随 append 更新。
        无 anchor 时回退入库缓存 ``stored_qfq_diff``（旧数据兼容）。
        """
        if factor_latest <= 0:
            return 0.0
        if qfq_anchor is not None and raw_anchor is not None:
            return qfq_anchor - raw_anchor * factor_event / factor_latest
        if stored_qfq_diff is not None:
            return stored_qfq_diff
        return 0.0

    @staticmethod
    def calculate_qfq_diff(
        raw_close: float,
        external_qfq: Optional[float],
        *,
        factor_event: float,
        factor_latest: float,
    ) -> float:
        """
        入库缓存：与 ``segment_offset`` 在入库时 ``F(最新)`` 下等价（可选写入 ``qfq_diff`` 列）。
        """
        return AdjFactorEventHandlerHelper.segment_offset(
            factor_event=factor_event,
            factor_latest=factor_latest,
            qfq_anchor=external_qfq,
            raw_anchor=raw_close,
        )

    @staticmethod
    def events_support_append(existing: List[Dict[str, Any]]) -> bool:
        """已有事件均含 anchor 时，才允许 tail append（否则需 refresh 补齐 anchor）。"""
        if not existing:
            return False
        for row in existing:
            if row.get("qfq_anchor") is None or row.get("raw_anchor") is None:
                return False
        return True

    @staticmethod
    def split_append_tail(
        existing: List[Dict[str, Any]],
        rebuilt: List[Dict[str, Any]],
    ) -> tuple[bool, List[Dict[str, Any]]]:
        """
        判断 rebuilt 是否可在保留 existing 的前提下仅 append 尾部新事件。

        Returns:
            (can_append, tail_events)
        """
        if not existing or not rebuilt:
            return False, []

        def _key(r: Dict[str, Any]) -> tuple:
            return (str(r.get("event_date") or ""), r.get("factor") or 0.0)

        existing_sorted = sorted(existing, key=lambda r: str(r.get("event_date") or ""))
        rebuilt_sorted = sorted(rebuilt, key=lambda r: str(r.get("event_date") or ""))

        if len(rebuilt_sorted) < len(existing_sorted):
            return False, []

        for old, new in zip(existing_sorted, rebuilt_sorted):
            if str(old.get("id")) != str(new.get("id")):
                return False, []
            if _key(old) != _key(new):
                return False, []

        if not AdjFactorEventHandlerHelper.events_support_append(existing_sorted):
            return False, []

        tail = rebuilt_sorted[len(existing_sorted) :]
        return (len(tail) > 0, tail)
    
    # ========== 日期工具类 ==========
    
    @staticmethod
    def normalize_date_to_yyyymmdd(date_value: Any) -> str:
        """
        将日期值标准化为 YYYYMMDD 格式字符串
        
        Args:
            date_value: 可以是 datetime.date、YYYY-MM-DD 字符串、YYYYMMDD 字符串等
        
        Returns:
            str: YYYYMMDD 格式的日期字符串
        """
        if isinstance(date_value, date):
            return DateUtils.date_to_format(date_value)
        elif isinstance(date_value, str):
            # 使用 normalize_str 自动识别并转换格式
            normalized = DateUtils.normalize_str(date_value)
            if normalized:
                return normalized
            # 如果 normalize_str 失败，尝试手动处理
            if '-' in date_value:
                return date_value.replace('-', '')
            return date_value
        else:
            return str(date_value).replace('-', '')
    
    # ========== 事件构建类 ==========
    
    @staticmethod
    def build_adj_factor_events(
        stock_id: str,
        adj_factor_df: pd.DataFrame,
        raw_price_map: Dict[str, float],
        qfq_map: Dict[str, float],
        first_kline_ymd: Optional[str]
    ) -> List[Dict[str, Any]]:
        """
        构建复权因子事件列表
        
        Args:
            stock_id: 股票代码
            adj_factor_df: Tushare adj_factor API 返回的 DataFrame
            raw_price_map: 日期 -> 原始收盘价的映射
            qfq_map: 日期 -> 前复权收盘价的映射（腾讯 qfq K 线，经 parse_akshare_qfq_price_map）
            first_kline_ymd: 第一根K线日期（YYYYMMDD格式）
        
        Returns:
            List[Dict]: 复权因子事件列表，每个元素包含：
                - id: 股票代码
                - event_date: 事件日期（YYYYMMDD格式）
                - factor: 复权因子
                - qfq_anchor / raw_anchor: 事件日快照（append 后不变）
                - qfq_diff: 可选缓存（入库时 F(最新) 下的 delta）
        """
        if adj_factor_df is None or adj_factor_df.empty:
            return []
        
        # 处理复权因子数据：按日期排序
        adj_factor_df = adj_factor_df.sort_values('trade_date', ascending=True)
        factor_latest = float(adj_factor_df.iloc[-1].get('adj_factor', 1.0))
        
        # 获取第一个复权因子（用于从未有复权事件的股票，或第一根K线早于所有复权因子数据的情况）
        first_factor = 1.0
        if not adj_factor_df.empty:
            first_row = adj_factor_df.iloc[0]
            first_factor = float(first_row.get('adj_factor', 1.0))
        
        # 计算所有复权事件日期（因子变化的日期）
        changing_dates = AdjFactorEventHandlerHelper.get_factor_changing_dates(adj_factor_df)
        
        # 确保第一根日线日期作为一个事件点（必须包含，即使早于所有复权因子数据）
        if first_kline_ymd:
            if first_kline_ymd not in changing_dates:
                # 插入到开头，确保第一根K线日期是第一个事件
                changing_dates.insert(0, first_kline_ymd)
            else:
                # 如果已经在列表中，确保它在第一位
                changing_dates.remove(first_kline_ymd)
                changing_dates.insert(0, first_kline_ymd)
        
        # 如果从未有复权事件（changing_dates 为空），但存在第一根K线，确保至少保存一条记录
        if not changing_dates:
            if first_kline_ymd:
                changing_dates = [first_kline_ymd]
            else:
                return []
        
        # 为每个事件日期计算 qfq_diff 并构建事件记录
        events = []
        
        # 如果 qfq_map 为空，记录一次警告（避免为每个事件日期都记录）
        if not qfq_map:
            logger.warning(f"{stock_id}: 无法获取前复权价格数据（API 返回格式异常或数据为空），该股票的所有事件日期都将使用 qfq_diff=0.0")
        
        for event_date_ymd in changing_dates:
            # 获取该事件日的复权因子
            factor = AdjFactorEventHandlerHelper.get_factor_for_date(
                adj_factor_df, event_date_ymd, first_factor
            )
            
            # 获取该事件日的原始收盘价
            # 如果事件日不是交易日（如周末、节假日），查找该日期之前最近的交易日收盘价
            raw_close = AdjFactorEventHandlerHelper.get_raw_price_for_date(
                raw_price_map, event_date_ymd
            )
            if raw_close is None or raw_close == 0:
                # 事件日没有原始收盘价属于正常情况，不再逐条打印 debug 日志
                continue
            
            # 获取该事件日的前复权价格（如果事件日不是交易日，查找该日期之前最近的交易日价格）
            qfq_price = AdjFactorEventHandlerHelper.get_qfq_price_for_date(
                qfq_map, event_date_ymd, stock_id
            )
            
            qfq_diff = AdjFactorEventHandlerHelper.calculate_qfq_diff(
                raw_close,
                qfq_price,
                factor_event=factor,
                factor_latest=factor_latest,
            )
            
            events.append(
                AdjFactorEventHandlerHelper._pack_event_row(
                    stock_id=stock_id,
                    event_date_ymd=event_date_ymd,
                    factor=factor,
                    qfq_price=qfq_price,
                    raw_close=raw_close,
                    qfq_diff=qfq_diff,
                )
            )
        
        return events
