"""
adj_factor_event 爬取精度：Tushare / AKShare 数据在写入 DB 前的业务舍入与前链比对。

仅服务于 ``AdjFactorEventHandler`` 流水线（helper / save 路径），
不属于 ``core/tables`` 或 ``infra/db`` 契约；表 Model 只接收已规范化的 float 行。

精度来源：``core/default_config/data.json`` → ``decimal_places.adj_factor_event``。
"""
from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Dict, Optional


def _load_places() -> tuple[int, int, int]:
    factor_places = 4
    price_places = 3
    diff_places = 4
    try:
        from core.infra.project_context import ConfigManager

        places = ConfigManager.get_adj_factor_event_decimal_places()
        factor_places = places["factor_places"]
        price_places = places["price_places"]
        diff_places = places["diff_places"]
    except Exception:
        pass
    return (
        max(0, factor_places),
        max(0, price_places),
        max(0, diff_places),
    )


def factor_places() -> int:
    return _load_places()[0]


def price_places() -> int:
    return _load_places()[1]


def diff_places() -> int:
    return _load_places()[2]


def factor_tolerance() -> float:
    """前链 factor 比对容差（与 factor 小数位一致）。"""
    p = factor_places()
    return 10 ** (-p) if p > 0 else 1e-6


def _quantize(value: Any, places: int) -> Optional[float]:
    """爬取边界舍入：仅接受 float/int（Tushare / AKShare / 内存计算产物）。"""
    if value is None:
        return None
    if isinstance(value, bool):
        raise TypeError("adj_factor 数值字段不接受 bool")
    if isinstance(value, Decimal):
        raise TypeError(
            "adj_factor 爬取边界仅接受 float/int；Decimal 应在 DB 读出口已转为 float"
        )
    if not isinstance(value, (int, float)):
        raise TypeError(
            f"adj_factor 数值字段仅接受 float/int，收到 {type(value).__name__}"
        )
    d = Decimal(str(value))
    q = Decimal("1").scaleb(-places)
    return float(d.quantize(q, rounding=ROUND_HALF_UP))


def round_factor(value: Any) -> Optional[float]:
    return _quantize(value, factor_places())


def round_price(value: Any) -> Optional[float]:
    return _quantize(value, price_places())


def round_diff(value: Any) -> Optional[float]:
    return _quantize(value, diff_places())


def normalize_event_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Handler 写库前规范化浮点字段（Tushare 前链 + anchor 快照）。"""
    out = dict(row)
    if "factor" in out and out["factor"] is not None:
        out["factor"] = round_factor(out["factor"])
    if "qfq_anchor" in out:
        out["qfq_anchor"] = round_price(out["qfq_anchor"])
    if "raw_anchor" in out and out["raw_anchor"] is not None:
        out["raw_anchor"] = round_price(out["raw_anchor"])
    if "qfq_diff" in out and out["qfq_diff"] is not None:
        out["qfq_diff"] = round_diff(out["qfq_diff"])
    return out
