"""
复权因子事件数据（新表，只存储除权日） Schema 定义

定义 Handler 的 normalize 方法需要将 Provider 返回的数据转换成什么格式
schema 中的 key 是数据库字段名（normalize 后的输出字段名）
"""
from core.modules.data_source.contracts import DataSourceField
from core.modules.data_source.contracts import DataSourceSchema


SCHEMA = DataSourceSchema(
    name="adj_factor_event",
    description="复权因子事件链（incremental + Tushare 前链校验 + tail append）",
    fields={
        "id": DataSourceField(str, required=True, description="股票代码 ts_code"),
        "event_date": DataSourceField(str, required=True, description="事件日期 YYYYMMDD"),
        "factor": DataSourceField(float, required=True, description="Tushare 绝对复权因子 F(t)"),
        "qfq_anchor": DataSourceField(
            float,
            required=False,
            description="事件日腾讯前复权收盘价快照",
        ),
        "raw_anchor": DataSourceField(
            float,
            required=False,
            description="事件日未复权收盘价快照",
        ),
        "qfq_diff": DataSourceField(
            float,
            required=False,
            description="可选缓存 delta；消费端优先 anchor 动态 offset",
        ),
        "last_update": DataSourceField(
            str,
            required=False,
            description="该股上次复权检查时间（框架 renew 门控，save 时写入）",
        ),
    }
)
