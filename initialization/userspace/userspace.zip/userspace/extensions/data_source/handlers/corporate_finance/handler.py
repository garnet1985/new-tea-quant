"""
企业财务数据 Handler

从 Tushare 获取企业财务指标数据（季度）。日期范围（rolling / force_refresh）由框架 renew 配置处理。
"""
from typing import List, Dict, Any, Optional, Tuple
import logging

from core.modules.data_source.contracts import BaseHandler
from core.modules.data_source.contracts import BaseProvider
from core.modules.data_source.contracts import ApiJob
from core.modules.data_source.contracts import DataSourceConfig
from core.modules.data_source.contracts import NormalizationHelper as nh
from core.utils.date.date_utils import DateUtils


logger = logging.getLogger(__name__)


class CorporateFinanceHandler(BaseHandler):
    """企业财务数据 Handler：季度数据（YYYYQ[1-4]），每次 renew 覆盖 dependencies 中的全量 stock_list。"""

    def __init__(
        self,
        data_source_key: str,
        schema,
        config: DataSourceConfig,
        providers: Dict[str, BaseProvider],
        depend_on_data_source_names: List[str] = None,
    ):
        super().__init__(data_source_key, schema, config, providers, depend_on_data_source_names or [])
    
    def on_build_job_payload(
        self,
        entity_info: Any,
        apis: List[ApiJob],
        context: Dict[str, Any]
    ) -> Optional[str]:
        """注入 ts_code 到每个 API job。"""
        entity_id = entity_info.get("id") if isinstance(entity_info, dict) else str(entity_info)
        if not entity_id:
            return None
        for job in apis:
            job.params["ts_code"] = str(entity_id)
        return str(entity_id)

    def on_after_batch_api_job_bundles_complete(
        self,
        context: Dict[str, Any],
        batch_items: List[Tuple[Any, Dict[str, Any]]],
    ) -> None:
        """batch：多只股票的企业财务数据合并一次 upsert。"""
        if context.get("is_dry_run") or not batch_items:
            return
        all_rows: List[Dict[str, Any]] = []
        for job_bundle, fetched_data in batch_items:
            stock_id = job_bundle.bundle_id.replace("corporate_finance_batch_", "")
            job_id = job_bundle.apis[0].job_id or job_bundle.apis[0].api_name
            result = fetched_data.get(job_id)
            if result is None:
                continue
            normalized = self._normalize_single_stock_data(context, result, stock_id)
            all_rows.extend(normalized.get("data") or [])
        if not all_rows:
            return
        self._system_save({"data": all_rows})
        logger.debug(
            "corporate_finance batch: %s bundles, %s rows",
            len(batch_items),
            len(all_rows),
        )
    
    def _normalize_single_stock_data(
        self, context: Dict[str, Any], result: Any, stock_id: str
    ) -> Dict[str, Any]:
        """字段映射 + end_date -> quarter 转换，按 quarter 去重保留 end_date 最大的。"""
        records = nh.result_to_records(result)
        if not records:
            return {"data": []}

        records = self.clean_nan_in_records(records, default=None)
        api_cfg = context["config"].get_apis()["finance_data"]
        result_mapping = api_cfg.result_mapping
        mapped_records = nh.apply_field_mapping(records, result_mapping)

        quarter_records = {}
        for record in mapped_records:
            end_date = str(record.get("end_date", "")).replace("-", "")
            if len(end_date) != 8:
                continue
            quarter = DateUtils.date_to_quarter(end_date)
            if not quarter:
                continue
            existing = quarter_records.get(quarter)
            if existing is None or end_date > str(existing.get("end_date", "")).replace("-", ""):
                quarter_records[quarter] = record

        formatted = []
        for quarter, record in quarter_records.items():
            ann_date = DateUtils.normalize(record.get("ann_date"), fmt=DateUtils.FMT_YYYYMMDD)
            if not ann_date:
                continue
            record["id"] = stock_id
            record["quarter"] = quarter
            record["ann_date"] = ann_date
            record.pop("end_date", None)
            formatted.append(record)
        formatted.sort(key=lambda row: str(row["ann_date"]))
        return {"data": formatted}

    def normalize_data(self, context: Dict[str, Any], fetched_data: Any) -> Dict[str, Any]:
        if config := context.get("config"):
            if config.get_save_mode() in ("immediate", "batch"):
                return {"data": []}
        return super().normalize_data(context, fetched_data)
