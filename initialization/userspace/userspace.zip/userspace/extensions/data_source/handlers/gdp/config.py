"""
GDP Handler 配置。绑定表 sys_gdp。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_gdp",
    "save_mode": "unified",
    "renew": {
        "type": "rolling",
        "last_update_info": {
            "date_field": "quarter",
            "date_format": Utils.date.PERIOD_QUARTER,
        },
        "rolling": {
            "unit": Utils.date.PERIOD_QUARTER,
            "length": 4,
        },
    },
    "apis": {
        "gdp_data": {
            "provider_name": "tushare",
            "method": "get_gdp",
            "result_mapping": {
                "quarter": "quarter",
                "gdp": "gdp",
                "gdp_yoy": "gdp_yoy",
                "primary_industry": "pi",
                "primary_industry_yoy": "pi_yoy",
                "secondary_industry": "si",
                "secondary_industry_yoy": "si_yoy",
                "tertiary_industry": "ti",
                "tertiary_industry_yoy": "ti_yoy",
            },
            "params": {},
        },
    },
}
