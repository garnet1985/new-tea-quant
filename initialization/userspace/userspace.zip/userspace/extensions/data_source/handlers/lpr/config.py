"""
LPR Handler 配置。绑定表 sys_lpr。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_lpr",
    "save_mode": "unified",
    "renew": {
        "type": "rolling",
        "rolling": {
            "length": 30,
            "unit": Utils.date.PERIOD_DAY,
        },
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
    },
    "apis": {
        "lpr_data": {
            "provider_name": "tushare",
            "method": "get_lpr",
            "result_mapping": {
                "date": "date",
                "lpr_1_y": "1y",
                "lpr_5_y": "5y",
            },
            "params": {},
        },
    },
}
