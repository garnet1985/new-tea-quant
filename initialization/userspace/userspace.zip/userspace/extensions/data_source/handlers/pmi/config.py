"""
PMI Handler 配置。绑定表 sys_pmi。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_pmi",
    "save_mode": "unified",
    "renew": {
        "type": "rolling",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_MONTH,
        },
        "rolling": {
            "unit": Utils.date.PERIOD_MONTH,
            "length": 12,
        },
    },
    "apis": {
        "pmi_data": {
            "provider_name": "tushare",
            "method": "get_pmi",
            "result_mapping": {
                "date": "MONTH",
                "pmi": "PMI010000",
                "pmi_l_scale": "PMI010100",
                "pmi_m_scale": "PMI010200",
                "pmi_s_scale": "PMI010300",
            },
            "params": {},
        },
    },
}
