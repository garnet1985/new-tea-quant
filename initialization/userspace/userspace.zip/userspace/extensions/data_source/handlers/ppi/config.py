"""
PPI Handler 配置。绑定表 sys_ppi。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_ppi",
    "save_mode": "unified",
    "renew": {
        "type": "rolling",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_MONTH,
        },
        "rolling": {
            "unit": Utils.date.PERIOD_MONTH,
            "length": 12,
        },
    },
    "apis": {
        "ppi_data": {
            "provider_name": "tushare",
            "method": "get_ppi",
            "result_mapping": {
                "date": "month",
                "ppi": "ppi_accu",
                "ppi_yoy": "ppi_yoy",
                "ppi_mom": "ppi_mom",
            },
            "params": {},
        },
    },
}
