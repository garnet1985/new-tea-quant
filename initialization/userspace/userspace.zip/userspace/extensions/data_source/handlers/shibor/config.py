"""
Shibor Handler 配置。绑定表 sys_shibor。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_shibor",
    "save_mode": "unified",
    "renew": {
        "type": "rolling",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
        "rolling": {
            "unit": Utils.date.PERIOD_DAY,
            "length": 30,
        },
    },
    "apis": {
        "shibor_data": {
            "provider_name": "tushare",
            "method": "get_shibor",
            "result_mapping": {
                "date": "date",
                "one_night": "on",
                "one_week": "1w",
                "one_month": "1m",
                "three_month": "3m",
                "one_year": "1y",
            },
            "params": {},
        },
    },
}
