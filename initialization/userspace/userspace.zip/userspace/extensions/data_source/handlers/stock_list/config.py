"""
Stock List Handler 配置。绑定表 sys_stock_list。
行业/板块/市场/地域由定义表 + 映射表维护；result_mapping 中维度字段仅用于钩子写入映射，不写入 sys_stock_list。
"""
CONFIG = {
    "table": "sys_stock_list",
    "save_mode": "unified",
    "renew": {
        "type": "refresh",
    },
    "ignore_fields": ["last_update"],
    "apis": {
        "stock_list_data": {
            "provider_name": "tushare",
            "method": "get_stock_list_full",
            "result_mapping": {
                "id": "ts_code",
                "name": "name",
                "list_status": "list_status",
                "list_date": "list_date",
                "delist_date": "delist_date",
                "industry": "industry",
                "board": "market",
                "market": "exchange",
                "area": "area",
            },
            "params": {
                "fields": (
                    "ts_code,name,area,industry,market,exchange,"
                    "list_status,list_date,delist_date"
                ),
            },
        },
    },
}
