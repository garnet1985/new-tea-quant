"""
股票列表 Handler 辅助：格式化、维度映射写入。
"""
from typing import List, Dict, Any, Optional, Tuple


DimensionMaps = Dict[str, Any]


def format_mapped_records_with_defaults(
    mapped_records: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """过滤无效记录；last_update 由 Handler 在保存前统一写入。"""
    formatted = []
    for item in mapped_records:
        if item.get("id") and item.get("name"):
            formatted.append(dict(item))
    return formatted


def save_stock_dimension_mappings(
    dimensions: List[Tuple[str, str, str, str, str]],
    val_to_id: Dict[str, Dict[str, int]],
    industry_map_model,
    board_map_model,
    market_map_model,
    area_map_model,
) -> None:
    """删除本批股票的旧映射，写入行业/板块/交易所/地域映射。"""
    industry_val_to_id = val_to_id.get("industry") or {}
    board_val_to_id = val_to_id.get("board") or {}
    market_val_to_id = val_to_id.get("market") or {}
    area_val_to_id = val_to_id.get("area") or {}

    industry_rows = []
    board_rows = []
    market_rows = []
    area_rows = []
    stock_ids = set()

    for stock_id, industry_val, board_val, market_val, area_val in dimensions:
        if not stock_id:
            continue
        stock_ids.add(stock_id)
        iid = industry_val_to_id.get(industry_val)
        if iid is not None:
            industry_rows.append({"stock_id": stock_id, "industry_id": iid})
        bid = board_val_to_id.get(board_val)
        if bid is not None:
            board_rows.append({"stock_id": stock_id, "board_id": bid})
        mid = market_val_to_id.get(market_val)
        if mid is not None:
            market_rows.append({"stock_id": stock_id, "market_id": mid})
        aid = area_val_to_id.get(area_val)
        if aid is not None:
            area_rows.append({"stock_id": stock_id, "area_id": aid})

    if stock_ids:
        ids_tuple = tuple(stock_ids)
        industry_map_model.delete("stock_id IN %s", (ids_tuple,))
        board_map_model.delete("stock_id IN %s", (ids_tuple,))
        market_map_model.delete("stock_id IN %s", (ids_tuple,))
        area_map_model.delete("stock_id IN %s", (ids_tuple,))

    if industry_rows:
        industry_map_model.replace_mapping(industry_rows)
    if board_rows:
        board_map_model.replace_mapping(board_rows)
    if market_rows:
        market_map_model.replace_mapping(market_rows)
    if area_rows:
        area_map_model.replace_mapping(area_rows)
