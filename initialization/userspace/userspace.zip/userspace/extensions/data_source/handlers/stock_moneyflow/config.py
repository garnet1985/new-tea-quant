"""
Stock Moneyflow Handler 配置。绑定表 sys_stock_moneyflow（Tushare moneyflow）。

按交易日全市场拉取：无 job_execution，on_before_fetch 将全局日期区间展开为逐日 trade_date 任务。
"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_stock_moneyflow",
    "save_mode": "batch",
    "renew": {
        "type": "rolling",
        "rolling": {
            "unit": Utils.date.PERIOD_DAY,
            "length": 7,
        },
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
    },
    "apis": {
        "moneyflow": {
            "provider_name": "tushare",
            "method": "get_moneyflow",
            "result_mapping": {
                "id": "ts_code",
                "date": "trade_date",
                "buy_sm_amount": "buy_sm_amount",
                "sell_sm_amount": "sell_sm_amount",
                "buy_md_amount": "buy_md_amount",
                "sell_md_amount": "sell_md_amount",
                "buy_lg_amount": "buy_lg_amount",
                "sell_lg_amount": "sell_lg_amount",
                "buy_elg_amount": "buy_elg_amount",
                "sell_elg_amount": "sell_elg_amount",
                "net_mf_vol": "net_mf_vol",
                "net_mf_amount": "net_mf_amount",
            },
            "params": {},
        },
    },
}
