"""
Stock ST Periods Handler 配置。绑定表 sys_stock_st_periods。

按股拉取 namechange（**不传公告日区间**，整段历史解析 ST/*ST 后整股替换写入）。
窗口内状态靠时段相交判定，不按 start_date BETWEEN 截断。
"""
CONFIG = {
    "table": "sys_stock_st_periods",
    "save_mode": "immediate",
    "renew": {
        "type": "refresh",
        "job_execution": {
            "list": "stock_list",
            "key": "id",
        },
    },
    "apis": {
        "namechange": {
            "provider_name": "tushare",
            "method": "get_namechange",
            "params_mapping": {
                "ts_code": "id",
            },
        },
    },
}
