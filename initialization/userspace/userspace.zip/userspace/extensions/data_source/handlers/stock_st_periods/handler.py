"""
ST 风险警示时段 Handler：按股 namechange → 解析 ST 段 → 整股替换 sys_stock_st_periods。

一次 execute 遍历 stock_list 全量；吞吐由 TushareProvider.api_limits['get_namechange']（800/min）限流。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import logging

from core.modules.data_source.contracts import BaseHandler
from core.modules.data_source.contracts import BaseProvider
from core.modules.data_source.contracts import ApiJob
from core.modules.data_source.contracts import ApiJobBundle
from core.modules.data_source.contracts import DataSourceConfig
from core.modules.data_source.contracts import NormalizationHelper as nh

from .helper import records_to_st_periods


logger = logging.getLogger(__name__)


class StockStPeriodsHandler(BaseHandler):
    """namechange 按股同步，全量 list 一次跑完。"""

    def __init__(
        self,
        data_source_key: str,
        schema,
        config: DataSourceConfig,
        providers: Dict[str, BaseProvider],
        depend_on_data_source_names: List[str] = None,
    ):
        super().__init__(
            data_source_key,
            schema,
            config,
            providers,
            depend_on_data_source_names or [],
        )

    def on_prepare_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        context = super().on_prepare_context(context)
        all_stocks = context["dependencies"].get("stock_list") or []
        if all_stocks:
            context["stock_list"] = all_stocks
            logger.info("stock_st_periods 全量：%s 只", len(all_stocks))
        return context

    def normalize_data(self, context: Dict[str, Any], fetched_data: Any) -> Dict[str, Any]:
        """数据已在 on_after_single_api_job_bundle_complete 写入，不走统一 save。"""
        return {"data": []}

    def on_after_normalize(self, context: Dict[str, Any], normalized_data: Dict[str, Any]):
        return normalized_data

    def on_build_job_payload(
        self,
        entity_info: Any,
        apis: List[ApiJob],
        context: Dict[str, Any],
    ) -> Optional[str]:
        entity_id = entity_info.get("id") if isinstance(entity_info, dict) else str(entity_info)
        if not entity_id:
            return None
        for job in apis:
            job.params = job.params or {}
            job.params["ts_code"] = str(entity_id)
            # namechange 的 start/end 按公告日过滤，会丢掉窗口前已开始的 ST 段
            job.params.pop("start_date", None)
            job.params.pop("end_date", None)
        return str(entity_id)

    def on_after_batch_api_job_bundles_complete(
        self,
        context: Dict[str, Any],
        batch_items: List[Tuple[Any, Dict[str, Any]]],
    ) -> None:
        """每股 replace_for_stock，batch 仅调度批次。"""
        for job_bundle, fetched_data in batch_items:
            self._save_st_periods_bundle(context, job_bundle, fetched_data)

    def _save_st_periods_bundle(
        self,
        context: Dict[str, Any],
        job_bundle: ApiJobBundle,
        fetched_data: Dict[str, Any],
    ) -> None:
        stock_id = self._extract_stock_id(job_bundle)
        if not stock_id or context.get("is_dry_run"):
            return

        job_id = job_bundle.apis[0].job_id or job_bundle.apis[0].api_name
        result = fetched_data.get(job_id)
        records = nh.result_to_records(result)
        if not records:
            logger.warning(
                "stock_st_periods [%s]: namechange 无数据，跳过写入（保留库内已有记录）",
                stock_id,
            )
            return
        records = self.clean_nan_in_records(records, default=None)

        from datetime import datetime

        last_update = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        periods = records_to_st_periods(
            records,
            stock_id=stock_id,
            last_update=last_update,
        )

        model = context["data_manager"].get_table("sys_stock_st_periods")
        model.replace_for_stock(stock_id, periods)
        logger.info(
            "stock_st_periods [%s]: %s 段 ST 记录（namechange 原始 %s 行）",
            stock_id,
            len(periods),
            len(records),
        )

    @staticmethod
    def _extract_stock_id(job_bundle: ApiJobBundle) -> str:
        if job_bundle.apis:
            code = (job_bundle.apis[0].params or {}).get("ts_code")
            if code:
                return str(code).strip()
        bid = str(job_bundle.bundle_id or "")
        if bid:
            return bid.split("_")[-1].strip()
        return ""
