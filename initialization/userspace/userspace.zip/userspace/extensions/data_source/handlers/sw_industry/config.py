"""申万行业分类。绑定表 sys_sw_industry。"""


def _code(row, field):
    """行业代码在接口里可能是整数。映射阶段先收成文本，避免变成 110000.0。"""
    value = row.get(field)
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


CONFIG = {
    "table": "sys_sw_industry",
    "save_mode": "unified",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
    },
    "apis": {
        "sw_industry": {
            "provider_name": "tushare",
            "method": "get_sw_industry_classify",
            "params": {
                "src": "SW2021",
            },
            "result_mapping": {
                "id": "index_code",
                "industry_code": lambda row: _code(row, "industry_code"),
                "name": "industry_name",
                "level": "level",
                "parent_code": lambda row: _code(row, "parent_code"),
                "is_pub": lambda row: int(row.get("is_pub") or 0),
                "src": lambda _row: "SW2021",
            },
        },
    },
}
