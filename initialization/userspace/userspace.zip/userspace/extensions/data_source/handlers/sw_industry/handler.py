"""申万行业分类：index_classify(SW2021) → sys_sw_industry。"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.infra.utils import Utils
from core.modules.data_source.contracts import BaseHandler

logger = logging.getLogger(__name__)

CACHE_KEY = "sw_industry_last_sync"
RENEW_IF_OVER_DAYS = 7


class SwIndustryHandler(BaseHandler):
    """申万 2021 分类树。整表替换，不走样本股票过滤。"""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if context.get("force_refresh"):
            return None
        last = _last_sync_day(context, CACHE_KEY)
        if not last:
            return None
        try:
            days = Utils.date.diff_days(last, Utils.date.today())
        except Exception:
            return None
        if days < RENEW_IF_OVER_DAYS:
            logger.info(
                "sw_industry 距上次同步 %s 天（<%s），跳过；强制请 renew -f",
                days,
                RENEW_IF_OVER_DAYS,
            )
            return {"data": []}
        return None

    def on_before_save(
        self, context: Dict[str, Any], normalized_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        rows = self.clean_nan_in_records((normalized_data or {}).get("data") or [])
        rows = [row for row in rows if row.get("id") and row.get("level")]
        if not rows:
            logger.warning("sw_industry 本次无分类数据，保留已有表")
            return {"data": []}
        model = context["data_manager"].get_table("sys_sw_industry")
        model.delete_all()
        model.save_records(rows)
        _mark_synced(context, CACHE_KEY)
        logger.info("sw_industry 写入 %s 行", len(rows))
        return {"data": []}


def _last_sync_day(context: Dict[str, Any], cache_key: str) -> str:
    dm = context.get("data_manager")
    if not dm:
        return ""
    try:
        cache = dm.db_cache.load(cache_key, field="json") or {}
    except Exception:
        return ""
    return str(cache.get("synced_at") or "").strip()


def _mark_synced(context: Dict[str, Any], cache_key: str) -> None:
    dm = context.get("data_manager")
    if not dm:
        return
    try:
        dm.db_cache.save(cache_key, json={"synced_at": Utils.date.today()})
    except Exception:
        logger.warning("写入 %s 失败", cache_key, exc_info=True)
