"""申万一级行业日线。绑定表 sys_data_sw_industry_kline。"""
from core.infra.utils import Utils


CONFIG = {
    "table": "sys_data_sw_industry_kline",
    "save_mode": "batch",
    "renew": {
        "type": "incremental",
        "last_update_info": {
            "date_field": "date",
            "date_format": Utils.date.PERIOD_DAY,
        },
        "job_execution": {
            "list": "sw_l1_list",
            "key": "id",
        },
    },
    "apis": {
        "sw_daily": {
            "provider_name": "tushare",
            "method": "get_sw_daily",
            "params_mapping": {
                "ts_code": "id",
            },
            "result_mapping": {
                "id": "ts_code",
                "date": "trade_date",
                "open": "open",
                "high": "high",
                "low": "low",
                "close": "close",
                "price_change_delta": "change",
                "price_change_rate_delta": "pct_change",
                "volume": "vol",
                "amount": "amount",
                "pe": "pe",
                "pb": "pb",
                "float_mv": "float_mv",
                "total_mv": "total_mv",
            },
        },
    },
}
