"""申万一级行业日线：sw_daily → sys_data_sw_industry_kline。

index_daily 对 .SI 返回空，必须走 sw_daily。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from core.modules.data_source.contracts import (
    ApiJob,
    ApiJobBundle,
    BaseHandler,
    DataSourceConfig,
    NormalizationHelper as nh,
)

logger = logging.getLogger(__name__)

# 申万 A 指，用来算行业相对涨跌。不在分类树里。
SW_A_SHARE = "801003.SI"
LIST_NAME = "sw_l1_list"


class SwIndustryKlineHandler(BaseHandler):
    """按一级行业指数增量拉日线，并额外写入申万 A 指。"""

    def on_prepare_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        context = super().on_prepare_context(context)
        ids = _load_l1_ids(context.get("data_manager"))
        if not ids:
            logger.warning("sys_data_sw_industry 还没有一级行业，跳过行业日线。先更新 sw_industry")
        else:
            logger.info("申万行业日线目标 %s 个（含申万 A 指）", len(ids))
        deps = context.setdefault("dependencies", {})
        deps[LIST_NAME] = [{"id": index_id} for index_id in ids]
        return context

    def on_after_batch_api_job_bundles_complete(
        self,
        context: Dict[str, Any],
        batch_items: List[Tuple[Any, Dict[str, Any]]],
    ) -> None:
        if context.get("is_dry_run") or not batch_items:
            return
        config = context.get("config")
        data_manager = context.get("data_manager")
        if not data_manager or not isinstance(config, DataSourceConfig):
            return
        records: List[Dict[str, Any]] = []
        for job_bundle, fetched in batch_items:
            if not isinstance(job_bundle, ApiJobBundle):
                continue
            for api_job in job_bundle.apis or []:
                records.extend(self._map_job(api_job, fetched, config))
        if not records:
            return
        model = data_manager.get_table("sys_data_sw_industry_kline")
        if model:
            model.save_records(records)
            logger.info("sw_industry_kline 写入 %s 行", len(records))

    def on_after_single_api_job_bundle_complete(
        self,
        context: Dict[str, Any],
        job_bundle: ApiJobBundle,
        fetched_data: Dict[str, Any],
    ):
        self.on_after_batch_api_job_bundles_complete(
            context, [(job_bundle, fetched_data)]
        )
        return fetched_data

    def normalize_data(self, context: Dict[str, Any], fetched_data: Any) -> Dict[str, Any]:
        config = context.get("config")
        if config and config.get_save_mode() in ("immediate", "batch"):
            return {"data": []}
        return super().normalize_data(context, fetched_data)

    def _map_job(
        self,
        api_job: ApiJob,
        fetched_data: Dict[str, Any],
        config: DataSourceConfig,
    ) -> List[Dict[str, Any]]:
        job_id = api_job.job_id or api_job.api_name
        raw = fetched_data.get(job_id)
        if raw is None:
            return []
        frame = raw if isinstance(raw, pd.DataFrame) else pd.DataFrame(raw)
        if frame.empty:
            return []
        api_config = config.get_apis().get(api_job.api_name or "")
        mapping = api_config.result_mapping if api_config else {}
        mapped = nh.apply_field_mapping(frame.to_dict("records"), mapping)
        wanted = str((api_job.params or {}).get("ts_code") or "")
        out = []
        for row in self.clean_nan_in_records(mapped):
            index_id = str(row.get("id") or "")
            if wanted and index_id != wanted:
                continue
            if not index_id or not row.get("date"):
                continue
            row["date"] = _plain_date(row.get("date"))
            if not row["date"]:
                continue
            out.append(row)
        return out


def _plain_date(value: Any) -> str:
    text = str(value or "").strip()
    if text.endswith(".0"):
        text = text[:-2]
    if text.lower() in ("nan", "none", "nat"):
        return ""
    return text


def _load_l1_ids(data_manager: Any) -> List[str]:
    if not data_manager:
        return []
    model = data_manager.get_table("sys_data_sw_industry")
    if not model:
        return []
    rows = model.load("level = %s", ("L1",), order_by="id ASC") or []
    ids = [str(row.get("id")) for row in rows if row.get("id")]
    if not ids:
        return []
    if SW_A_SHARE not in ids:
        ids.append(SW_A_SHARE)
    return ids
