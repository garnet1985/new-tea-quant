"""股票当前申万行业。绑定表 sys_map_sw_stock_industry。"""


def _text(value):
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in ("nan", "none", "nat"):
        return None
    if text.endswith(".0"):
        text = text[:-2]
    return text


CONFIG = {
    "table": "sys_map_sw_stock_industry",
    "save_mode": "unified",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
    },
    "apis": {
        "sw_stock_industry": {
            "provider_name": "tushare",
            "method": "get_sw_stock_industry",
            "params": {
                "src": "SW2021",
            },
            "result_mapping": {
                "stock_id": "ts_code",
                "l1_code": lambda row: _text(row.get("l1_code")),
                "l2_code": lambda row: _text(row.get("l2_code")),
                "l3_code": lambda row: _text(row.get("l3_code")),
                "in_date": lambda row: _text(row.get("in_date")),
            },
        },
    },
}
