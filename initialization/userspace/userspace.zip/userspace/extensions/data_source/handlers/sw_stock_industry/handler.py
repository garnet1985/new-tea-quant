"""申万行业成分：31 个一级的最新成分 → sys_sw_stock_industry_map。"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.infra.utils import Utils
from core.modules.data_source.contracts import BaseHandler

logger = logging.getLogger(__name__)

CACHE_KEY = "sw_stock_industry_last_sync"
RENEW_IF_OVER_DAYS = 7


class SwStockIndustryHandler(BaseHandler):
    """一只股票一行。整表替换，保留全市场成分，不按样本股票池截断。"""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if context.get("force_refresh"):
            return None
        dm = context.get("data_manager")
        if not dm:
            return None
        try:
            cache = dm.db_cache.load(CACHE_KEY, field="json") or {}
        except Exception:
            return None
        last = str(cache.get("synced_at") or "").strip()
        if not last:
            return None
        try:
            days = Utils.date.diff_days(last, Utils.date.today())
        except Exception:
            return None
        if days < RENEW_IF_OVER_DAYS:
            logger.info(
                "sw_stock_industry 距上次同步 %s 天（<%s），跳过；强制请 renew -f",
                days,
                RENEW_IF_OVER_DAYS,
            )
            return {"data": []}
        return None

    def on_before_save(
        self, context: Dict[str, Any], normalized_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        rows = self.clean_nan_in_records((normalized_data or {}).get("data") or [])
        by_stock: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            stock_id = str(row.get("stock_id") or "").strip()
            if not stock_id or not row.get("l1_code"):
                continue
            in_date = row.get("in_date")
            if in_date is not None:
                row["in_date"] = str(in_date).strip() or None
            by_stock[stock_id] = row
        if not by_stock:
            logger.warning("sw_stock_industry 本次无成分，保留已有表")
            return {"data": []}
        model = context["data_manager"].get_table("sys_sw_stock_industry_map")
        model.delete_all()
        model.save_records(list(by_stock.values()))
        try:
            context["data_manager"].db_cache.save(
                CACHE_KEY, json={"synced_at": Utils.date.today()}
            )
        except Exception:
            logger.warning("写入 %s 失败", CACHE_KEY, exc_info=True)
        logger.info("sw_stock_industry 写入 %s 行", len(by_stock))
        return {"data": []}
