"""
Trade Calendar Handler 配置。绑定表 sys_trade_calendar。

全量拉取 Tushare trade_cal（SSE），自然日 + is_open。
仅传 start_date（userspace/core data.json）；不传 end_date，由 Tushare 返回到其自然上界。
同步元数据写入 sys_cache（trade_calendar_last_sync）。
"""
from core.infra.utils import Utils

MARKET_SSE = "SSE"
CACHE_KEY_LAST_SYNC = "trade_calendar_last_sync"
# 距上次成功 sync 不足该天数则跳过（force_refresh 除外）
RENEW_IF_OVER_DAYS = 30

CONFIG = {
    "table": "sys_trade_calendar",
    "save_mode": "unified",
    "needs_stock_grouping": False,
    "renew": {
        "type": "refresh",
        "date_format": Utils.date.PERIOD_DAY,
        "renew_if_over_days": {
            "value": RENEW_IF_OVER_DAYS,
        },
    },
    "apis": {
        "trade_cal": {
            "provider_name": "tushare",
            "method": "get_trade_cal",
            "params": {
                "exchange": MARKET_SSE,
            },
            "result_mapping": {
                "market": lambda _row: MARKET_SSE,
                "cal_date": "cal_date",
                "is_open": "is_open",
            },
        },
    },
}
