# Post Process 扩展

后续处理是**全局**的：扫描任意策略结束后，自动跑所有 ``is_enabled: true`` 的 PostProcessor。
不在策略 ``settings.scanner`` 里配置。

```text
post_process/
├── adapters/
│   ├── tradable_opportunity.py
│   ├── report_template.py
│   ├── presenter/
│   ├── email_sender/
│   ├── wechat_sender/
│   ├── sms_sender/
│   └── demo_broker/
└── post_processors/
    ├── presenter/          # is_enabled: true（默认）
    └── demo_handoff/       # is_enabled: false（演示装配）
```

启用 / 关闭：改对应 ``post_processor.yaml`` 的 ``is_enabled``。
勿同时启用会重复发信的多套装配。

详见 `adapters/README.md` 与 `core/modules/post_process/docs/`。
