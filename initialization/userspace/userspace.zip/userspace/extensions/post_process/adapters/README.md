# Adapters（后续处理积木）

每个子目录一个 adapter：

```text
adapters/
├── tradable_opportunity.py   # 演示用可交易机会基类（非 adapter）
├── report_template.py        # sender 共用报告渲染
├── presenter/                # 会话视图 + 同策略 price 回测历史
├── email_sender/
│   ├── report.template.txt
│   ├── opportunity_line.template.txt
│   └── token.example.txt     # 复制为 token.txt 填密钥
├── wechat_sender/            # 同上模版 + webhook token
├── sms_sender/
└── demo_broker/              # A 股演示：engine=easytrader|vnpy|qmt
```

- 实现：`adapter.py` 继承 `BaseAdapter`，实现 `run(session, config, deps)`
- 可选：`settings.py` 提供默认 `settings` / `config`
- example 默认 **`dry_run: true`**，只打日志不真发信/真下单
- sender：改 `report.template.txt` / `opportunity_line.template.txt`；密钥用 `token.example.txt` → `token.txt`

`presenter` 同时承担「读历史」与「可选 CLI 展示」；结构化结果经 `deps["presenter"]` 供 UI / 下游使用。

`demo_broker` 用 ``config.engine`` 切换三种演示后端；真下单示例在源码里注释掉。

可交易机会（仅交易类 adapter 用）::

```python
from userspace.extensions.post_process.adapters import TradableOpportunity
```
