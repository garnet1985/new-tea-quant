"""demo_broker — A 股交易演示壳。

将标准机会转为 ``TradableOpportunity`` 后，按 ``config.engine`` 走三种演示后端之一：

- ``easytrader`` — 对齐 https://github.com/shidenggui/easytrader
- ``vnpy`` — 对齐 vn.py Gateway / 引擎调用形状
- ``qmt`` — 对齐迅投 miniQMT / xtquant 调用形状

默认 ``dry_run: true``：只打日志。真下单示例代码保留在各 ``_submit_*`` 内并注释掉，
不依赖本机安装对应 SDK；打开 dry_run=false 且取消注释前请自行安装客户端/库。

合规提示：easytrader / 非官方接口不稳定且可能违反券商条款；仅作演示。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport
from userspace.extensions.post_process.adapters.tradable_opportunity import (
    TradableOpportunity,
)

_ENGINES = frozenset({"easytrader", "vnpy", "qmt"})


class DemoBrokerAdapter(BaseAdapter):
    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        dry_run = bool(config.get("dry_run", True))
        engine = str(config.get("engine") or "easytrader").strip().lower()
        if engine not in _ENGINES:
            raise ValueError(
                f"demo_broker.engine 无效: {engine!r}，可选 {sorted(_ENGINES)}"
            )

        size_kind = str(config.get("size_kind") or "qty").strip() or "qty"
        default_notional = float(config.get("default_notional") or 10000.0)
        default_qty = config.get("default_qty")
        default_weight = config.get("default_weight")
        missing_qty = str(config.get("missing_qty") or "use_default").strip()

        hist = deps.get("presenter")
        acks: List[Dict[str, Any]] = []

        for report in session.strategies:
            for opp in report.opportunities:
                tradable = self._to_tradable(
                    opp,
                    strategy_name=report.strategy_name,
                    goal=dict(report.goal or {}),
                    size_kind=size_kind,
                    default_notional=default_notional,
                    default_qty=default_qty,
                    default_weight=default_weight,
                    missing_qty=missing_qty,
                )
                if tradable is None:
                    continue

                ok, err = tradable.validate()
                if not ok:
                    self.log_warning(f"skip invalid tradable {opp.id}: {err}")
                    continue

                order = self._order_fields(tradable)
                if dry_run:
                    status = "dry_run_accepted"
                    self.log_info(
                        f"demo_broker[{engine}] DRY {order['symbol']} "
                        f"side={order['side']} price={order['price']} "
                        f"amount={order['amount']}"
                    )
                else:
                    status = self._submit(engine, order, config)
                    self.log_info(
                        f"demo_broker[{engine}] {status} {order['symbol']} "
                        f"amount={order['amount']}"
                    )

                acks.append(
                    {
                        "opportunity_id": tradable.opportunity_id,
                        "entity_id": tradable.entity_id,
                        "engine": engine,
                        "dry_run": dry_run,
                        "status": status,
                        "order": order,
                        "has_presenter_deps": hist is not None,
                    }
                )

        return acks

    def _to_tradable(
        self,
        opp: Any,
        *,
        strategy_name: str,
        goal: Dict[str, Any],
        size_kind: str,
        default_notional: float,
        default_qty: Any,
        default_weight: Any,
        missing_qty: str,
    ) -> Optional[TradableOpportunity]:
        kwargs: Dict[str, Any] = {
            "strategy_name": strategy_name,
            "goal": goal,
            "size_kind": size_kind,
        }
        if size_kind == "notional":
            kwargs["notional"] = default_notional
        elif size_kind == "qty":
            if default_qty is None and missing_qty == "skip_signal":
                self.log_info(f"skip {opp.id}: no qty")
                return None
            kwargs["qty"] = float(default_qty or 100.0)
        elif size_kind == "weight":
            kwargs["weight"] = float(
                default_weight if default_weight is not None else 0.05
            )
        else:
            self.log_warning(f"skip {opp.id}: bad size_kind={size_kind}")
            return None
        return TradableOpportunity.from_opportunity(opp, **kwargs)

    @staticmethod
    def _order_fields(tradable: TradableOpportunity) -> Dict[str, Any]:
        """统一成「代码 / 价 / 股数」；A 股演示默认整百股。"""
        price = float(tradable.trigger_price or 0.0)
        if tradable.size_kind == "qty" and tradable.qty is not None:
            amount = int(float(tradable.qty))
        elif tradable.size_kind == "notional" and tradable.notional and price > 0:
            amount = int(float(tradable.notional) / price / 100) * 100
            amount = max(amount, 100)
        else:
            # weight：演示壳没有账户权益，退回默认 100 股
            amount = 100
        symbol = str(tradable.entity_id or "").strip()
        # easytrader / 部分接口常用 6 位；QMT 常用 000001.SZ
        code6 = symbol.split(".")[0] if symbol else ""
        return {
            "symbol": symbol,
            "code": code6,
            "side": "buy",
            "price": price,
            "amount": amount,
            "goal": dict(tradable.goal or {}),
        }

    def _submit(
        self, engine: str, order: Dict[str, Any], config: Dict[str, Any]
    ) -> str:
        if engine == "easytrader":
            return self._submit_easytrader(order, config)
        if engine == "vnpy":
            return self._submit_vnpy(order, config)
        return self._submit_qmt(order, config)

    # ------------------------------------------------------------------
    # easytrader（演示形状；真下单请自行安装并取消注释）
    # ------------------------------------------------------------------
    def _submit_easytrader(
        self, order: Dict[str, Any], config: Dict[str, Any]
    ) -> str:
        _ = config
        self.log_info(
            f"[easytrader stub] buy code={order['code']} "
            f"price={order['price']} amount={order['amount']}"
        )
        # --- 演示代码（默认注释）---
        # import easytrader
        # user = easytrader.use(
        #     str(config.get("easytrader_broker") or "universal_client")
        # )
        # # 客户端登录信息勿写入 git；用本地配置文件
        # user.prepare(str(config.get("easytrader_prepare") or "account.json"))
        # result = user.buy(
        #     order["code"],
        #     price=order["price"],
        #     amount=order["amount"],
        # )
        # return f"easytrader:{result}"
        raise NotImplementedError(
            "demo_broker/easytrader: 真下单未启用；保持 dry_run=true，"
            "或自行安装 easytrader 并取消 _submit_easytrader 内注释"
        )

    # ------------------------------------------------------------------
    # vn.py（演示形状）
    # ------------------------------------------------------------------
    def _submit_vnpy(self, order: Dict[str, Any], config: Dict[str, Any]) -> str:
        _ = config
        self.log_info(
            f"[vnpy stub] send order {order['symbol']} "
            f"price={order['price']} volume={order['amount']}"
        )
        # --- 演示代码（默认注释）---
        # from vnpy.trader.constant import Direction, Exchange, OrderType
        # from vnpy.trader.object import OrderRequest
        # from vnpy.trader.engine import MainEngine
        # # 假定外部已启动 MainEngine + 股票 Gateway 并写入 config["vnpy_gateway"]
        # main_engine: MainEngine = config["vnpy_main_engine"]
        # gateway_name = str(config.get("vnpy_gateway") or "XTP")
        # vt_symbol = order["symbol"]  # 如 000001.SZ
        # code, exchange_suf = vt_symbol.split(".")
        # exchange = Exchange.SZSE if exchange_suf.upper() == "SZ" else Exchange.SSE
        # req = OrderRequest(
        #     symbol=code,
        #     exchange=exchange,
        #     direction=Direction.LONG,
        #     type=OrderType.LIMIT,
        #     volume=float(order["amount"]),
        #     price=float(order["price"]),
        #     reference="ntq_demo",
        # )
        # vt_orderid = main_engine.send_order(req, gateway_name)
        # return f"vnpy:{vt_orderid}"
        raise NotImplementedError(
            "demo_broker/vnpy: 真下单未启用；保持 dry_run=true，"
            "或自行接入 vn.py MainEngine 并取消 _submit_vnpy 内注释"
        )

    # ------------------------------------------------------------------
    # 迅投 miniQMT / xtquant（演示形状）
    # ------------------------------------------------------------------
    def _submit_qmt(self, order: Dict[str, Any], config: Dict[str, Any]) -> str:
        _ = config
        self.log_info(
            f"[qmt/xtquant stub] order_stock {order['symbol']} "
            f"price={order['price']} volume={order['amount']}"
        )
        # --- 演示代码（默认注释）---
        # from xtquant import xtconstant
        # from xtquant.xttrader import StockAccount, XtQuantTrader
        # path = str(config.get("qmt_userdata_path") or "")
        # session_id = int(config.get("qmt_session_id") or 123456)
        # account_id = str(config.get("qmt_account_id") or "")
        # trader = XtQuantTrader(path, session_id)
        # account = StockAccount(account_id)
        # trader.start()
        # trader.connect()
        # # 股票同步报单（限价买）
        # order_id = trader.order_stock(
        #     account,
        #     order["symbol"],
        #     xtconstant.STOCK_BUY,
        #     int(order["amount"]),
        #     xtconstant.FIX_PRICE,
        #     float(order["price"]),
        # )
        # return f"qmt:{order_id}"
        raise NotImplementedError(
            "demo_broker/qmt: 真下单未启用；保持 dry_run=true，"
            "或安装 miniQMT/xtquant 并取消 _submit_qmt 内注释"
        )
