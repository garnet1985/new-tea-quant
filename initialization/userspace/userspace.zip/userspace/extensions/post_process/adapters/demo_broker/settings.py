settings = {
    "dry_run": True,
    # easytrader | vnpy | qmt
    "engine": "easytrader",
    "size_kind": "qty",
    "default_notional": 10000.0,
    "default_qty": 100,
    "default_weight": 0.05,
    "missing_qty": "use_default",
    # --- engine 专用（真下单时再用；勿把密钥写进 git）---
    # "easytrader_broker": "universal_client",
    # "easytrader_prepare": "account.json",
    # "vnpy_gateway": "XTP",
    # "qmt_userdata_path": "C:/QMT/userdata_mini",
    # "qmt_account_id": "",
    # "qmt_session_id": 123456,
}
