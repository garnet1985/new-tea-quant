# presenter

扫描会话的默认后处理适配器：组装可展示/可复用的会话视图（含回测历史）。

## 做什么

1. **加载**：对会话中每个策略，取当前可用的最新 `price_factor` 产物，按会话汇总 + 按标的汇总。
2. **展示**：可选打印策略报告与机会；`show_history: true` 时附带回测摘要。
3. **返回**：结构化 dict（含 `strategies`、`backtest_history`），供 UI 或其它 adapter 经 `deps["presenter"]` 使用。

## settings

| 键 | 默认 | 说明 |
|----|------|------|
| `print` | `true` | 是否打印到 stdout |
| `show_history` | `true` | 打印时是否附带回测历史 |

## 返回结构（摘要）

```text
{
  "scan_date": "...",
  "emitted_at": "...",
  "strategies": [ { strategy_name, opportunities, ... } ],
  "backtest_history": {
    "<strategy>": {
      "layer": "price",
      "session_summary": {...} | null,
      "by_stock": { "<entity_id>": {...} },
      "error": null | "..."
    }
  }
}
```
