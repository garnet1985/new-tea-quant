"""presenter — 展示 ScanSessionReport，并加载同策略 price 层回测历史。

职责:
1. 读取各策略「当前可用」的 price_factor 最新产物（与旧 scan 历史统计同源）
2. 可选命令行展示；返回结构化 dict，供 UI / 其它 adapter 经 ``deps['presenter']`` 使用
"""

from __future__ import annotations

from typing import Any, Dict, List

from core.infra.cmd_layout import i
from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport


class PresenterAdapter(BaseAdapter):
    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> Dict[str, Any]:
        _ = deps
        show_history = bool(config.get("show_history", True))
        print_enabled = bool(config.get("print", True))

        history_by_strategy = self._load_histories(session)

        if print_enabled:
            self._print_session(session, history_by_strategy, show_history=show_history)

        # UI / 下游统一消费此结构
        return {
            "scan_date": session.scan_date,
            "emitted_at": session.emitted_at,
            "strategies": [
                {
                    "strategy_name": r.strategy_name,
                    "strategy_version": r.strategy_version,
                    "scan_date": r.scan_date,
                    "goal": dict(r.goal or {}),
                    "opportunities": [
                        {
                            "id": o.id,
                            "entity_id": o.entity_id,
                            "entity_name": o.entity_name,
                            "trigger_date": o.trigger_date,
                            "trigger_price": o.trigger_price,
                            "snapshot": dict(o.snapshot or {}),
                        }
                        for o in r.opportunities
                    ],
                }
                for r in session.strategies
            ],
            "backtest_history": history_by_strategy,
        }

    def _load_histories(self, session: ScanSessionReport) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for report in session.strategies:
            name = str(report.strategy_name or "").strip()
            if not name:
                continue
            entity_ids = [
                str(o.entity_id or "").strip()
                for o in report.opportunities
                if str(o.entity_id or "").strip()
            ]
            out[name] = self._load_one_strategy_history(name, entity_ids)
        return out

    @staticmethod
    def _load_one_strategy_history(
        strategy_name: str, entity_ids: List[str]
    ) -> Dict[str, Any]:
        """优先走 strategy 内既有 enrichment（latest price_factor）。"""
        try:
            from core.modules.strategy.core.engines.scanner.helpers.price_history_enrichment import (
                build_price_history_for_adapter,
            )

            raw = build_price_history_for_adapter(strategy_name, entity_ids)
        except Exception as exc:
            return {
                "layer": "price",
                "session_summary": None,
                "by_stock": {},
                "error": str(exc),
            }
        return {
            "layer": "price",
            "session_summary": raw.get("session_summary"),
            "by_stock": dict(raw.get("by_stock") or {}),
            "error": None,
        }

    def _print_session(
        self,
        session: ScanSessionReport,
        history_by_strategy: Dict[str, Any],
        *,
        show_history: bool,
    ) -> None:
        print("\n" + "=" * 80)
        print(f"{i('bar_chart')} 扫描会话")
        print("=" * 80)
        print(f"会话扫描日: {session.scan_date}")
        if session.emitted_at:
            print(f"生成时间: {session.emitted_at}")
        print(f"策略报告数: {len(session.strategies)}")
        print("=" * 80)

        if not session.strategies:
            print("\n没有策略报告")
            print("=" * 80)
            return

        for report in session.strategies:
            print(f"\n--- 策略: {report.strategy_name} ---")
            if report.strategy_version:
                print(f"  版本: {report.strategy_version}")
            print(f"  扫描日: {report.scan_date}")
            print(f"  机会数: {len(report.opportunities)}")
            if report.goal:
                print(f"  目标摘要键: {', '.join(sorted(report.goal.keys()))}")

            if not report.opportunities:
                print("  （无机会）")
            else:
                for idx, opp in enumerate(report.opportunities, 1):
                    print(f"\n  【机会 {idx}】 {opp.id}")
                    label = opp.entity_name or opp.entity_id
                    print(f"    标的: {label} ({opp.entity_id})")
                    print(f"    触发日: {opp.trigger_date}")
                    print(f"    触发价: {opp.trigger_price:.2f}")
                    if opp.snapshot:
                        print(f"    快照: {opp.snapshot}")

            if show_history:
                hist = history_by_strategy.get(report.strategy_name) or {}
                self._print_history(report.strategy_name, hist, report)

        print("\n" + "=" * 80)

    def _print_history(
        self,
        strategy_name: str,
        hist: Dict[str, Any],
        report: Any,
    ) -> None:
        print(f"\n  {i('bar_chart')} 回测历史（price 层 · {strategy_name}）")
        print("  " + "-" * 60)
        if hist.get("error"):
            print(f"  加载失败: {hist['error']}")
            return

        summary = hist.get("session_summary")
        if isinstance(summary, dict) and summary:
            total = summary.get("total_investments", 0)
            win_rate = summary.get("win_rate", 0)
            # overall_report 里 win_rate 可能是百分数或小数，兼容两种
            wr = float(win_rate or 0)
            if wr <= 1.0:
                wr_pct = wr * 100
            else:
                wr_pct = wr
            avg_roi = summary.get("avg_roi", summary.get("avg_return", 0))
            try:
                avg_pct = float(avg_roi or 0) * 100
            except (TypeError, ValueError):
                avg_pct = 0.0
            print("  整体:")
            if total:
                print(
                    f"    投资次数={total}  "
                    f"胜率={wr_pct:.1f}%  平均收益={avg_pct:.2f}%"
                )
            else:
                print("    （会话汇总无投资记录）")
        else:
            print("  整体: （无 overall_report / 尚未跑过 price 回测）")

        by_stock = hist.get("by_stock") if isinstance(hist.get("by_stock"), dict) else {}
        seen = set()
        for opp in report.opportunities:
            sid = str(opp.entity_id or "").strip()
            if not sid or sid in seen:
                continue
            seen.add(sid)
            stats = by_stock.get(sid)
            if not isinstance(stats, dict) or not stats:
                print(f"  · {opp.entity_name or sid} ({sid}): 无该标的历史")
                continue
            wr = float(stats.get("win_rate") or 0) * 100
            avg = float(stats.get("avg_return") or 0) * 100
            n = stats.get("completed_investments", 0)
            print(
                f"  · {opp.entity_name or sid} ({sid}): "
                f"完成={n} 胜率={wr:.1f}% 平均收益={avg:.2f}%"
            )
