"""presenter adapter 默认配置。"""

settings = {
    "print": True,
    "show_history": True,
}
