"""sms_sender — 短信通知（架子 / dry_run 默认开）。

正文来自 ``report.template.txt``；密钥放 ``token.txt``（见 ``token.example.txt``）。
"""

from __future__ import annotations

from typing import Any, Dict, List

from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport
from userspace.extensions.post_process.adapters.report_template import (
    adapter_dir,
    load_token,
    render_sender_report,
)


class SmsSenderAdapter(BaseAdapter):
    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> Dict[str, Any]:
        dry_run = bool(config.get("dry_run", True))
        phones: List[str] = []
        raw = config.get("to") or []
        if isinstance(raw, str) and raw.strip():
            phones = [raw.strip()]
        elif isinstance(raw, list):
            phones = [str(x).strip() for x in raw if str(x).strip()]

        body = render_sender_report(session, config, adapter_file=__file__)
        rows_hint = sum(len(r.opportunities) for r in session.strategies)
        directory = adapter_dir(__file__)
        token = load_token(directory)
        hist = deps.get("presenter")
        self.log_info(
            f"sms_sender to={phones or ['(unset)']} dry_run={dry_run} "
            f"token={'set' if token else 'unset'} "
            f"has_presenter_deps={hist is not None} chars={len(body)}"
        )
        if dry_run:
            self.log_info("sms_sender dry_run preview:\n" + body.rstrip())
            return {
                "channel": "sms",
                "dry_run": True,
                "to": phones,
                "body": body,
                "opportunity_count": rows_hint,
            }

        if not phones:
            raise RuntimeError("sms_sender: 未配置 to")
        if not token:
            raise RuntimeError(
                "sms_sender: 缺少 token.txt（先复制 token.example.txt → token.txt）"
            )
        # TODO: 接短信网关（Twilio / 国内云厂商等）
        raise NotImplementedError("sms_sender: 真发尚未实现，请保持 dry_run=true")
