settings = {
    "dry_run": True,
    "to": [],
    # 留空则读同目录 report.template.txt / opportunity_line.template.txt
    "report_template": "",
    "line_template": "",
    "default_qty": 100,
    "default_weight": 0.05,
    "default_notional": None,
}
