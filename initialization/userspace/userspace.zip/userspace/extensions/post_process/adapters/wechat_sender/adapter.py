"""wechat_sender — 企业微信 / 群机器人通知（架子 / dry_run 默认开）。

正文来自 ``report.template.txt``；Webhook 放 ``token.txt``（见 ``token.example.txt``）。
"""

from __future__ import annotations

import os
from typing import Any, Dict

from core.modules.post_process.contracts import BaseAdapter, ScanSessionReport
from userspace.extensions.post_process.adapters.report_template import (
    adapter_dir,
    load_token,
    render_sender_report,
)


class WechatSenderAdapter(BaseAdapter):
    def run(
        self,
        session: ScanSessionReport,
        config: Dict[str, Any],
        deps: Dict[str, Any],
    ) -> Dict[str, Any]:
        dry_run = bool(config.get("dry_run", True))
        env_key = str(config.get("webhook_url_env") or "NTQ_WECOM_WEBHOOK").strip()
        directory = adapter_dir(__file__)
        webhook = str(
            config.get("webhook_url")
            or os.environ.get(env_key)
            or load_token(directory)
            or ""
        ).strip()

        body = render_sender_report(session, config, adapter_file=__file__)
        rows_hint = sum(len(r.opportunities) for r in session.strategies)
        hist = deps.get("presenter")
        self.log_info(
            f"wechat_sender webhook={'set' if webhook else 'unset'} "
            f"dry_run={dry_run} has_presenter_deps={hist is not None} "
            f"opportunities={rows_hint}"
        )
        if dry_run:
            self.log_info("wechat_sender dry_run preview:\n" + body.rstrip())
            return {
                "channel": "wechat",
                "dry_run": True,
                "webhook_set": bool(webhook),
                "body": body,
                "opportunity_count": rows_hint,
            }

        if not webhook:
            raise RuntimeError(
                "wechat_sender: 缺少 webhook（config / env / token.txt；"
                f"见 token.example.txt，env={env_key}）"
            )
        # TODO: POST markdown/text 到企业微信机器人
        raise NotImplementedError("wechat_sender: 真发尚未实现，请保持 dry_run=true")
