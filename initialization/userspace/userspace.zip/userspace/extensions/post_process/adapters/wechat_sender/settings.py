settings = {
    "dry_run": True,
    "webhook_url_env": "NTQ_WECOM_WEBHOOK",
    "webhook_url": "",
    # 留空则读同目录 report.template.txt / opportunity_line.template.txt
    "report_template": "",
    "line_template": "",
    "default_qty": 100,
    "default_weight": 0.05,
    "default_notional": None,
}
