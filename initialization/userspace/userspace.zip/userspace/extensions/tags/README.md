# 标签场景（`userspace/extensions/tags/`）

这里是**标签用户空间**：定义「要算什么标签」（`settings.py`）和「怎么算」（`tag.py`），框架负责按日期和实体批量执行并落库。

## 三个概念

- **scenario（场景）**：一套相关标签的业务问题，对应一个目录；**系统 ID = 目录路径**（如 `demo/market_cap_tier`）
- **tag（标签）**：场景内的一个分类维度（如 `market_cap_tier`）
- **tag_value**：某实体在某日写入的标签值（JSON，常见形态 `{"value": ...}`）

Tag 的用途：Strategy 复用已算好的特征，避免重复算因子；投资上也可作为可复用的判断结论。

当前 userspace 支持：

- **per_entity**（`stock.kline.*` / `index.kline.*` 等）：`entity_based` / `slice_based`，经 BacktestEngine
- **global**（`macro.gdp` / `macro.cpi` 等）：主进程日历推进，落库实体为 `__global__`；`execution.mode` 可省略
- **non_time_series**（`stock.list` / `index.list` 等）：主进程一次计算，落库实体为 `__global__`；`execution.mode` 可省略

路由由 `data.base` 推断，勿手写 `tag_target_type`。详解见 [`USER_GUIDE.md`](USER_GUIDE.md) / [`settings_example.py`](settings_example.py)。

---

## 一分钟上手

1. 打开 [`demo/market_cap_tier/settings.py`](demo/market_cap_tier/settings.py)，确认 `"is_enabled": True`
2. 仓库根目录执行：

```bash
python cli.py tag --scenario demo/market_cap_tier
```

跑所有已启用场景：

```bash
python cli.py tag
```

---

## 从 0 新建场景

### Step 1）复制模板

```bash
python cli.py t -n my_scenario
```

或手动复制：

```bash
cp -R userspace/extensions/tags/_template/empty_scenario userspace/extensions/tags/my_scenario
```

或手动建目录：

```text
userspace/extensions/tags/my_scenario/
├── settings.py
└── tag.py
```

### Step 2）写 `settings.py`

最少建议：`is_enabled`、`meta.key`、`meta.display_name`、`data.base`、`tag_definitions`。  
完整字段见 [`settings_example.py`](settings_example.py) 或 [`_template/empty_scenario/settings.py`](_template/empty_scenario/settings.py)。

要点：

- **不要**在根级写 `name` — 由目录路径决定 `tag_key`；CLI 用 `meta.key`
- 计算区间 / 更新模式 → `calculation`（`update_mode`、`recompute` 等）
- **per_entity** 才需要 `execution.mode`（`entity_based` / `slice_based`）；**global / non_time_series** 可省略
- 数据声明 → `data.base` + `data.required` + `min_required_records`（路由看 base 的 scope×type）
- 业务阈值 → `core`（hooks 里读 `ctx.settings.core`）
- **不要**写 `performance` — per_entity 调度看 `worker.json` → `job_pipeline.tag`

### Step 3）写 `tag.py`

继承 `TagHooks`，实现 `calculate_tag(ctx)`。  
[`_template/empty_scenario/tag.py`](_template/empty_scenario/tag.py) 已列出常用钩子。

### Step 4）运行

```bash
python cli.py tag --scenario my_scenario
```

---

## 目录结构

```text
userspace/extensions/tags/
├── README.md
├── USER_GUIDE.md
├── settings_example.py      # 配置字段 SOT
├── _template/               # 可复制模板（不参与 discovery）
│   └── empty_scenario/
└── demo/
    ├── market_cap_tier/     # 市值档位示例（per_entity）
    ├── macro_rate_stance/   # LPR+Shibor 利率环境（global）
    └── stock_area_cluster/  # 省/市 → 经济区（non_time_series）
        ├── settings.py
        ├── tag.py
        └── README.md
```

---

## 更多说明

- 用户指南：[USER_GUIDE.md](USER_GUIDE.md)
- 模块设计：`core/modules/tag/README.md`
