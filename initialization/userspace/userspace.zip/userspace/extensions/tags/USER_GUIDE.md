# 标签用户指南（userspace）

本指南给「要自己写标签场景」的用户：快速跑通一个场景，并知道如何从示例扩展到可复用资产。

配置字段的完整说明见同目录 [`settings_example.py`](settings_example.py)（SOT）。

---

## 1. 标签场景由什么组成？

每个场景目录通常两份核心文件：

- `settings.py` — 声明算什么、需要什么数据、怎么更新
- `tag.py` — 实现标签计算逻辑（继承 `TagHooks`）

框架负责：发现、按 `data.base` 路由调度、结果落库。  
你负责：标签定义与业务计算。

目录在 `userspace/extensions/tags/` 下；**场景 ID（`tag_key`）= 相对该目录的路径**，例如 `demo/market_cap_tier`。  
CLI / API 请用 `meta.key`（短 alias）；不要在 `settings.py` 根级写 `name`，展示名写在 `meta.display_name`。

---

## 2. 路由：由 `data.base` 决定

不要手写 `tag_target_type`。框架读 base 对应 Data Contract 的 `scope × type`：

| base 示例 | 路由 | 调度 | `execution.mode` |
|-----------|------|------|------------------|
| `stock.kline.daily` / `index.kline.daily` | **per_entity** | BacktestEngine 多进程 | 必填：`entity_based` 或 `slice_based` |
| `macro.gdp` / `macro.cpi` / … | **global** | Tag **主进程**日历推进 | 可省略；写了会 warning 后忽略 |
| `stock.list` / `index.list` | **non_time_series** | Tag **主进程**一次计算 | 可省略；写了会 warning 后忽略 |

补充：

- per_entity 实体池来自 base 的 `list_data_key`（如 `stock.list` / `index.list`）
- global / non_time_series 落库 `entity_id` 为哨兵 `__global__`；钩子仍用 `calculate_tag(ctx)`
- non_time_series 无日历循环；落库 `as_of` 取计算窗 `end_date`

---

## 3. 最小可运行模板（per_entity）

目录：

```text
userspace/extensions/tags/my_scenario/
├── settings.py
└── tag.py
```

`settings.py` 示例：

```python
settings = {
    "is_enabled": True,
    "meta": {
        "key": "my_tag",
        "display_name": "我的标签场景",
        "description": "demo",
    },
    "core": {},
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {
            "mode": "entity_based",
            "start_date": "",
            "end_date": "",
        },
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {},
        },
        "required": [],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {
            "name": "my_tag",
            "display_name": "我的标签",
            "description": "demo",
        },
    ],
}
```

`tag.py` 示例：

```python
from typing import Any, Dict, Optional

from core.modules.tag.contracts import TagContext, TagHooks


class MyTagHooks(TagHooks):
    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        klines = ctx.data.items.get("stock.kline.daily") or []
        if not klines:
            return None
        latest = klines[-1]
        return {
            "value": {
                "as_of_date": ctx.data.now,
                "close": latest.get("close"),
            }
        }
```

---

## 4. global 时序示例（如 GDP）

`settings.py` 要点：`data.base.data_key` 用 `macro.*`；**不必**写 `execution.mode`（时间窗仍可写在 `execution.start_date` / `end_date`）。

```python
settings = {
    "is_enabled": True,
    "meta": {
        "key": "macro_gdp_tag",
        "display_name": "GDP 相关标签",
    },
    "calculation": {
        "update_mode": "incremental",
        "execution": {
            "start_date": "",
            "end_date": "",
        },
    },
    "data": {
        "base": {"data_key": "macro.gdp", "params": {}},
        "required": [],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {"name": "gdp_regime", "display_name": "GDP 状态"},
    ],
}
```

```python
from typing import Any, Dict, Optional

from core.modules.tag.contracts import TagContext, TagHooks


class MacroGdpTagHooks(TagHooks):
    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        rows = ctx.data.items.get("macro.gdp") or []
        if not rows:
            return None
        latest = rows[-1]
        return {
            "value": {
                "as_of_date": ctx.data.now,
                "quarter": latest.get("quarter"),
                "entity_id": ctx.data.entity_id,  # "__global__"
            }
        }
```

主进程按交易日历推进 as_of；季频序列通过 contract `until` 做成可见历史后再进钩子。

---

## 5. non_time_series 示例（如 stock.list）

`data.base` 用非时序 contract（当前如 `stock.list` / `index.list`）。无日历推进：装数后对每个 `tag_definition` **调用一次** `calculate_tag`；`ctx.data.now` / 落库 `as_of` 为计算窗 `end_date`。

```python
settings = {
    "is_enabled": True,
    "meta": {
        "key": "universe_snapshot",
        "display_name": "股票池快照标签",
    },
    "calculation": {
        "update_mode": "refresh",
        "recompute": True,
        "execution": {
            "start_date": "",
            "end_date": "",
        },
    },
    "data": {
        "base": {"data_key": "stock.list", "params": {}},
        "required": [],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {"name": "universe_size", "display_name": "股票池规模"},
    ],
}
```

```python
from typing import Any, Dict, Optional

from core.modules.tag.contracts import TagContext, TagHooks


class UniverseSnapshotHooks(TagHooks):
    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        rows = ctx.data.items.get("stock.list") or []
        return {
            "value": {
                "count": len(rows),
                "as_of_date": ctx.data.now,
                "entity_id": ctx.data.entity_id,  # "__global__"
            }
        }
```

---

## 6. 运行命令

仓库根目录：

```bash
python cli.py tag
python cli.py tag --scenario my_tag
# 或完整路径：
python cli.py tag --scenario demo/market_cap_tier
```

`--scenario` 可用 **`meta.key`** 或目录路径（`tag_key`）。

per_entity 的并发与分片在 `core/default_config/worker.json` → `job_pipeline.tag`（可用 `userspace/system/config/worker.json` 覆盖）；scenario 的 `settings.py` **不要**写 `performance` 块。global / non_time_series 不走该 worker 池。

---

## 7. 参考示例

| 路径 | 说明 |
|------|------|
| [`demo/market_cap_tier/`](demo/market_cap_tier/) | 市值档位 low/mid/high，仅在档位变化日写入（per_entity） |
| [`demo/macro_rate_stance/`](demo/macro_rate_stance/) | LPR+Shibor 利率环境 easing/tightening/stable（global） |
| [`demo/stock_area_cluster/`](demo/stock_area_cluster/) | 省/市 area → 经济区快照（non_time_series） |
| [`settings_example.py`](settings_example.py) | 各字段注释与默认值（含路由说明） |

---

## 8. 常见问题

### Q1：场景没被执行？

- 检查 `settings["is_enabled"]`
- `--scenario` 是否为 `meta.key` 或目录路径（如 `demo/market_cap_tier`）
- 目录下是否同时有 `settings.py` 与 `tag.py`

### Q2：`ctx.data.items` 里没有你要的数据？

- 检查 `data.base` / `data.required` 的 `data_key`
- 检查 hooks 里取数 key 是否与 Data Contract 一致（如 `stock.indicators.daily` / `macro.gdp` / `stock.list`）
- global / non_time_series runner **不会**装载 `required` 里的 per_entity 序列

### Q3：标签写入太多？

- 仅在状态变化时返回非 `None`（参考 `demo/market_cap_tier`）
- 状态写入 `ctx.custom`（多实体请带 `entity_id` 键）
- `tag_definitions[].name` 保持稳定，避免历史定义混乱

### Q4：开发环境只有 500 只股票？

- `userspace/system/config/data.json` 里 `use_sample_stock_list` 会**全局**限制股票池（读 `stock.list`、写 per-stock 表均生效）
- 详见 [`system/config/README.md`](../../system/config/README.md)
- 不影响以 `__global__` 落库的 global / non_time_series 场景

### Q5：写了 `execution.mode` 但 base 是 macro / list？

- 预期行为：校验 **warning**，mode 不参与调度；仍走对应主进程 runner

---

## 9. 相关文档

- 入口：[README.md](README.md)
- 模块设计：`core/modules/tag/docs/DESIGN.md` / `DECISIONS.md`
- 策略 settings 对照：`userspace/strategies/settings_example.py`（`data` / `simulation.execution` ↔ `calculation.execution`）
