# 空白 Tag 场景模板 — 复制整个 empty_scenario/ 到新目录后改名、改 meta、实现 tag.py。
# 字段说明见 ../../settings_example.py（与本文件内容同步）。
# 系统不会扫描 _template/ 目录；复制后请将 is_enabled 设为 True。

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    "is_enabled": False,

    "meta": {
        "key": "empty_tag",
        "display_name": "空白 Tag 场景模板",
        "description": "复制 _template/empty_scenario/ 到新目录后修改；本模板不写入任何 tag 值。",
        "keywords": ["示例"],
        "details": {
            "logic": [
                "示例：在 example_tag_1 条件不满足时使用 example_tag_2",
            ],
        },
        "category": ["your category"],
    },

    # -----------------------------------------------------------------------
    # 2. core — scenario 私有参数（tag.py 里读 ctx.settings.core）
    # -----------------------------------------------------------------------
    "core": {},

    # -----------------------------------------------------------------------
    # 3. calculation — 计算区间与执行模式
    # -----------------------------------------------------------------------
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {
            "mode": "entity_based",
            "start_date": "",
            "end_date": "",
        },
    },

    # -----------------------------------------------------------------------
    # 4. data — 数据契约（与 strategy 命名对齐）
    # -----------------------------------------------------------------------
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {},
            "indicators": {},
        },
        "required": [
            # {"data_key": "macro.gdp", "params": {}},
        ],
        "min_required_records": 0,
    },

    # -----------------------------------------------------------------------
    # 5. tag_definitions — 标签定义
    # -----------------------------------------------------------------------
    "tag_definitions": [
        {
            "name": "example_tag_1",
            "display_name": "example tag 1",
            "description": "标签 1 说明",
        },
        {
            "name": "example_tag_2",
            "display_name": "example tag 2",
            "description": "举例：当 example_tag_1 条件不满足时使用的互斥标签",
        },
    ],
}
