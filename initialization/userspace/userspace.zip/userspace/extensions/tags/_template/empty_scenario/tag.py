#!/usr/bin/env python3
"""空白 Tag 场景模板 — 复制后实现 calculate_tag。"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence

from core.modules.tag.contracts import TagCalendarAsOfResult, TagContext, TagHooks

__all__ = ["EmptyTagHooks"]


class EmptyTagHooks(TagHooks):
    """空白 hooks：复制后重命名，实现 ``calculate_tag``。"""

    def to_entity_list(
        self, ctx: TagContext, entity_list: Sequence[str]
    ) -> Sequence[str]:
        """per_entity 开跑前过滤实体池（默认原样返回）。"""
        return super().to_entity_list(ctx, entity_list)

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        """返回 ``{"value": ...}`` 或 ``None``（本日不写）。"""
        _ = ctx
        return None

    def on_calendar_asof(self, ctx: TagContext) -> TagCalendarAsOfResult:
        """``slice_based`` 时覆盖；默认走 ``calculate_tag``。"""
        return super().on_calendar_asof(ctx)
