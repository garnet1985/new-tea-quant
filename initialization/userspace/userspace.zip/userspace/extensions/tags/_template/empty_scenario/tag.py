#!/usr/bin/env python3
"""空白 Tag 场景模板 — 复制后在此实现 calculate_tag 等钩子。"""

from __future__ import annotations

from typing import Any, Dict, Optional

from core.modules.tag.contracts import TagCalendarAsOfResult, TagContext, TagHooks

__all__ = ["EmptyTagHooks"]


class EmptyTagHooks(TagHooks):
    """
    空白 Tag hooks 模板。

    复制到新 scenario 目录后：
    1. 重命名本类（如 ``MarketCapTierTagHooks``）
    2. 在 ``calculate_tag`` 中实现打标逻辑
    3. 按需重写 ``on_calendar_asof``（``calculation.execution.mode: slice_based``）
    """

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        """
        计算单个 tag 值（必填）。

        entity_based：按实体时间轴逐日调用。
        slice_based：未重写 ``on_calendar_asof`` 时也会走本方法。

        返回 None 表示本日不写 tag；否则返回：
        ``{"value": ..., "start_date": "...", "end_date": "..."}``

        常用上下文：
        - ``ctx.data.now`` / ``ctx.data.entity_id`` / ``ctx.data.tag_definition``
        - ``ctx.data.items[data_key]`` — 按 data_key 索引的历史数据
        - ``ctx.settings.core`` — settings.core 业务参数
        - ``ctx.custom`` — 跨日可写状态（多实体时请带 entity_id 键）
        """
        _ = ctx
        return None

    def on_calendar_asof(self, ctx: TagContext) -> TagCalendarAsOfResult:
        """
        日历横截面钩子（``calculation.execution.mode: slice_based`` 且重写后生效）。

        ``ctx.data.by_entity`` 为当日全市场数据视图；
        ``ctx.data.calendar["session_state"]`` 为跨日状态（同 strategy）。
        默认：不写 tag，仅透传 session_state。
        """
        return super().on_calendar_asof(ctx)
