# 宏观利率环境 Tag（global demo）

联合 **LPR**（`macro.lpr`）与 **Shibor**（`macro.shibor`）判断融资环境大方向，落库实体为 `__global__`。

| 标签值 | 含义 |
|--------|------|
| `easing` | 利率下行 → 宽松 |
| `tightening` | 利率上行 → 紧缩 |
| `stable` | 变动不足阈值，或双源冲突 |

默认字段：`lpr_1_y`、`three_month`；阈值 5bp（`settings.core` 可改）。仅在 stance **变化日**写入。

```bash
python cli.py tag --scenario macro_rate_stance --dry-run
# 或
python cli.py tag --scenario demo/macro_rate_stance --dry-run
```

启发式演示，不是完整宏观模型。
