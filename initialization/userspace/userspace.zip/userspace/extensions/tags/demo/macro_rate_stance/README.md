# 宏观利率环境（global demo）

联合 **LPR**（`macro.lpr`）与 **Shibor**（`macro.shibor`）判断融资环境方向，落库实体为 `__global__`。

方向本身是三个标签，纵轴和列表上看到的是标签名。`value` 只保留当时的利率读数，给悬停。

| 标签 | 含义 |
|------|------|
| 宽松 | 利率下行 |
| 平稳 | 变动不足阈值，或双源冲突 |
| 紧缩 | 利率上行 |

默认字段：`lpr_1_y`、`three_month`；阈值 5bp（`settings.core` 可改）。只在方向**变化日**写入当前标签。

```bash
python cli.py tag --scenario macro_rate_stance --dry-run
# 或
python cli.py tag --scenario demo/macro_rate_stance --dry-run
```

启发式演示，不是完整宏观模型。改完配置后需要重新跑一遍，旧的「利率环境」定义会被清掉。
