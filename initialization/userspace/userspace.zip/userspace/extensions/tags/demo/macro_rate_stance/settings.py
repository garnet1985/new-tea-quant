"""利率环境：宽松 / 平稳 / 紧缩三个标签，只在方向变化日写入当前标签。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "macro_rate_stance",
        "display_name": "宏观利率环境",
        "description": "LPR 与 Shibor 的方向分成宽松、平稳、紧缩；只在方向变化日写入当前标签",
        "keywords": ["macro", "lpr", "shibor", "global"],
        "category": ["demo", "macro"],
    },
    "core": {
        "lpr_field": "lpr_1_y",
        "shibor_field": "three_month",
        "lpr_threshold": 0.05,
        "shibor_threshold": 0.05,
    },
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {"start_date": "", "end_date": ""},
    },
    "data": {
        "base": {"data_key": "macro.lpr"},
        "required": [{"data_key": "macro.shibor"}],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {
            "name": "easing",
            "display_name": "宽松",
            "description": "LPR 与 Shibor 整体下行",
        },
        {
            "name": "stable",
            "display_name": "平稳",
            "description": "变动不足阈值，或两个利率方向冲突",
        },
        {
            "name": "tightening",
            "display_name": "紧缩",
            "description": "LPR 与 Shibor 整体上行",
        },
    ],
}
