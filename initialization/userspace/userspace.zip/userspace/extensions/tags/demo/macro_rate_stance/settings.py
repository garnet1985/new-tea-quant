"""
利率环境 Tag 场景（global）

联合 LPR（政策锚定）与 Shibor（市场资金面）判断融资环境大方向：
easing / tightening / stable。仅在 stance 变化日写入。
"""

settings = {
    "is_enabled": True,

    "meta": {
        "key": "macro_rate_stance",
        "display_name": "宏观利率环境",
        "description": (
            "用 LPR + Shibor 方向变化标注融资环境宽松/紧缩/平稳；"
            "启发式 demo，非完整宏观模型"
        ),
        "keywords": ["macro", "lpr", "shibor", "global"],
        "category": ["demo", "macro"],
    },

    "core": {
        # 利率字段（与库内列名一致）
        "lpr_field": "lpr_1_y",
        "shibor_field": "three_month",
        # 变动阈值（百分点）；|Δ| >= threshold 才算有方向
        "lpr_threshold": 0.05,
        "shibor_threshold": 0.05,
    },

    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        # global：不需要 execution.mode
        "execution": {
            "start_date": "",
            "end_date": "",
        },
    },

    "data": {
        "base": {
            "data_key": "macro.lpr",
            "params": {},
        },
        "required": [
            {"data_key": "macro.shibor", "params": {}},
        ],
        "min_required_records": 0,
    },

    "tag_definitions": [
        {
            "name": "macro_rate_stance",
            "display_name": "利率环境",
            "description": (
                "easing=宽松（利率下行）；tightening=紧缩（利率上行）；"
                "stable=平稳或双源冲突；仅在变化日写入"
            ),
        },
    ],
}
