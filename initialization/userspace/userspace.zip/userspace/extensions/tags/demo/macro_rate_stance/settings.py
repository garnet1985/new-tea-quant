"""利率环境 Tag（global）：LPR + Shibor → easing / tightening / stable。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "macro_rate_stance",
        "display_name": "宏观利率环境",
        "description": "LPR + Shibor 方向变化标注融资环境；启发式 demo",
        "keywords": ["macro", "lpr", "shibor", "global"],
        "category": ["demo", "macro"],
    },
    "core": {
        "lpr_field": "lpr_1_y",
        "shibor_field": "three_month",
        "lpr_threshold": 0.05,
        "shibor_threshold": 0.05,
    },
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {"start_date": "", "end_date": ""},
    },
    "data": {
        "base": {"data_key": "macro.lpr"},
        "required": [{"data_key": "macro.shibor"}],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {
            "name": "macro_rate_stance",
            "display_name": "利率环境",
            "description": "easing / tightening / stable；仅在变化日写入",
        },
    ],
}
