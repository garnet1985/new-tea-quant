#!/usr/bin/env python3
"""宏观利率环境 Tag：LPR + Shibor，仅在 stance 变化日写入。"""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.tag.contracts import TagContext, TagHooks

LPR_KEY = DATA_KEY.MACRO_LPR
SHIBOR_KEY = DATA_KEY.MACRO_SHIBOR
TAG_NAME = "macro_rate_stance"
VALID = frozenset({"easing", "tightening", "stable"})
STATE_KEY = "last_stance:__global__"


class MacroRateStanceTagHooks(TagHooks):
    """global 时序：双源利率方向 → stance。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name != TAG_NAME:
            return None

        core = ctx.settings.core if isinstance(ctx.settings.core, dict) else {}
        lpr = _signal(
            ctx.data.items.get(LPR_KEY) or [],
            field=str(core.get("lpr_field") or "lpr_1_y"),
            threshold=_float(core.get("lpr_threshold"), 0.05),
        )
        shibor = _signal(
            ctx.data.items.get(SHIBOR_KEY) or [],
            field=str(core.get("shibor_field") or "three_month"),
            threshold=_float(core.get("shibor_threshold"), 0.05),
        )
        if lpr is None or shibor is None:
            return None

        stance = _combine(lpr, shibor)
        if stance not in VALID:
            return None

        last = ctx.custom.get(STATE_KEY)
        if last not in VALID:
            prior = ctx.data.prior_value
            raw = prior
            if isinstance(prior, dict):
                raw = prior.get("value") if "value" in prior else prior.get("stance")
            if isinstance(raw, str) and raw in VALID:
                last = raw
                ctx.custom[STATE_KEY] = raw
        if last in VALID and last == stance:
            return None

        ctx.custom[STATE_KEY] = stance
        return {"value": stance}


def _signal(
    rows: Sequence[Mapping[str, Any]], *, field: str, threshold: float
) -> Optional[str]:
    points = _last_two(rows, field)
    if points is None:
        return None
    (_d0, v0), (_d1, v1) = points
    delta = v1 - v0
    th = abs(float(threshold))
    if delta <= -th:
        return "easing"
    if delta >= th:
        return "tightening"
    return "stable"


def _combine(lpr: str, shibor: str) -> str:
    if lpr == shibor:
        return lpr
    if lpr == "stable":
        return shibor
    if shibor == "stable":
        return lpr
    return "stable"


def _last_two(
    rows: Sequence[Mapping[str, Any]], field: str
) -> Optional[Tuple[Tuple[str, float], Tuple[str, float]]]:
    parsed: List[Tuple[str, float]] = []
    for row in rows or ():
        if not isinstance(row, Mapping):
            continue
        date = str(row.get("date") or "").strip()
        rate = _float_or_none(row.get(field))
        if date and rate is not None:
            parsed.append((date, rate))
    if len(parsed) < 2:
        return None
    return parsed[-2], parsed[-1]


def _float(raw: Any, default: float) -> float:
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def _float_or_none(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
