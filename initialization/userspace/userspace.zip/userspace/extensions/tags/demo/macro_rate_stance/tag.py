#!/usr/bin/env python3
"""宏观利率环境：宽松 / 平稳 / 紧缩三个标签，只在方向变化日写入当前标签。"""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.tag.contracts import TagContext, TagHooks

LPR_KEY = DATA_KEY.MACRO_LPR
SHIBOR_KEY = DATA_KEY.MACRO_SHIBOR
_TAGS = frozenset({"easing", "stable", "tightening"})


class MacroRateStanceTagHooks(TagHooks):
    """global 时序：当前利率方向对应一个标签，方向变化日才写入。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name not in _TAGS:
            return None

        core = ctx.settings.core if isinstance(ctx.settings.core, dict) else {}
        lpr = _signal(
            ctx.data.items.get(LPR_KEY) or [],
            field=str(core.get("lpr_field") or "lpr_1_y"),
            threshold=_float(core.get("lpr_threshold"), 0.05),
        )
        shibor = _signal(
            ctx.data.items.get(SHIBOR_KEY) or [],
            field=str(core.get("shibor_field") or "three_month"),
            threshold=_float(core.get("shibor_threshold"), 0.05),
        )
        if lpr is None or shibor is None:
            return None

        stance = _combine(lpr[0], shibor[0])
        if stance not in _TAGS or definition.name != stance:
            return None

        state_key = "last_tag:__global__"
        if ctx.custom.get(state_key) == stance:
            return None

        ctx.custom[state_key] = stance
        return {"value": _note(lpr, shibor)}


def _signal(
    rows: Sequence[Mapping[str, Any]], *, field: str, threshold: float
) -> Optional[Tuple[str, float, float]]:
    """最近两点的方向、最新读数、变动。"""
    points = _last_two(rows, field)
    if points is None:
        return None
    (_d0, v0), (_d1, v1) = points
    delta = v1 - v0
    th = abs(float(threshold))
    if delta <= -th:
        direction = "easing"
    elif delta >= th:
        direction = "tightening"
    else:
        direction = "stable"
    return direction, v1, delta


def _combine(lpr: str, shibor: str) -> str:
    if lpr == shibor:
        return lpr
    if lpr == "stable":
        return shibor
    if shibor == "stable":
        return lpr
    return "stable"


def _note(
    lpr: Tuple[str, float, float], shibor: Tuple[str, float, float]
) -> str:
    """悬停用：两个利率的最新读数和变动。"""
    return f"LPR {_rate(lpr)} · Shibor {_rate(shibor)}"


def _rate(move: Tuple[str, float, float]) -> str:
    _direction, latest, delta = move
    return f"{latest:.2f}（{delta:+.2f}）"


def _last_two(
    rows: Sequence[Mapping[str, Any]], field: str
) -> Optional[Tuple[Tuple[str, float], Tuple[str, float]]]:
    parsed: List[Tuple[str, float]] = []
    for row in rows or ():
        if not isinstance(row, Mapping):
            continue
        date = str(row.get("date") or "").strip()
        rate = _float_or_none(row.get(field))
        if date and rate is not None:
            parsed.append((date, rate))
    if len(parsed) < 2:
        return None
    return parsed[-2], parsed[-1]


def _float(raw: Any, default: float) -> float:
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def _float_or_none(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
