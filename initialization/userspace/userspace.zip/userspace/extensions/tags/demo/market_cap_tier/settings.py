"""市值档位：高 / 中 / 低三个标签，仅在档位变化日写入当前标签。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "market_cap_tier",
        "display_name": "市值分类",
        "description": "按总市值分成高市值、中市值、低市值；只在档位变化日写入当前标签",
    },
    "core": {
        # 阈值单位：亿元；库内 total_market_value 为万元
        "micro_cap_max_threshold": 10.0,
        "low_cap_max_threshold": 30.0,
        "mid_cap_max_threshold": 100.0,
    },
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {
            "mode": "entity_based",
            "start_date": "",
            "end_date": "",
        },
    },
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "required": [{"data_key": "stock.indicators.daily"}],
        "min_required_records": 1,
    },
    "tag_definitions": [
        {
            "name": "high_cap",
            "display_name": "高市值",
            "description": "总市值高于中市值上限",
        },
        {
            "name": "mid_cap",
            "display_name": "中市值",
            "description": "总市值高于低市值上限，且不超过中市值上限",
        },
        {
            "name": "low_cap",
            "display_name": "低市值",
            "description": "总市值不超过低市值上限；微市值并入这一档",
        },
    ],
}
