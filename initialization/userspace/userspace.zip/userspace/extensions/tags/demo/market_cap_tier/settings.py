"""市值档位 Tag：按总市值分档，仅在档位变化日写入。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "market_cap_tier",
        "display_name": "市值分类",
        "description": "根据市值划分档位，仅在档位变化日写入",
    },
    "core": {
        # 阈值单位：亿元；库内 total_market_value 为万元
        "micro_cap_max_threshold": 10.0,
        "low_cap_max_threshold": 30.0,
        "mid_cap_max_threshold": 100.0,
    },
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution": {
            "mode": "entity_based",
            "start_date": "",
            "end_date": "",
        },
    },
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "required": [{"data_key": "stock.indicators.daily"}],
        "min_required_records": 1,
    },
    "tag_definitions": [
        {
            "name": "market_cap_tier",
            "display_name": "市值",
            "description": "micro / low / mid / high；仅在档位变化日写入",
        },
    ],
}
