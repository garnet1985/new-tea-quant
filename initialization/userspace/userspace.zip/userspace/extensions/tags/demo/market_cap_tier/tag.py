#!/usr/bin/env python3
"""市值档位 Tag：仅在 tier 变化日写入 market_cap_tier。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.tag.contracts import TagContext, TagHooks

INDICATORS = DATA_KEY.STOCK_INDICATORS_DAILY
TAG_NAME = "market_cap_tier"
VALID_TIERS = frozenset({"micro", "low", "mid", "high"})


@dataclass(frozen=True)
class CapTierThresholds:
    """市值分档阈值（库内 total_market_value 单位：万元）。"""

    micro_cap_max_wan: float
    low_cap_max_wan: float
    mid_cap_max_wan: float

    @classmethod
    def from_core(cls, core: Mapping[str, Any]) -> "CapTierThresholds":
        micro_yi = _float(core.get("micro_cap_max_threshold"), 10.0)
        low_yi = _float(core.get("low_cap_max_threshold"), 30.0)
        mid_yi = _float(core.get("mid_cap_max_threshold"), 100.0)
        if low_yi <= micro_yi:
            low_yi = micro_yi + 1.0
        if mid_yi <= low_yi:
            mid_yi = low_yi + 1.0
        return cls(
            micro_cap_max_wan=micro_yi * 10_000.0,
            low_cap_max_wan=low_yi * 10_000.0,
            mid_cap_max_wan=mid_yi * 10_000.0,
        )

    def classify(self, cap_wan: float) -> str:
        if cap_wan <= self.micro_cap_max_wan:
            return "micro"
        if cap_wan <= self.low_cap_max_wan:
            return "low"
        if cap_wan <= self.mid_cap_max_wan:
            return "mid"
        return "high"


def find_bar_on_date(
    rows: Sequence[Mapping[str, Any]],
    as_of_date: str,
) -> Optional[Dict[str, Any]]:
    target = str(as_of_date or "").strip()
    if not target:
        return None
    for row in reversed(rows or ()):
        dt = str(row.get("date") or "").strip()
        if dt == target:
            return dict(row)
        if dt and dt < target:
            break
    return None


class MarketCapTierTagHooks(TagHooks):
    """单股时序：检测市值档位变化，变化日写入 tag。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name != TAG_NAME:
            return None

        indicators = ctx.data.items.get(INDICATORS) or []
        bar = find_bar_on_date(indicators, ctx.data.now)
        if bar is None:
            return None
        cap_wan = _float_or_none(bar.get("total_market_value"))
        if cap_wan is None:
            return None

        thresholds = CapTierThresholds.from_core(ctx.settings.core)
        tier = thresholds.classify(cap_wan)
        if tier not in VALID_TIERS:
            return None

        state_key = f"last_tier:{ctx.data.entity_id}"
        last_tier = ctx.custom.get(state_key)
        if not (isinstance(last_tier, str) and last_tier in VALID_TIERS):
            prior = ctx.data.prior_value
            if isinstance(prior, str) and prior in VALID_TIERS:
                last_tier = prior
                ctx.custom[state_key] = prior
        if isinstance(last_tier, str) and last_tier in VALID_TIERS and last_tier == tier:
            return None

        ctx.custom[state_key] = tier
        return {"value": tier}


def _float(raw: Any, default: float) -> float:
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def _float_or_none(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
