#!/usr/bin/env python3
"""市值档位 Tag：仅在 tier 变化日写入 market_cap_tier。"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.tag.contracts import TagContext, TagHooks

INDICATORS = DATA_KEY.STOCK_INDICATORS_DAILY
TAG_NAME = "market_cap_tier"
VALID = frozenset({"micro", "low", "mid", "high"})


class MarketCapTierTagHooks(TagHooks):
    """单股时序：市值档位变化日写入。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name != TAG_NAME:
            return None

        bar = _bar_on_date(ctx.data.items.get(INDICATORS) or [], ctx.data.now)
        if bar is None:
            return None
        cap = _float_or_none(bar.get("total_market_value"))
        if cap is None:
            return None

        tier = _classify(cap, ctx.settings.core)
        if tier not in VALID:
            return None

        state_key = f"last_tier:{ctx.data.entity_id}"
        last = ctx.custom.get(state_key)
        if last not in VALID:
            prior = ctx.data.prior_value
            if isinstance(prior, str) and prior in VALID:
                last = prior
                ctx.custom[state_key] = prior
        if last in VALID and last == tier:
            return None

        ctx.custom[state_key] = tier
        return {"value": tier}


def _classify(cap_wan: float, core: Any) -> str:
    """core 阈值单位：亿元；库内 total_market_value：万元。"""
    cfg = core if isinstance(core, dict) else {}
    micro = _float(cfg.get("micro_cap_max_threshold"), 10.0) * 10_000.0
    low = _float(cfg.get("low_cap_max_threshold"), 30.0) * 10_000.0
    mid = _float(cfg.get("mid_cap_max_threshold"), 100.0) * 10_000.0
    if low <= micro:
        low = micro + 10_000.0
    if mid <= low:
        mid = low + 10_000.0
    if cap_wan <= micro:
        return "micro"
    if cap_wan <= low:
        return "low"
    if cap_wan <= mid:
        return "mid"
    return "high"


def _bar_on_date(rows: Sequence[Any], as_of: str) -> Optional[Dict[str, Any]]:
    target = str(as_of or "").strip()
    if not target:
        return None
    for row in reversed(rows or ()):
        if not isinstance(row, dict):
            continue
        dt = str(row.get("date") or "").strip()
        if dt == target:
            return row
        if dt and dt < target:
            break
    return None


def _float(raw: Any, default: float) -> float:
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def _float_or_none(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
