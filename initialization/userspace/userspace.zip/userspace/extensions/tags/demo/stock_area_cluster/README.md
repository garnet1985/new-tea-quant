# 股票经济区归类（non_time_series demo）

`data.base = stock.list`。用 `settings.core.province_to_cluster` 把省/市 area 映射到经济区。映射值用标签的展示名（长三角、珠三角、京津冀、成渝双城、其它）；未命中进 **其它**。

经济区本身是标签。`value` 是该区当时的注解，例如 `128只 · 上海、江苏、浙江、安徽 · 样例 …`。

```bash
python cli.py tag --scenario stock_area_cluster --dry-run
```

落库实体 `__global__`。area 维表通过 DataManager join（暂无独立 Data Contract）；改区划只改 `core` 映射，展示名要和 `tag_definitions` 对得上。改完配置后需要重新跑一遍，旧的「经济区归类」定义会被清掉。
