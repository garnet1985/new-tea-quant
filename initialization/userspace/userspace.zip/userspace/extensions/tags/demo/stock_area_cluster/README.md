# 股票经济区归类（non_time_series demo）

`data.base = stock.list`。用 `settings.core.province_to_cluster` 把省/市 area 映射到经济区；未命中进 **其它**。

默认经济区：长三角、珠三角、京津冀、成渝双城。

```bash
python cli.py tag --scenario stock_area_cluster --dry-run
```

落库实体 `__global__`；value 为各经济区 `count` / `provinces` / `sample_ids` 快照。  
area 维表通过 DataManager join（暂无独立 Data Contract）；改区划只改 `core` 映射即可。
