"""股票经济区归类（non_time_series）：area → 经济区快照。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "stock_area_cluster",
        "display_name": "股票经济区归类",
        "description": "按注册地 area 映射到经济区；未命中归入「其它」",
        "keywords": ["area", "cluster", "non_time_series", "demo"],
        "category": ["demo", "universe"],
    },
    "core": {
        "fallback_cluster": "其它",
        "sample_per_cluster": 5,
        "province_to_cluster": {
            "上海": "长三角",
            "江苏": "长三角",
            "浙江": "长三角",
            "安徽": "长三角",
            "广东": "珠三角",
            "深圳": "珠三角",
            "北京": "京津冀",
            "天津": "京津冀",
            "河北": "京津冀",
            "四川": "成渝双城",
            "重庆": "成渝双城",
        },
    },
    "calculation": {
        "update_mode": "refresh",
        "recompute": True,
        "execution": {"start_date": "", "end_date": ""},
    },
    "data": {
        "base": {"data_key": "stock.list"},
        "required": [],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {
            "name": "stock_area_cluster",
            "display_name": "经济区归类",
            "description": "经济区快照：count / provinces / sample_ids",
        },
    ],
}
