"""股票经济区：长三角 / 珠三角 / 京津冀 / 成渝双城 / 其它，各是一个标签。"""

settings = {
    "is_enabled": True,
    "meta": {
        "key": "stock_area_cluster",
        "display_name": "股票经济区归类",
        "description": "按注册地归入经济区标签；value 是该区当时的只数和地区",
        "keywords": ["area", "cluster", "non_time_series", "demo"],
        "category": ["demo", "universe"],
    },
    "core": {
        "fallback_cluster": "其它",
        "sample_per_cluster": 5,
        "province_to_cluster": {
            "上海": "长三角",
            "江苏": "长三角",
            "浙江": "长三角",
            "安徽": "长三角",
            "广东": "珠三角",
            "深圳": "珠三角",
            "北京": "京津冀",
            "天津": "京津冀",
            "河北": "京津冀",
            "四川": "成渝双城",
            "重庆": "成渝双城",
        },
    },
    "calculation": {
        "update_mode": "refresh",
        "recompute": True,
        "execution": {"start_date": "", "end_date": ""},
    },
    "data": {
        "base": {"data_key": "stock.list"},
        "required": [],
        "min_required_records": 0,
    },
    "tag_definitions": [
        {
            "name": "yangtze",
            "display_name": "长三角",
            "description": "上海、江苏、浙江、安徽",
        },
        {
            "name": "pearl",
            "display_name": "珠三角",
            "description": "广东、深圳",
        },
        {
            "name": "jingjinji",
            "display_name": "京津冀",
            "description": "北京、天津、河北",
        },
        {
            "name": "chengyu",
            "display_name": "成渝双城",
            "description": "四川、重庆",
        },
        {
            "name": "other",
            "display_name": "其它",
            "description": "映射未命中，或没有注册地",
        },
    ],
}
