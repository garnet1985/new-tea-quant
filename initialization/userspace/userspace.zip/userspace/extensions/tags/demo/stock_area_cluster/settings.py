"""
股票经济区归类 Tag 场景（non_time_series）

用 settings.core.province_to_cluster 把省/市 area 映射到经济区；
未命中（含无 area）归入「其它」。落库实体为 __global__ 快照。
"""

settings = {
    "is_enabled": True,

    "meta": {
        "key": "stock_area_cluster",
        "display_name": "股票经济区归类",
        "description": (
            "按注册地 area 映射到经济区（长三角/珠三角/京津冀/成渝双城/其它）；"
            "映射表在 core.province_to_cluster，可自行增删"
        ),
        "keywords": ["area", "cluster", "non_time_series", "demo"],
        "category": ["demo", "universe"],
    },

    "core": {
        # 未命中省/市、或股票无 area 时的桶名
        "fallback_cluster": "其它",
        # 每个经济区在 value 里最多附带多少只示例股票（便于抽查）
        "sample_per_cluster": 5,
        # 省/市（sys_areas.value）→ 经济区；未列出的进 fallback_cluster
        "province_to_cluster": {
            # 长三角
            "上海": "长三角",
            "江苏": "长三角",
            "浙江": "长三角",
            "安徽": "长三角",
            # 珠三角（库内深圳与广东分列）
            "广东": "珠三角",
            "深圳": "珠三角",
            # 京津冀
            "北京": "京津冀",
            "天津": "京津冀",
            "河北": "京津冀",
            # 成渝双城
            "四川": "成渝双城",
            "重庆": "成渝双城",
        },
    },

    "calculation": {
        # non_ts 一次计算；refresh 方便反复 dry-run / 调 map
        "update_mode": "refresh",
        "recompute": True,
        "execution": {
            "start_date": "",
            "end_date": "",
        },
    },

    "data": {
        "base": {
            "data_key": "stock.list",
            "params": {},
        },
        "required": [],
        "min_required_records": 0,
    },

    "tag_definitions": [
        {
            "name": "stock_area_cluster",
            "display_name": "经济区归类",
            "description": (
                "value 为经济区快照：各区 count / provinces / sample_ids；"
                "映射见 settings.core.province_to_cluster"
            ),
        },
    ],
}
