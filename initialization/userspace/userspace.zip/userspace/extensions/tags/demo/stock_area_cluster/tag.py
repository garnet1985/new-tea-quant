#!/usr/bin/env python3
"""股票经济区归类：area → 经济区快照（non_time_series）。"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.data_manager import DataManager
from core.modules.tag.contracts import TagContext, TagHooks

LIST_KEY = DATA_KEY.STOCK_LIST
TAG_NAME = "stock_area_cluster"
DEFAULT_FALLBACK = "其它"


class StockAreaClusterTagHooks(TagHooks):
    """non_ts：股票池 × area map → 经济区汇总。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name != TAG_NAME:
            return None

        rows = ctx.data.items.get(LIST_KEY) or []
        core = ctx.settings.core if isinstance(ctx.settings.core, dict) else {}
        mapping = {
            str(p).strip(): str(c).strip()
            for p, c in (core.get("province_to_cluster") or {}).items()
            if str(p).strip() and str(c).strip()
        }
        fallback = str(core.get("fallback_cluster") or DEFAULT_FALLBACK).strip() or DEFAULT_FALLBACK
        sample_n = max(int(core.get("sample_per_cluster") or 5), 0)

        stock_ids = sorted(
            {
                str(row.get("id") or "").strip()
                for row in rows
                if isinstance(row, Mapping) and str(row.get("id") or "").strip()
            }
        )
        if not stock_ids:
            return None

        area_by_stock = _load_stock_area_names()
        buckets: Dict[str, Dict[str, Any]] = {}
        for sid in stock_ids:
            province = area_by_stock.get(sid)
            cluster = mapping.get(province, fallback) if province else fallback
            b = buckets.setdefault(
                cluster, {"count": 0, "provinces": set(), "sample_ids": [], "unmapped": 0}
            )
            b["count"] += 1
            if province:
                b["provinces"].add(province)
            else:
                b["unmapped"] += 1
            if sample_n and len(b["sample_ids"]) < sample_n:
                b["sample_ids"].append(sid)

        value = {
            "as_of": ctx.data.now,
            "universe_size": len(stock_ids),
            "with_area": sum(1 for sid in stock_ids if sid in area_by_stock),
            "fallback_cluster": fallback,
            "clusters": {
                name: {
                    "count": int(b["count"]),
                    "provinces": sorted(b["provinces"]),
                    "sample_ids": list(b["sample_ids"]),
                    "unmapped": int(b["unmapped"]),
                }
                for name, b in sorted(buckets.items(), key=lambda kv: (-kv[1]["count"], kv[0]))
            },
        }
        prior = ctx.data.prior_value
        if isinstance(prior, Mapping) and all(
            prior.get(k) == value.get(k)
            for k in ("universe_size", "with_area", "fallback_cluster", "clusters")
        ):
            return None
        return {"value": value}


def _load_stock_area_names() -> Dict[str, str]:
    """stock_id → area 省/市名（sys_areas.value）。"""
    svc = DataManager().stock.list
    areas_model = svc.areas_model
    map_model = svc.area_map_model
    if areas_model is None or map_model is None:
        return {}
    id_to_name = {
        int(row["id"]): str(row.get("value") or "").strip()
        for row in (areas_model.load() or [])
        if row.get("id") is not None and str(row.get("value") or "").strip()
    }
    out: Dict[str, str] = {}
    for row in map_model.load() or []:
        sid = str(row.get("stock_id") or "").strip()
        try:
            area_id = int(row.get("area_id"))
        except (TypeError, ValueError):
            continue
        name = id_to_name.get(area_id)
        if sid and name:
            out[sid] = name
    return out
