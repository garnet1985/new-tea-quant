#!/usr/bin/env python3
"""股票经济区归类：area 省/市 → 经济区快照（non_time_series / __global__）。"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.data_manager import DataManager
from core.modules.tag.contracts import TagContext, TagHooks

LIST_KEY = DATA_KEY.STOCK_LIST
TAG_NAME = "stock_area_cluster"
DEFAULT_FALLBACK = "其它"


class StockAreaClusterTagHooks(TagHooks):
    """non_ts：股票池 × area map → 经济区汇总。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name != TAG_NAME:
            return None

        rows = ctx.data.items.get(LIST_KEY) or []
        if not rows:
            return None

        core = ctx.settings.core if isinstance(ctx.settings.core, dict) else {}
        mapping = _province_map(core.get("province_to_cluster"))
        fallback = str(core.get("fallback_cluster") or DEFAULT_FALLBACK).strip() or DEFAULT_FALLBACK
        sample_n = max(int(core.get("sample_per_cluster") or 5), 0)

        stock_ids = {
            str(row.get("id") or "").strip()
            for row in rows
            if isinstance(row, Mapping) and str(row.get("id") or "").strip()
        }
        if not stock_ids:
            return None

        area_by_stock = _load_stock_area_names()
        buckets: Dict[str, Dict[str, Any]] = {}

        for sid in sorted(stock_ids):
            province = area_by_stock.get(sid)
            cluster = mapping.get(province, fallback) if province else fallback
            bucket = buckets.setdefault(
                cluster,
                {
                    "count": 0,
                    "provinces": set(),
                    "sample_ids": [],
                    "unmapped": 0,
                },
            )
            bucket["count"] += 1
            if province:
                bucket["provinces"].add(province)
            else:
                bucket["unmapped"] += 1
            if sample_n and len(bucket["sample_ids"]) < sample_n:
                bucket["sample_ids"].append(sid)

        clusters_out: Dict[str, Any] = {}
        for name, bucket in sorted(buckets.items(), key=lambda kv: (-kv[1]["count"], kv[0])):
            clusters_out[name] = {
                "count": int(bucket["count"]),
                "provinces": sorted(bucket["provinces"]),
                "sample_ids": list(bucket["sample_ids"]),
                "unmapped": int(bucket["unmapped"]),
            }

        value = {
            "as_of": ctx.data.now,
            "universe_size": len(stock_ids),
            "with_area": sum(1 for sid in stock_ids if sid in area_by_stock),
            "fallback_cluster": fallback,
            "clusters": clusters_out,
        }

        prior = ctx.data.prior_value
        if _same_snapshot(prior, value):
            return None
        return {"value": value}


def _province_map(raw: Any) -> Dict[str, str]:
    if not isinstance(raw, Mapping):
        return {}
    out: Dict[str, str] = {}
    for province, cluster in raw.items():
        p = str(province or "").strip()
        c = str(cluster or "").strip()
        if p and c:
            out[p] = c
    return out


def _load_stock_area_names() -> Dict[str, str]:
    """stock_id → area 省/市名（sys_areas.value）。"""
    dm = DataManager()
    svc = dm.stock.list
    areas_model = svc.areas_model
    map_model = svc.area_map_model
    if areas_model is None or map_model is None:
        return {}

    id_to_name = {
        int(row["id"]): str(row.get("value") or "").strip()
        for row in (areas_model.load() or [])
        if row.get("id") is not None and str(row.get("value") or "").strip()
    }
    out: Dict[str, str] = {}
    for row in map_model.load() or []:
        sid = str(row.get("stock_id") or "").strip()
        try:
            area_id = int(row.get("area_id"))
        except (TypeError, ValueError):
            continue
        name = id_to_name.get(area_id)
        if sid and name:
            out[sid] = name
    return out


def _same_snapshot(prior: Any, value: Mapping[str, Any]) -> bool:
    if not isinstance(prior, Mapping):
        return False
    # as_of 可随 end_date 变；比较结构主体
    keys = ("universe_size", "with_area", "fallback_cluster", "clusters")
    return all(prior.get(k) == value.get(k) for k in keys)
