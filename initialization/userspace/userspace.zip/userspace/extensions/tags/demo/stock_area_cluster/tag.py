#!/usr/bin/env python3
"""股票经济区：每个经济区是一个标签，value 是该区当时的只数和地区。"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.data_manager import DataManager
from core.modules.tag.contracts import TagContext, TagHooks

LIST_KEY = DATA_KEY.STOCK_LIST
_KNOWN_TAGS = frozenset({"yangtze", "pearl", "jingjinji", "chengyu", "other"})
_CACHE_KEY = "area_buckets"
DEFAULT_FALLBACK = "其它"


class StockAreaClusterTagHooks(TagHooks):
    """non_ts：股票池按注册地归入经济区标签，每个标签写自己的注解。"""

    def calculate_tag(self, ctx: TagContext) -> Optional[Dict[str, Any]]:
        definition = ctx.data.tag_definition
        if definition is None or definition.name not in _KNOWN_TAGS:
            return None

        buckets = ctx.custom.get(_CACHE_KEY)
        if buckets is None:
            buckets = _build_buckets(ctx)
            ctx.custom[_CACHE_KEY] = buckets
        if not buckets:
            return None
        bucket = buckets.get(definition.name)
        if bucket is None:
            return None
        return {"value": _note(bucket)}


def _build_buckets(ctx: TagContext) -> Dict[str, Dict[str, Any]]:
    rows = ctx.data.items.get(LIST_KEY) or []
    core = ctx.settings.core if isinstance(ctx.settings.core, dict) else {}
    names = _names_by_label(ctx)
    fallback = names.get(str(core.get("fallback_cluster") or DEFAULT_FALLBACK).strip(), "other")
    if fallback not in _KNOWN_TAGS:
        fallback = "other"
    mapping = {
        str(province).strip(): names.get(str(cluster).strip(), fallback)
        for province, cluster in (core.get("province_to_cluster") or {}).items()
        if str(province).strip() and str(cluster).strip()
    }
    sample_n = max(int(core.get("sample_per_cluster") or 5), 0)
    stock_ids = sorted(
        {
            str(row.get("id") or "").strip()
            for row in rows
            if isinstance(row, Mapping) and str(row.get("id") or "").strip()
        }
    )
    if not stock_ids:
        return {}

    area_by_stock = _load_stock_area_names()
    buckets = {name: _empty_bucket() for name in _KNOWN_TAGS}
    for sid in stock_ids:
        province = area_by_stock.get(sid)
        tag_name = mapping.get(province, fallback) if province else fallback
        bucket = buckets[tag_name]
        bucket["count"] += 1
        if province:
            bucket["provinces"].add(province)
        else:
            bucket["unmapped"] += 1
        if sample_n and len(bucket["sample_ids"]) < sample_n:
            bucket["sample_ids"].append(sid)
    return buckets


def _names_by_label(ctx: TagContext) -> Dict[str, str]:
    """展示名和机器名都指到 definition.name，映射表可以写中文。"""
    out: Dict[str, str] = {}
    for item in ctx.settings.definition_items():
        if item.name not in _KNOWN_TAGS:
            continue
        out[item.name] = item.name
        label = str(item.display_name or "").strip()
        if label:
            out[label] = item.name
    return out


def _empty_bucket() -> Dict[str, Any]:
    return {"count": 0, "provinces": set(), "sample_ids": [], "unmapped": 0}


def _note(bucket: Mapping[str, Any]) -> str:
    """悬停 / 快照用：只数、覆盖地区、少量样例。"""
    provinces = "、".join(sorted(bucket.get("provinces") or []))
    samples = list(bucket.get("sample_ids") or [])
    parts = [f"{int(bucket.get('count') or 0)}只"]
    if provinces:
        parts.append(provinces)
    if samples:
        parts.append("样例 " + "、".join(str(item) for item in samples))
    unmapped = int(bucket.get("unmapped") or 0)
    if unmapped:
        parts.append(f"未映射 {unmapped}")
    return " · ".join(parts)


def _load_stock_area_names() -> Dict[str, str]:
    """stock_id → area 省/市名（sys_data_areas.value）。"""
    svc = DataManager().stock.list
    areas_model = svc.areas_model
    map_model = svc.area_map_model
    if areas_model is None or map_model is None:
        return {}
    id_to_name = {
        int(row["id"]): str(row.get("value") or "").strip()
        for row in (areas_model.load() or [])
        if row.get("id") is not None and str(row.get("value") or "").strip()
    }
    out: Dict[str, str] = {}
    for row in map_model.load() or []:
        sid = str(row.get("stock_id") or "").strip()
        try:
            area_id = int(row.get("area_id"))
        except (TypeError, ValueError):
            continue
        name = id_to_name.get(area_id)
        if sid and name:
            out[sid] = name
    return out
