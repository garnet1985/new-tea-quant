# settings_example.py — Tag 配置字段说明（SOT；复制到正式 scenario 目录后按需删减）
#
# 新建 Tag scenario：复制 _template/empty_scenario/ 到新目录，或复制本文件到 userspace/extensions/tags/<your_path>/settings.py。
#
# 最少建议填写：is_enabled、meta.key、meta.display_name、data.base、tag_definitions
# 其余块可整段省略，使用系统默认值。
#
# 系统 tag_key（日志、DB scenario.name）= 相对 userspace/extensions/tags/ 的路径，
# 例如目录 demo/market_cap_tier → tag_key 为 demo/market_cap_tier。
# CLI / API 请用 meta.key（短 alias），不必复制完整路径。
# 勿在 settings 根级写 name；展示名写在 meta.display_name。
#
# 复制为正式 settings.py 时，顶层变量名须为 settings（discovery 加载 var_name="settings"）。
#
# 使用 data.required 且引用 DATA_KEY 时，可在 tag.py / settings.py 顶部：
#   from core.modules.data_contract.contracts import DATA_KEY
#
# 约定摘要：
# - 路由由 data.base 的 contract scope×type 决定（勿手写 tag_target_type）：
#     per_entity 时序 → BacktestEngine（execution.mode = entity_based | slice_based）
#     global 时序     → Tag 轻量主进程推进（execution.mode 忽略；写了会 warning）
#     非时序 base     → Tag 轻量主进程一次计算（execution.mode 忽略）
# - 计算区间、更新模式：calculation（≈ strategy.simulation；块名保留）
#   - calculation.execution 与 strategy.simulation.execution 同构（仅 per_entity 需要 mode）
# - 数据声明：data.base + data.required（命名与 strategy 对齐）
#     base 可为 stock.kline.* / index.kline.*（per_entity）、macro.*（global）
#     或 stock.list / index.list（non_time_series）
# - 标签定义：tag_definitions
# - 并发调度（仅 per_entity）：core/default_config/worker.json → job_pipeline.tag
#   （可在 userspace/config/worker.json 覆盖；scenario settings 不写 performance）
# - 框架自动推导（勿在 userspace 手写）：name、target_entity、tag_time_axis_based_on
# - per_entity 实体池：base 的 meta.list_data_key（如 stock.list / index.list）
# - global / non_time_series 实体池：哨兵 __global__（落库 entity_id）

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    # 必填，是否启用（discovery 扫描 / CLI 默认可选）
    "is_enabled": True,

    # 用户可见文档块；系统 tag_key 由目录路径决定，不在此填写 name
    "meta": {
        "key": "my_tag",              # 必填，全局唯一；CLI --scenario 使用此 alias
        # 必填，UI / 报告展示名
        "display_name": "示例场景",
        # 可选，但强烈建议填写
        "description": "场景说明：打标逻辑、适用实体、演示目的等。",
        # 选填，默认 []；标签 / 检索用
        "keywords": ["示例"],
        # 选填，默认 {}；结构化说明
        "details": {
            "logic": [
                "示例：在 example_tag_1 条件不满足时使用 example_tag_2",
            ],
        },
        # 选填，默认 []
        "category": ["your category"],
    },

    # -----------------------------------------------------------------------
    # 2. core — scenario 私有参数（tag.py hooks 里读 ctx.settings.core）
    # -----------------------------------------------------------------------
    # 选填，默认 {}；键名由 hooks 自行约定
    "core": {
        # "low_cap_max_threshold": 50.0,
    },

    # -----------------------------------------------------------------------
    # 3. calculation — 计算区间与执行模式（整段可省略；≈ strategy.simulation）
    # -----------------------------------------------------------------------
    "calculation": {
        # 选填，默认 "incremental"
        # incremental — 从 sys_tag_calc_progress.last_calculated_end 续算（日常跑批；不是 max(as_of)）
        # refresh     — 清值后对目标区间重算（改逻辑 / 修历史后使用；不写 progress）
        "update_mode": "incremental",

        # 选填，默认 False。一次性运维开关：True 时本次运行等价 refresh，且可能重建 scenario 元数据
        # 与 update_mode 不同：recompute 不描述日常增量策略，仅用于开发修数 / 强制重建
        "recompute": False,

        # 选填，默认 False。True=只计算不落库（不写 tag_value、不更新 sys_tag_calc_progress；
        # 也不执行 refresh/recompute 的清库）。CLI/API dry_run 与此为 OR
        "is_dry_run": False,

        # execution：时间窗 + 调度 mode
        # - per_entity base：mode 必填（entity_based | slice_based）
        # - global base：mode 可省略；若填写则 warning 后忽略（不走 BacktestEngine）
        "execution": {
            # 选填，默认 "entity_based"（仅 per_entity 路由生效）
            # entity_based — 各实体按各自交易日推进（常规打标）
            # slice_based  — 日历切片 + on_calendar_asof（incremental / refresh 均可）
            "mode": "entity_based",
            # 选填 YYYYMMDD；空= data.json default_start_date
            "start_date": "",
            # 选填 YYYYMMDD；空= latest completed trading date
            "end_date": "",
        },
    },

    # -----------------------------------------------------------------------
    # 4. data — 数据契约（与 strategy 命名对齐）
    # -----------------------------------------------------------------------
    "data": {
        # 必填。路由与实体池由 base 的 contract meta 推断：
        #   stock.kline.daily / index.kline.daily → per_entity（list_data_key → stock.list / index.list）
        #   macro.gdp / macro.cpi / …           → global（哨兵 __global__；主进程日历推进）
        #   stock.list / index.list             → non_time_series（哨兵 __global__；一次计算）
        # 时序示例：stock.kline.daily | stock.indicators.daily | index.kline.daily | macro.gdp
        "base": {
            "data_key": "stock.kline.daily",  # 必填
            "params": {
                # 选填，默认 qfq；可选 raw | hfq（依 data_key 而定；macro / list 通常 {}）
                "adjust": "qfq",
            },
            # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
            "indicators": {},
        },
        # 选填，默认 []；计算 tag 所需的辅助数据源（不含 base）
        # global / non_ts 场景可挂其它 global 源；per_entity 辅助源勿依赖这两类 runner 装载
        "required": [
            # {"data_key": "macro.gdp", "params": {}},
            # {"data_key": "stock.indicators.daily", "params": {}},
        ],
        # 选填，默认 0；calculation.update_mode=incremental 时须显式配置（可为 0）
        # as_of 之前至少需要的 history 条数（warmup / min bars）
        "min_required_records": 0,
    },

    # -----------------------------------------------------------------------
    # 5. tag_definitions — 标签定义（一个 scenario 下可多个 tag）
    # -----------------------------------------------------------------------
    # 必填，至少 1 项
    "tag_definitions": [
        {
            # 必填，机器识别码（对应 tag_definition.name）；字母数字下划线
            "name": "example_tag_1",
            # 选填，默认与 name 相同
            "display_name": "example tag 1",
            # 选填，默认 ""
            "description": "标签 1 说明",
        },
        {
            "name": "example_tag_2",
            "display_name": "example tag 2",
            "description": "举例：当 example_tag_1 条件不满足时使用的互斥标签",
        },
    ],
}
