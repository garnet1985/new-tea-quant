# 策略用户指南（userspace）

面向「要自己写策略」的用户：在 **Web UI** 里从零跑通一条策略，并知道文件该怎么改。命令行仅作附录，日常不必使用。

---

## 0. 先打开界面

在仓库根目录启动（安装向导完成后同样适用）：

```bash
python launcher.py
```

浏览器打开后，顶部导航与策略相关的主要入口：

| 导航 | 用途 |
|------|------|
| **制定策略** | 分步回测：枚举机会 → 价格回测 → 组合模拟 |
| **策略选股** | 用最新行情扫描当前机会 |
| **高级功能** | 特征标签、数据源、数据契约 |
| **设置** | 全局配置（数据库、userspace 路径等） |

下文回测流程以 **制定策略** 为主。

---

## 1. 策略由哪两部分组成？

一个策略目录通常两件核心文件：

- `settings.py` — 参数与运行方式（可在 UI 设置面板编辑）
- `strategy.py` — 继承 `StrategyHooks`，实现买入信号等钩子（主入口：`has_opportunity`）

框架负责：按 settings 准备数据、执行扫描/枚举/模拟、输出报告与版本快照。  
您主要负责 **逻辑 + 配置**。

脚手架：复制 [`_template/empty_strategy/`](_template/empty_strategy/)，或 `python cli.py -n my_strategy`。

---

## 2. 在 UI 里跑通第一次回测

### 2.1 选一条演示策略（推荐）

1. 点击顶栏 **制定策略**。
2. 在列表中搜索 **「随机买卖策略」**（`meta.key`：`random_v1`，目录 `demo/random/random_v1_baseline`），点击进入。
3. 顶栏 **Stepper** 有三步，与分层回测一一对应：

| 步骤 | 界面名称 | 在问什么 |
|------|----------|----------|
| 1 | **枚举机会** | 历史上能触发多少次机会？ |
| 2 | **价格回测** | 单笔层面 ROI 是否偏正？ |
| 3 | **组合模拟** | 有限资金下组合表现如何？ |

4. 在 **枚举机会** 页：左侧可看/改设置，点击 **运行**，等待进度完成后查看下方 **报告**。
5. 依次切换到 **价格回测**、**组合模拟** 重复运行（依赖上一步枚举结果时会自动关联）。
6. 在价格/组合报告里可 **点击单只股票** 查看 K 线与买卖点位（v0.4.1+）。

更多演示策略说明见 [demo/README.md](demo/README.md)。

### 2.2 扫描「今天有没有机会」

1. 点击顶栏 **策略选股**。
2. 选择策略并启动扫描（需先保证数据已更新到足够新的交易日，见 **设置** 或数据 renew 相关说明）。
3. 在结果表格中查看命中列表。

回测看历史，扫描看 **最新** — 二者不要混为一谈。

---

## 3. 自己新建策略（文件 + UI）

### 3.1 建目录

```bash
cp -R userspace/strategies/_template/empty_strategy userspace/strategies/my_strategy
# 或
python cli.py -n my_strategy
```

得到：

```text
userspace/strategies/my_strategy/
├── settings.py
└── strategy.py
```

目录路径是磁盘上的策略位置（如 `my_strategy`）。命令行和接口用 `settings.py` 里的 `meta.key`。路径段须为字母开头的 ASCII 字母/数字/下划线。  
`_template/` 本身不会被 discovery 扫进列表。

### 3.2 写 `settings.py`

以模板或 [settings_example.py](settings_example.py) 为准。最少建议：`is_enabled`、`meta.display_name`、`core`、`data.base`、`goal`、`simulation.execution.mode`。

```python
settings = {
    "is_enabled": True,
    "meta": {
        "key": "my_strategy",
        "display_name": "我的策略",
        "description": "demo",
    },
    "core": {"rsi_oversold_threshold": 20},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [],
        "min_required_records": 30,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"ratio": -0.1, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
    },
}
```

保存后回到 **制定策略** 列表，刷新即可看到新策略（`is_enabled: True` 时）。

### 3.3 写 `strategy.py`

继承 `StrategyHooks`，主入口是 `has_opportunity`：

```python
from __future__ import annotations

from core.modules.strategy.contracts import (
    StrategyContext,
    StrategyHooks,
)


class MyStrategy(StrategyHooks):
    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        record = ctx.record_of_today
        if record is None:
            return False
        rsi = record.get("rsi14")
        threshold = float(settings["core"]["rsi_oversold_threshold"])
        if rsi is None or rsi >= threshold:
            return False
        ctx.capture("rsi", rsi)
        return True
```

参考实现：[`demo/regression/rsi/rsi_v1_baseline/strategy.py`](demo/regression/rsi/rsi_v1_baseline/strategy.py)、[`_template/empty_strategy/strategy.py`](_template/empty_strategy/strategy.py)。

### 3.4 在 UI 里验证

1. **制定策略** → 选中 `my_strategy` → 从 **枚举机会** 开始运行。
2. 在左侧 **设置** 面板微调阈值后再次运行，对比报告差异（注意是否会生成新版本快照）。
3. 需要时用顶栏 **版本/恢复** 相关入口对比两次运行的报告（以当前 UI 为准）。

---

## 4. 常见改动点（改文件或在 UI 设置里改）

| 想改什么 | 对应 settings |
|----------|----------------|
| 信号阈值 | `core` |
| K 线 / 复权 / 指标 | `data.base` |
| 额外数据（财报、tag 等） | `data.required` |
| 止盈止损 / 持仓期 | `goal` |
| 回测样本规模 | `sampling` |
| entity / slice 执行模式 | `simulation.execution.mode` |
| 扫描后通知渠道 | `scanner.adapters` |

字段说明见 [settings_example.py](settings_example.py)。

---

## 5. 结果在哪里？

- **首选：UI 报告** — 各步运行完成后的报告面板（含对比、单股 K 线等）。
- **磁盘备份**：`userspace/strategies/<策略 ID>/results/simulations/{version}/`（三步共享一个 version 号：`enum` / `price` / `portfolio`）。索引在同目录 `meta.json`。日常编辑写在 `settings.py`，没有单独的「发布」步骤。规格见 [VERSIONING.md](../../core/modules/strategy/docs/VERSIONING.md)。

本地产物勿把大文件提交 Git。

---

## 6. 常见问题

### Q1：列表里看不到我的策略？

- `settings.py` 中 `is_enabled` 是否为 `True`
- 目录是否同时包含 `settings.py` 与 `strategy.py`
- 是否误放在 `_` 开头目录（如 `_template`）下
- 路径是否符合命名规则（见上文）

### Q2：运行了但一直没有机会？

- 在 **枚举机会** 报告里先看机会总数是否为 0
- 临时降低 `core` 里阈值，确认链路通后再收紧
- 检查 `min_required_records` 是否过大

### Q3：价格/组合步报错或结果为空？

- 是否先成功跑完 **枚举机会**
- 数据是否覆盖回测区间（**设置** / 数据更新）

### Q4：UI 改了 settings 和磁盘文件不一致？

- UI 保存会写回 `settings.py`；若您手动改文件，需在界面 **重新加载** 或刷新后再跑

---

## 7. 参考

- 入口：[README.md](README.md)
- 演示策略：[demo/README.md](demo/README.md)
- 参数大全：[settings_example.py](settings_example.py)
- 核心模块：[core/modules/strategy/README.md](../../core/modules/strategy/README.md)
- Version / 指纹：[core/modules/strategy/docs/VERSIONING.md](../../core/modules/strategy/docs/VERSIONING.md)
- 公开契约：`from core.modules.strategy.contracts import StrategyHooks, StrategyContext, Opportunity`

---

## 附录：命令行（可选）

习惯终端或在无 UI 环境时，可用 [`cli.py`](../../cli.py)（与 UI 共用同一后端）：

```bash
python cli.py se --strategy random_v1   # 枚举
python cli.py sp --strategy random_v1   # 价格因子
python cli.py so --strategy random_v1   # 组合模拟
python cli.py c  --strategy random_v1   # 扫描
python cli.py t  --scenario market_cap_tier   # 标签
```

`--strategy` / `--scenario` 写 `meta.key`。目录路径也可以，例如 `demo/random/random_v1_baseline`。

完整子命令见 `python cli.py -h`。
