# 跨策略决策模拟的公共 settings 草稿目录。
# 0.5.1 开工时请改名为 userspace/strategies/_decision/（单数），且不要当普通策略发现。
# 口径：core/modules/strategy/docs/notes/DECISION_MAKER_CROSS.md
