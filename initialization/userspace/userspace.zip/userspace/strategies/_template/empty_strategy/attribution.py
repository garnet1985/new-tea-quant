# 归因示例。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# inputs 里每一项是一条对照轴，默认一次只改一轴（cross 保持 False）。
# 先跑完对应回测，再跑 sea / spa / soa。更多写法见 strategies/attribution_example.py。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [15, 20, 25]},
        "stop_loss": {"values": [-0.08, -0.1, -0.15]},
    },
    "cross": False,
}
