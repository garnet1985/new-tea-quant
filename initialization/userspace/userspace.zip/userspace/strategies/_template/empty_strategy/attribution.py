# 归因战役配置（模板）。不进指纹；Workbench 保存 settings 时不要改这份文件。
# 顶层 inputs = 三层共用的「如果」轴（默认 oaat）。
# TODO: 全轴 cross 能展开，但报告仍按单因素讲，产品还没完成。
# CLI sea/spa/soa 只决定补到哪一层产物；须先有对应主 version（se / sp / so）。

attribution = {
    "inputs": {
        # "rsi_oversold_threshold": {"values": [20, 25]},
        # "max_pe_percentile": {"values": [30, None]},
        # "stop_loss": {
        #     "values": [
        #         None,
        #         {"stages": [{"close_invest": True, "ratio": -0.2}]},
        #     ],
        # },
        # "opportunity_merge_gap": {"values": [1, 3, 5]},
    },
    "cross": False,
    # 组合层单独归因：只改资金分配，锚定当前 version，不进上面的共用 inputs。
    # 整段不写时，按当前 settings 生成默认档（三种分配方式、持仓档、资金档，
    # 以及 settings 里已有的单票上限 / Kelly 系数 / 每笔手数）。
    # "allocation": {
    #     "mode": {"values": ["equal_shares", "equal_capital", "kelly"]},
    #     "max_portfolio_size": {"values": [4, 8, 10, 15, 20]},
    #     "initial_capital": {"values": [50000, 100000, 200000]},
    #     "max_weight_per_stock": {"values": [0.2, 0.33, 0.5]},
    #     "kelly_fraction": {"values": [0.25, 0.5, 1.0]},
    #     "lots_per_trade": {"values": [1, 2]},
    # },
    # TODO: 滚动验证的产品口径还没定，先不要打开。
    # "rolling": {
    #     "windows": [
    #         {"start": "20230101", "end": "20231231"},
    #     ],
    # },
}
