# 空白策略模板 — 复制整个 empty_strategy/ 到新目录后改名、改 meta、实现 strategy.py。
# 字段说明见 ../../settings_example.py（与本文件字段形状同步）。
# 系统不会扫描 _template/ 目录；复制后请将 is_enabled 设为 True。

settings = {
    "is_enabled": False,
    "meta": {
        "key": "empty_strategy",
        "display_name": "空白策略模板",
        "description": "复制 _template/empty_strategy/ 到新目录后修改；本模板不产生任何买入信号。",
        "keywords": ["示例"],
        "details": {
            "entry": ["示例：RSI(14) 低于 core.rsi_oversold_threshold 时产生买入信号"]
        },
        "category": ["your category"],
    },
    "core": {"rsi_oversold_threshold": 20},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "required": [],
        "min_required_records": 100,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"ratio": -0.1, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {"ratio": 0.1, "exit_ratio": 0.5, "actions": ["set_protect_loss"]},
                {"ratio": 0.2, "close_invest": True, "actions": ["set_dynamic_loss"]},
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
        "dynamic_loss": {"ratio": -0.1, "close_invest": True},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {"template": "standard"},
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 1_000_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": True,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
