# 空白策略模板 — 复制整个 empty_strategy/ 到新目录后改名、改 meta、实现 strategy.py。
# 系统不会扫描 _template/ 目录；复制后请将 is_enabled 设为 True。

settings = {
    "is_enabled": False,
    "meta": {
        "key": "empty_strategy",
        "display_name": "空白策略模板",
        "description": "空白模板：复制后改 key / display_name / description，并实现 strategy.py。",
        "keywords": ["示例"],
        "details": {"entry": ["在 has_opportunity 中实现入场条件"]},
        "category": "your category",
    },
    "analysis": {"enabled": True},
    "core": {"rsi_oversold_threshold": 20},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 100,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"ratio": -0.1, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {"ratio": 0.1, "exit_ratio": 0.5, "actions": ["set_protect_loss"]},
                {"ratio": 0.2, "close_invest": True, "actions": ["set_dynamic_loss"]},
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
        "dynamic_loss": {"ratio": -0.1, "close_invest": True},
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {"template": "standard"},
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 1000000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": True,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
