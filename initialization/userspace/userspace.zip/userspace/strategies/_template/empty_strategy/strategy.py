#!/usr/bin/env python3
"""空白策略模板 — 复制后在此实现 has_opportunity 等钩子。"""

from __future__ import annotations

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


class EmptyStrategy(StrategyHooks):
    """复制到新目录后重命名本类，并实现 ``has_opportunity``。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        return False
