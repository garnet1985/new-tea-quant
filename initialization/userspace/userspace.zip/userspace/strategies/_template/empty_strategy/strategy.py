#!/usr/bin/env python3
"""空白策略模板 — 复制后在此实现 scan_opportunity 等钩子。"""

from __future__ import annotations

from typing import Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

__all__ = ["EmptyStrategy"]


class EmptyStrategy(StrategyHooks):
    """
    空白策略模板。

    复制到新策略目录后：
    1. 重命名本类（如 ``MyRsiStrategy``）
    2. 在 ``scan_opportunity`` 中实现入场逻辑
    3. slice_based 策略按需实现 ``on_calendar_asof``
    4. settings.simulation.execution_mode 须为 ``entity_based`` 或 ``slice_based``
    """

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        """扫描单股买入机会（必填）。"""
        return None

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        """slice_based：决定本 as_of 日哪些股票进入 scan。"""
        return super().on_calendar_asof(ctx)

    def on_before_scan(self, ctx: StrategyContext) -> None:
        return None

    def on_after_scan(self, ctx: StrategyContext) -> None:
        return None
