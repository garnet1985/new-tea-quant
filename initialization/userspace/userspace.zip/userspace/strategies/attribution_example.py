attribution = {
    "inputs": {
        "your_custom_input": {"values": [None, 20, 25]},
        "your_custom_input_another_way": {
            "values": {"range": [20, 25], "step": 5}
        },
        # stop loss 的配置方式, take profit 的配置方式类似
        # "stop_loss": {
        #     "values": [
        #         None,
        #         {"stages": [{"close_invest": True, "ratio": -0.2}]},
        #     ],
        # },
    },
    # TODO: 全轴 cross 能展开，但报告仍按单因素讲，产品还没完成。
    # "cross": False,
    # 组合层单独归因：只改资金分配，锚定当前 version，不进上面的共用 inputs。
    # 整段不写时，按当前 settings 生成默认档（三种分配方式、持仓档、资金档，
    # 以及 settings 里已有的单票上限 / Kelly 系数 / 每笔手数）。
    # 配置同样支持range + step的方式，比如：
    # "max_portfolio_size": {"values": {"range": [4, 20], "step": 4}},
    # "allocation": {
    #     "mode": {"values": ["equal_shares", "equal_capital", "kelly"]},
    #     "max_portfolio_size": {"values": [4, 8, 10, 15, 20]},
    #     "initial_capital": {"values": [50000, 100000, 200000]},
    #     "max_weight_per_stock": {"values": [0.2, 0.33, 0.5]},
    #     "kelly_fraction": {"values": [0.25, 0.5, 1.0]},
    #     "lots_per_trade": {"values": [1, 2]},
    # },
    # TODO: 滚动验证的产品口径还没定，先不要打开。
    # "rolling": {
    #     "windows": [
    #         {"start": "20230101", "end": "20231231"},
    #     ],
    # },
}
