# 横截面演示（`demo/cross_sectional/`）

按**日历节点**在股票池内做**横截面排序 / 筛选**，再组合持仓的策略族。与 `random`（随机对照）、`regression`（单股均值回归）、`trend`（趋势，待补充）并列，作为演示策略的**第四类**。

## 与前三类的区别

| 类别 | 信号来源 | 典型执行模式 |
|------|----------|--------------|
| `random` | 无技能随机触发 | `entity_based` |
| `regression` | 单股指标偏离锚点 | `entity_based` |
| `trend` | 动量 / 趋势（占位） | — |
| **`cross_sectional`** | **全池排序 / 分位 / 因子** | **`slice_based` + `on_calendar_asof`** |

## 子族

| 子目录 | 说明 | 条数 |
|--------|------|------|
| [low_price/](low_price/README.md) | 低价股年度换仓；v1 survivor vs v2 PIT | 2 |

后续若有市值、价值等横截面 demo，可继续放在本目录下。

[← 演示总览](../README.md)
