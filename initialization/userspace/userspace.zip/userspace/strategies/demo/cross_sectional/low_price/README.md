# 低价股演示（`demo/cross_sectional/low_price/`）

对比 **幸存者偏差（v1）** 与 **PIT（v2）** 两条周期换仓策略。归属演示策略第四类 **[横截面](../README.md)**（`cross_sectional`）。

每个版本的 `strategy.py` **自包含**，不共享代码；两份逻辑相近，方便单独阅读和改。

## 策略一览

| 版本 | 路径 | 股票池 | 规则（见各自 `settings.py`） |
| --- | --- | --- | --- |
| **v1** | [low_price_v1_survivor_only/](low_price_v1_survivor_only/) | survivor（回测期末仍在市） | 月初选 2–5 元最低价 top 10；约 30 个自然日后 `goal.expiration` 卖出 |
| **v2** | [low_price_v2_PIT/](low_price_v2_PIT/) | PIT（含中途退市） | 同上；因含退市路径，收益往往低于 v1 |

## 准备数据

```bash
python cli.py r stock_klines
```

## 怎么跑

```bash
python cli.py s -f --strategy demo/cross_sectional/low_price/low_price_v1_survivor_only
python cli.py s -f --strategy demo/cross_sectional/low_price/low_price_v2_PIT
```

改 settings 后请 `-f` 强制重跑枚举与模拟。

## 解读提示

- PIT 多出的退市股若在持仓期内退市，v2 会多一段下跌 exposure
- 非投资建议

[← 横截面总览](../README.md) · [← 演示总览](../../README.md)
