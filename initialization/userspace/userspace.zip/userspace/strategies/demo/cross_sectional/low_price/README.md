# 低价股演示（`demo/cross_sectional/low_price/`）

对比 **幸存者偏差（v1）** 与 **PIT（v2）** 两条年度换仓策略。归属演示策略第四类 **[横截面](../README.md)**（`cross_sectional`）。

## 策略一览

| 版本 | 路径 | 股票池 | 规则 | 预期 |
| --- | --- | --- | --- | --- |
| **v1** | [low_price_v1_survivor_monthly_rebalance/](low_price_v1_survivor_monthly_rebalance/) | survivor | 1–5 元 top 20，**每年**首个交易日买、末个交易日卖 | 相对 v2 收益往往偏高 |
| **v2** | [low_price_v2_monthly_rebalance/](low_price_v2_monthly_rebalance/) | PIT（含中途退市） | 同上 | 含退市路径，收益往往更低 |

共用规则（见 [shared/selection.py](shared/selection.py)、[shared/calendar_period.py](shared/calendar_period.py)）：

- `rebalance_period=year`：每年**首个**开市日选股，**最后**开市日清仓（持约一年）
- 收盘价 **1–5 元**（含），按价从低到高最多 **20** 只；**无**市值 / Tag 过滤
- 资金：**等手数** `equal_shares`，每只 **2 手（200 股）**，`max_portfolio_size=20`

各版本的 `strategy.py`（`StrategyHooks`）**自行声明** `on_calendar_asof` / `has_opportunity` 钩子，并在钩子里逐步编排筛选；`shared/` 仅提供原子步骤（价格带、市值/Tag 过滤、日历边界判定等）。

## 准备数据

```bash
python cli.py r stock_klines
```

## 怎么跑

```bash
python cli.py s -f --strategy demo/cross_sectional/low_price/low_price_v1_survivor_monthly_rebalance
python cli.py s -f --strategy demo/cross_sectional/low_price/low_price_v2_monthly_rebalance
```

改 settings 后请 `-f` 强制重跑枚举与模拟。

## 解读提示

- 相对旧版「月度 2–3 元 + top10」，年度持有 + 宽价格带 + 更多标的，**更易拉开 v1/v2**
- PIT 多出的退市股若在入选年度内持有，v2 会多一段下跌 exposure
- Tag 演示请用其他策略；本目录不再包含 v3
- 非投资建议

[← 横截面总览](../README.md) · [← 演示总览](../../README.md)
