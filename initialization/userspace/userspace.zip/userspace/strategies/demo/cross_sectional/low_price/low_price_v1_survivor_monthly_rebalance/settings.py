settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_v1",
        "display_name": "低价股 · v1 年度换仓（幸存者 · 仅价格）",
        "description": "演示幸存者偏差：股票池剔除回测结束前已退市股票；每年首个交易日选 1–5 元最低价 top 20，持有一年（年末清仓）。相对 v2 "
        "往往收益偏高（看不见中途退市股）。",
        "keywords": ["演示", "低价股", "幸存者偏差", "calendar_slice"],
        "details": {
            "entry": [
                "股票池是所有活着的股票（就是大家平时在交易软件里看到的所有有行情的股票）",
                "筛选出1-5元之间的股票，每年选出20只最低价的股票，持有约一年",
                "每年换仓一次",
            ]
        },
    },
    "core": {
        "universe_mode": "survivor",
        "rebalance_period": "year",
        "min_close": 1.0,
        "max_close": 5.0,
        "top_n": 20,
        "cap_filter": "none",
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "required": [],
        "min_required_records": 1,
    },
    "goal": {"is_customized": True},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "slice_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "close",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 25000,
        "allocation": {
            "mode": "equal_shares",
            "max_portfolio_size": 20,
            "lots_per_trade": 2,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
