#!/usr/bin/env python3
"""v1：survivor 股票池 + 年度换仓横截面 demo。"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Optional, Tuple

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

_SHARED = Path(__file__).resolve().parents[1] / "shared"
if str(_SHARED) not in sys.path:
    sys.path.insert(0, str(_SHARED))

from calendar_period import (  # noqa: E402
    is_rebalance_period_end,
    is_rebalance_period_start,
    require_rebalance_period,
)
from selection import (  # noqa: E402
    INDICATORS,
    TAGS_SLOT,
    RebalanceFilters,
    find_bar_on_date,
    passes_cap_filter,
    passes_price_range,
)

__all__ = ["LowPriceSurvivorRebalanceStrategy"]


class LowPriceSurvivorRebalanceStrategy(StrategyHooks):
    """幸存者偏差对照：周期首个交易日横截面选股，末个交易日清仓。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        calendar = ctx.data.calendar
        as_of_date = str(calendar.get("as_of_date") or ctx.data.now or "")
        if not calendar:
            return CalendarAsOfResult(as_of_date=as_of_date, stocks=[])

        settings = ctx.effective_settings_dict()
        session_state = dict(calendar.get("session_state") or {})
        period = require_rebalance_period(settings)

        if is_rebalance_period_end(calendar, period):
            session_state["force_exit_open_date"] = as_of_date
            session_state.pop("period_selected", None)
            return CalendarAsOfResult(
                as_of_date=as_of_date,
                stocks=[],
                session_state=session_state,
            )

        if not is_rebalance_period_start(calendar, period):
            return CalendarAsOfResult(
                as_of_date=as_of_date,
                stocks=[],
                session_state=session_state,
            )

        filters = RebalanceFilters.from_settings(settings)
        stocks_map = ctx.data.by_entity or {}

        candidates: List[Tuple[str, float]] = []
        for sid, stock_data in stocks_map.items():
            if not isinstance(stock_data, dict):
                continue
            sid_s = str(sid).strip()
            if not sid_s:
                continue

            base_key = str(ctx.base_data_key or "").strip()
            bars = stock_data.get(base_key) if base_key else None
            if not bars:
                continue
            bar = find_bar_on_date(bars, as_of_date)
            if bar is None:
                continue

            close = float(bar["close"])
            if not passes_price_range(close, filters.min_close, filters.max_close):
                continue

            indicators = stock_data.get(INDICATORS) or []
            tag_rows = stock_data.get(TAGS_SLOT) or []
            if not passes_cap_filter(
                filters=filters,
                as_of_date=as_of_date,
                indicators=indicators,
                tag_rows=tag_rows,
            ):
                continue

            candidates.append((sid_s, close))

        candidates.sort(key=lambda item: (item[1], item[0]))
        selected = [sid for sid, _ in candidates[: filters.top_n]]

        session_state["period_selected"] = list(selected)
        session_state.pop("force_exit_open_date", None)
        return CalendarAsOfResult(
            as_of_date=as_of_date,
            stocks=selected,
            session_state=session_state,
        )

    def calendar_asof_needs_by_entity(self, ctx: StrategyContext) -> bool:
        """仅换仓首日需要 by_entity 做横截面选股。"""
        calendar = ctx.data.calendar or {}
        if not calendar:
            return False
        settings = ctx.effective_settings_dict()
        period = require_rebalance_period(settings)
        if is_rebalance_period_end(calendar, period):
            return False
        return bool(is_rebalance_period_start(calendar, period))

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        record_of_today = self.get_record_of_today(
            data, base_data_key=ctx.base_data_key
        )
        if record_of_today is None:
            return None

        close = float(record_of_today["close"])
        period = require_rebalance_period(settings)

        return self.build_opportunity(
            ctx,
            record_of_today,
            extra_fields={
                "close": close,
                "rebalance": period,
            },
        )
