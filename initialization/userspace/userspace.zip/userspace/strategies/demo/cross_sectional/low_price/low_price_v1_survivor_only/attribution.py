# 归因示例（low_price_v1）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照入选只数和价格上限。股票池模式保持幸存者，不在这里和 PIT 混扫。
# 先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "top_n": {"values": [5, 10, 20]},
        "max_close": {"values": [4, 5, 8]},
    },
    "cross": False,
}
