settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_v1",
        "display_name": "低价股v1 · 仅幸存者",
        "description": "低价股策略：所有股票均是回测阶段未退市股票。",
        "category": "横截面策略",
        "keywords": ["低价股", "幸存者偏差"],
        "details": {
            "entry": [
                "对所有股票每月按价格排序",
                "从2元开始向上取10只股票，最高5元，如果不足10只，则不再增加额外任何股票的投资",
                "持满一个月后用同样方法换另10只股票",
            ]
        },
    },
    "core": {
        "universe_mode": "survivor",
        "rebalance_period": "month",
        "min_close": 2.0,
        "max_close": 5.0,
        "top_n": 10,
        "cap_filter": "none",
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "required": [],
        "min_required_records": 1,
    },
    "goal": {"is_customized": True},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "slice_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "close",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_shares",
            "max_portfolio_size": 20,
            "lots_per_trade": 2,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
