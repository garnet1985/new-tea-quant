#!/usr/bin/env python3
"""v1：幸存者股票池 + 月初横截面选低价股。出场见 settings.goal.expiration。"""

from __future__ import annotations

from typing import List, Mapping, Tuple

from core.modules.strategy.contracts import (
    CalendarSlice,
    Records,
    StrategyContext,
    StrategyHooks,
)


class LowPriceSurvivorRebalanceStrategy(StrategyHooks):
    """每月第一个开市日：幸存者池内按收盘价从低到高取 top N。"""

    def on_calendar_slice(
        self, ctx: StrategyContext, calendar_slice: CalendarSlice
    ) -> List[str]:
        if not calendar_slice.is_first_open_of_month:
            return []

        core = ctx.effective_settings_dict()["core"]
        min_close = float(core["min_close"])
        max_close = float(core["max_close"])
        top_n = int(core["top_n"])

        candidates: List[Tuple[str, float]] = []
        for sid in calendar_slice.ids():
            bar = calendar_slice.records_of(sid).latest
            if not isinstance(bar, Mapping):
                continue
            try:
                close = float(bar["close"])
            except (KeyError, TypeError, ValueError):
                continue
            if min_close <= close <= max_close:
                candidates.append((sid, close))

        candidates.sort(key=lambda item: (item[1], item[0]))
        return [sid for sid, _ in candidates[:top_n]]

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        _ = (ctx, records)
        return True
