#!/usr/bin/env python3
"""v1：幸存者股票池 + 月初横截面选低价股。出场见 settings.goal.expiration。"""

from __future__ import annotations

from typing import Any, List, Mapping, Sequence, Tuple

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    StrategyHooks,
)


def _bar_on_date(rows: Sequence[Mapping[str, Any]], as_of_date: str) -> Mapping[str, Any]:
    for row in reversed(rows):
        dt = str(row["date"])
        if dt == as_of_date:
            return row
        if dt < as_of_date:
            break
    raise KeyError(as_of_date)


class LowPriceSurvivorRebalanceStrategy(StrategyHooks):
    """每月第一个开市日：幸存者池内按收盘价从低到高取 top N。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        calendar = ctx.data.calendar
        as_of_date = str(calendar["as_of_date"])
        if not calendar.get("is_first_open_of_month"):
            return CalendarAsOfResult(as_of_date=as_of_date, stocks=[])

        core = ctx.effective_settings_dict()["core"]
        min_close = float(core["min_close"])
        max_close = float(core["max_close"])
        top_n = int(core["top_n"])
        base_key = ctx.base_data_key

        candidates: List[Tuple[str, float]] = []
        for sid, stock_data in ctx.data.by_entity.items():
            try:
                bar = _bar_on_date(stock_data[base_key], as_of_date)
                close = float(bar["close"])
            except (KeyError, TypeError, ValueError):
                continue
            if min_close <= close <= max_close:
                candidates.append((str(sid), close))

        candidates.sort(key=lambda item: (item[1], item[0]))
        return CalendarAsOfResult(
            as_of_date=as_of_date,
            stocks=[sid for sid, _ in candidates[:top_n]],
        )

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        core = ctx.effective_settings_dict()["core"]
        record = ctx.record_of_today
        ctx.capture("close", float(record["close"]))
        ctx.capture("min_close", float(core["min_close"]))
        ctx.capture("max_close", float(core["max_close"]))
        ctx.capture("top_n", int(core["top_n"]))
        return True
