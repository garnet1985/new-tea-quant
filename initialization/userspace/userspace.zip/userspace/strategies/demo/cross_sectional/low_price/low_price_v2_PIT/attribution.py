# 归因示例（low_price_v2）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照入选只数和价格上限。股票池模式保持 PIT，不在这里和幸存者池混扫。
# 先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "top_n": {"values": [5, 10, 20]},
        "max_close": {"values": [4, 5, 8]},
    },
    "cross": False,
}
