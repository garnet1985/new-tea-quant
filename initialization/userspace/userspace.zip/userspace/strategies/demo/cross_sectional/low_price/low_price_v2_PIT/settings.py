# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_v2",
        "display_name": "低价股 · 含退市股",
        "description": "相对 v1：股票池改为 PIT（含回测期内退市股），用于观察幸存者偏差对收益的影响。",
        "category": "横截面策略",
        "keywords": ["低价股", "PIT"],
        "details": {
            "entry": [
                "每月第一个开市日，对 PIT 池（含退市）按收盘价从低到高排序",
                "取 2–5 元区间内最低价的 10 只（不足则有多少取多少）",
            ]
        },
    },
    "analysis": {"enabled": True},
    "core": {"max_close": 5, "min_close": 2, "top_n": 10, "universe_mode": "pit"},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 1,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {"expiration": {"fixed_window_in_days": 30, "mode": "natural_day"}},
    "portfolio": {
        "allocation": {
            "lots_per_trade": 2,
            "max_portfolio_size": 20,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "slice_based", "start_date": ""},
        "assumption": {
            "target_check_order": ["check_stop_loss", "check_take_profit", "check_expiration"],
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "close",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
