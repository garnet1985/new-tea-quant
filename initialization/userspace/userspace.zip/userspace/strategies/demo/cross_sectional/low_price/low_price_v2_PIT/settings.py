# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_v2",
        "display_name": "低价股v1 · 含退市股",
        "description": "低价股策略：股票池含回测期内中途退市股票。理论收益将低于仅幸存者偏差（v1）策略。",
        "category": "横截面策略",
        "keywords": ["低价股"],
        "details": {
            "entry": [
                "对所有股票每月按价格排序",
                "从2元开始向上取10只股票，最高5元，如果不足10只，则不再增加额外任何股票的投资",
                "持满一个月后用同样方法换另10只股票",
            ]
        },
        "is_enabled": True,
    },
    "analysis": {"enabled": True},
    "core": {
        "cap_filter": "none",
        "max_close": 5,
        "min_close": 2,
        "rebalance_period": "month",
        "top_n": 10,
        "universe_mode": "pit",
    },
    "data": {
        "base": {"data_key": "stock.kline.daily", "indicators": {}, "params": {}},
        "min_required_records": 1,
        "required": [],
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {"is_customized": True},
    "portfolio": {
        "allocation": {
            "lots_per_trade": 2,
            "max_portfolio_size": 20,
            "mode": "equal_shares",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "slice_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "close",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
