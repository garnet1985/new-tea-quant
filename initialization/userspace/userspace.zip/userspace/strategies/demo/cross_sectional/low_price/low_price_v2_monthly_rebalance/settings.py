settings = {
    "is_enabled": True,
    "meta": {
        "key": "low_price_v2",
        "display_name": "低价股 · v2 年度换仓（PIT · 仅价格）",
        "description": "与 v1 逻辑相同，但股票池为 PIT：含回测期内中途退市股票。用于对比幸存者偏差（v1）与真实可参与集合（v2）。",
        "keywords": ["演示", "低价股", "PIT", "calendar_slice"],
        "details": {
            "entry": [
                "股票池真正的所有股票（包含模拟过程中可能退市的股票）",
                "筛选出1-5元之间的股票，每年选出20只最低价的股票，持有约一年",
                "每年换仓一次",
            ]
        },
    },
    "core": {
        "universe_mode": "pit",
        "rebalance_period": "year",
        "min_close": 1.0,
        "max_close": 5.0,
        "top_n": 20,
        "cap_filter": "none",
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "required": [],
        "min_required_records": 1,
    },
    "goal": {"is_customized": True},
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "slice_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "close",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 25000,
        "allocation": {
            "mode": "equal_shares",
            "max_portfolio_size": 20,
            "lots_per_trade": 2,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
