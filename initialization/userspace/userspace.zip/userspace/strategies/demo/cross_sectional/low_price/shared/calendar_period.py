#!/usr/bin/env python3
"""换仓日历边界判定（不含选股编排）。"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Dict, Union

CalendarLike = Union[Mapping[str, Any], Any]

_SHARED_DIR = Path(__file__).resolve().parent
if str(_SHARED_DIR) not in sys.path:
    sys.path.insert(0, str(_SHARED_DIR))

from settings_core import SettingsCoreError, require_core_str  # noqa: E402

_VALID_PERIODS = frozenset({"month", "year"})


def _calendar_get(calendar: CalendarLike, key: str, default: Any = None) -> Any:
    if isinstance(calendar, Mapping):
        return calendar.get(key, default)
    return getattr(calendar, key, default)


def require_rebalance_period(settings: Dict[str, Any]) -> str:
    period = require_core_str(settings, "rebalance_period").lower()
    if period not in _VALID_PERIODS:
        raise SettingsCoreError(
            f"settings.core.rebalance_period must be one of {sorted(_VALID_PERIODS)}, got {period!r}"
        )
    return period


def is_rebalance_period_start(calendar: CalendarLike, period: str) -> bool:
    """周期首个决策日；优先读 calendar.is_period_start（engine 注入）。"""
    explicit = _calendar_get(calendar, "is_period_start")
    if explicit is not None:
        return bool(explicit)
    if period == "year":
        return bool(_calendar_get(calendar, "is_first_open_of_year"))
    return bool(_calendar_get(calendar, "is_first_open_of_month"))


def is_rebalance_period_end(calendar: CalendarLike, period: str) -> bool:
    """周期末个决策日；优先读 calendar.is_period_end（engine 注入）。"""
    explicit = _calendar_get(calendar, "is_period_end")
    if explicit is not None:
        return bool(explicit)
    if period == "year":
        return bool(_calendar_get(calendar, "is_last_open_of_year"))
    return bool(_calendar_get(calendar, "is_last_open_of_month"))


__all__ = [
    "is_rebalance_period_end",
    "is_rebalance_period_start",
    "require_rebalance_period",
]
