#!/usr/bin/env python3
"""严格读取 settings.core：缺字段或类型不对时立即报错。"""

from __future__ import annotations

from typing import Any, Dict, Iterable, Sequence


class SettingsCoreError(KeyError):
    """settings.core 缺少必填字段或值无效。"""


def require_core(settings: Dict[str, Any], key: str) -> Any:
    try:
        core = settings["core"]
    except KeyError as exc:
        raise SettingsCoreError("settings.core is required") from exc
    if key not in core:
        raise SettingsCoreError(f"settings.core.{key} is required")
    return core[key]


def require_core_str(settings: Dict[str, Any], key: str) -> str:
    value = require_core(settings, key)
    text = str(value).strip()
    if not text:
        raise SettingsCoreError(f"settings.core.{key} must be a non-empty string")
    return text


def require_core_float(settings: Dict[str, Any], key: str) -> float:
    raw = require_core(settings, key)
    try:
        return float(raw)
    except (TypeError, ValueError) as exc:
        raise SettingsCoreError(f"settings.core.{key} must be a number") from exc


def require_core_int(settings: Dict[str, Any], key: str) -> int:
    raw = require_core(settings, key)
    try:
        return int(raw)
    except (TypeError, ValueError) as exc:
        raise SettingsCoreError(f"settings.core.{key} must be an integer") from exc


def require_core_str_list(settings: Dict[str, Any], key: str) -> Sequence[str]:
    raw = require_core(settings, key)
    if not isinstance(raw, Iterable) or isinstance(raw, (str, bytes)):
        raise SettingsCoreError(f"settings.core.{key} must be a list of strings")
    items = [str(item).strip() for item in raw if str(item).strip()]
    if not items:
        raise SettingsCoreError(f"settings.core.{key} must contain at least one item")
    return items


__all__ = [
    "SettingsCoreError",
    "require_core",
    "require_core_float",
    "require_core_int",
    "require_core_str",
    "require_core_str_list",
]
