# 归因示例（random_v1）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照入场概率和止损。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "entry_probability": {"values": [0.01, 0.03, 0.05]},
        "stop_loss": {"values": [-0.15, -0.2, -0.25]},
    },
    "cross": False,
}
