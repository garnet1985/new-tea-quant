# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "random_v1",
        "display_name": "随机买卖策略 · 作为对比基准的版本",
        "description": "零技能基线：固定概率随机买入，用于对比后续版本。",
        "category": "随机策略",
        "keywords": ["随机", "市场整体收益"],
        "details": {
            "entry": [
                "每根K线有 3% 概率买入",
                "命中则买入，不论价格、不论哪只股票",
            ]
        },
    },
    "analysis": {"enabled": True},
    "core": {"entry_probability": 0.03, "seed": 6},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 5,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {"stages": [{"close_invest": True, "ratio": 0.2}]},
    },
    "portfolio": {
        "allocation": {
            "kelly_fraction": 0.5,
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
