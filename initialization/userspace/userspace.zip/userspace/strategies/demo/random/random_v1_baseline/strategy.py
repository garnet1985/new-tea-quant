#!/usr/bin/env python3
"""随机对照演示策略 v1 — 零技能基线。"""

from __future__ import annotations

from core.infra.utils import Utils
from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


class RandomNullBaselineStrategy(StrategyHooks):
    """按 ``core.entry_probability`` 随机买入；``core.seed`` 保证可复现。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        core = ctx.effective_settings_dict()["core"]
        seed = int(core["seed"])
        p = float(core["entry_probability"])
        roll = Utils.math.deterministic_unit_float(
            records.entity_id, records.latest["date"], seed
        )
        if roll >= p:
            return False
        ctx.capture("roll", roll)
        return True
