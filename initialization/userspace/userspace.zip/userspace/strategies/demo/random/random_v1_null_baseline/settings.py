settings = {
    "is_enabled": True,
    "meta": {
        "key": "random_v1",
        "display_name": "随机买卖策略v1 · 纯随机投资",
        "description": "演示策略：按固定概率随机买入。止损止盈对称相等。演示意义：随机策略一定程度能反映出市场整体的收益率水平，也可以作为其他策略的收益衡量基准。",
        "keywords": ["演示", "随机", "对照组", "零技能"],
        "details": {"entry": ["固定概率，中签就买。"]},
    },
    "core": {"seed": 6, "entry_probability": 0.03},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "required": [],
        "min_required_records": 5,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "open_day"},
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {
            "start_date": "20240101",
            "end_date": "20241231",
            "mode": "entity_based",
        },
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
