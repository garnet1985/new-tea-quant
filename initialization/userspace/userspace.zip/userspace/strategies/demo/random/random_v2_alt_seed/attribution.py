# 归因示例（random_v2）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照随机种子和入场概率。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "seed": {"values": [6, 42, 99]},
        "entry_probability": {"values": [0.01, 0.03, 0.05]},
    },
    "cross": False,
}
