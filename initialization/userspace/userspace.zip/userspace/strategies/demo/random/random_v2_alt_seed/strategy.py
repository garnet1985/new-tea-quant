#!/usr/bin/env python3
"""随机对照演示策略 v2 — 与 v1 相同逻辑，仅更换 seed。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

logger = logging.getLogger(__name__)


class RandomAltSeedStrategy(StrategyHooks):
    """
    与 ``random_v1_null_baseline`` 相同：按 ``core.entry_probability`` 随机触发买入。

    本版仅更换 ``core.seed``，用于对比「同规则、不同随机路径」下的回测差异。
    """

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        record_of_today = self.get_record_of_today(
            data, base_data_key=ctx.base_data_key
        )
        if record_of_today is None:
            return None

        if not self._is_lucky_day(ctx, record_of_today, settings):
            return None

        return self._build_lucky_day_opportunity(ctx, record_of_today, settings)

    @staticmethod
    def _stock_id(ctx: StrategyContext) -> str:
        entity_id = str(ctx.data.entity_id or "").strip()
        if not entity_id:
            raise ValueError("scan 缺少 entity_id")
        return entity_id

    def _is_lucky_day(
        self,
        ctx: StrategyContext,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> bool:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self._stock_id(ctx),
            self.signal_date(record_of_today),
            seed,
        )
        return roll < entry_probability

    def _build_lucky_day_opportunity(
        self,
        ctx: StrategyContext,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> Opportunity:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self._stock_id(ctx),
            self.signal_date(record_of_today),
            seed,
        )
        return self.build_opportunity(
            ctx,
            record_of_today,
            extra_fields={
                "random_roll": roll,
                "entry_probability": entry_probability,
                "seed": seed,
            },
        )
