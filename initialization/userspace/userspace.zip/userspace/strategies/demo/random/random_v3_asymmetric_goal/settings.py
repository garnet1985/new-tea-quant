# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "random_v3",
        "display_name": "随机买卖策略v3 · 止盈不对称",
        "description": "相对 v1：入场与 seed 相同，止盈改为 +40%（止损仍 -20%），观察不对称出场对胜率与收益的影响。",
        "category": "随机策略",
        "keywords": ["随机", "市场整体收益", "止盈大于止损"],
        "details": {
            "entry": [
                "每根K线有 3% 概率买入",
                "命中则买入，不论价格、不论哪只股票",
            ]
        },
    },
    "analysis": {"enabled": True},
    "core": {"seed": 6, "entry_probability": 0.03},
    "data": {
        "base": {"data_key": "stock.kline.daily"},
        "min_required_records": 5,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.4, "close_invest": True}]},
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
}
