#!/usr/bin/env python3
"""随机对照演示策略 v3 — 与 v1 相同入场，不对称止损止盈。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

logger = logging.getLogger(__name__)


class RandomAsymmetricGoalStrategy(StrategyHooks):
    """
    与 ``random_v1_null_baseline`` 相同随机入场（``seed=6``）。

    本版仅调整 ``goal``：止损 -20%、止盈 +30%，用于观察不对称出场对 ROI 分布的影响。
    """

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        record_of_today = self.get_record_of_today(
            data, base_data_key=ctx.base_data_key
        )
        if record_of_today is None:
            return None

        if not self._is_lucky_day(ctx, record_of_today, settings):
            return None

        return self._build_lucky_day_opportunity(ctx, record_of_today, settings)

    @staticmethod
    def _stock_id(ctx: StrategyContext) -> str:
        entity_id = str(ctx.data.entity_id or "").strip()
        if not entity_id:
            raise ValueError("scan 缺少 entity_id")
        return entity_id

    def _is_lucky_day(
        self,
        ctx: StrategyContext,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> bool:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self._stock_id(ctx),
            self.signal_date(record_of_today),
            seed,
        )
        return roll < entry_probability

    def _build_lucky_day_opportunity(
        self,
        ctx: StrategyContext,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> Opportunity:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self._stock_id(ctx),
            self.signal_date(record_of_today),
            seed,
        )
        return self.build_opportunity(
            ctx,
            record_of_today,
            extra_fields={
                "random_roll": roll,
                "entry_probability": entry_probability,
                "seed": seed,
            },
        )
