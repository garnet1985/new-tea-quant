#!/usr/bin/env python3
"""随机对照演示策略 v3 — 与 v1 相同入场；止盈不对称。"""

from __future__ import annotations

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


class RandomAsymmetricGoalStrategy(StrategyHooks):
    """与 v1 相同随机入场（同 seed）；差别只在 ``goal``。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        core = ctx.effective_settings_dict()["core"]
        seed = int(core["seed"])
        p = float(core["entry_probability"])
        roll = self.deterministic_roll(
            ctx.data.entity_id, ctx.record_of_today["date"], seed
        )
        if roll >= p:
            return False
        ctx.capture("roll", roll)
        ctx.capture("entry_probability", p)
        ctx.capture("seed", seed)
        return True
