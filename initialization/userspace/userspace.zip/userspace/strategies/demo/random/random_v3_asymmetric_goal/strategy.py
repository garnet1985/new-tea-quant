#!/usr/bin/env python3
"""随机对照演示策略 v3 — 与 v1 相同入场；止盈不对称。"""

from __future__ import annotations

from core.infra.utils import Utils
from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


class RandomAsymmetricGoalStrategy(StrategyHooks):
    """与 v1 相同随机入场（同 seed）；差别只在 ``goal``。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        core = ctx.effective_settings_dict()["core"]
        seed = int(core["seed"])
        p = float(core["entry_probability"])
        roll = Utils.math.deterministic_unit_float(
            records.entity_id, records.latest["date"], seed
        )
        if roll >= p:
            return False
        ctx.capture("roll", roll)
        return True
