# 均值回归演示（`demo/regression/`）

## 这组 demo 是干什么的？

「均值回归」意味着你认为价格暂时偏离某个**锚**，并可能向区间回归。RSI / 布林带是测偏离的**尺子**——不是保证赚钱的公式。单边下跌时超卖可以持续超卖，往往是 **regime 不对**。

## RSI 线（3 条）

| 目录 | `meta.key` | UI 展示名 | 多讲的一件事 |
|------|-----------|-----------|--------------|
| `demo/regression/rsi/rsi_v1_baseline` | `rsi_v1` | RSI超跌反弹v1 · 作为对比基准的版本 | 纯 RSI(14) 超卖 |
| `demo/regression/rsi/rsi_v2_net_profit_gate` | `rsi_v2` | RSI超跌反弹v2 · 净利润同比门槛 | + 最新已披露季度净利润同比 |
| `demo/regression/rsi/rsi_v3_pe_percentile_gate` | `rsi_v3` | RSI超跌反弹v3 · PE历史分位 | + PE 历史分位 |

**UI 对比建议**：依次打开 v1 → v2 → v3，每步跑完看 **枚举机会** 报告中的机会总数如何下降。

## 布林带线（4 条）

| 目录 | `meta.key` | UI 展示名 | 多讲的一件事 |
|------|-----------|-----------|--------------|
| `demo/regression/bb/bb_v1_baseline` | `bb_v1` | 布林带下轨v1 · 作为对比基准的版本 | 日线下轨下方 |
| `demo/regression/bb/bb_v2_weekly_filter` | `bb_v2` | 布林带下轨v2 · 周线过滤 | + 周线下轨（需 weekly 数据） |
| `demo/regression/bb/bb_v3_managed_exit` | `bb_v3` | 布林带下轨v3 · 分阶段出场 | 同 v2 入场，ratio 多阶段出场 |
| `demo/regression/bb/bb_v4_custom_goal` | `bb_v4` | 布林带下轨v4 · 自定义出场 | 同 v2 入场，中轨保护 + 上轨 custom 清仓 |

**UI 对比建议**：

- v1 vs v2：对比 **枚举** 机会数（周线过滤通常更少）
- v2 vs v3：**入场相同**，重点看 **价格回测 / 组合模拟** 报告与单股 K 线
- v3 vs v4：出场从固定 `ratio` 改为 `goal` 段上的 `custom`，由 `StrategyHooks.is_take_profit` 判断（读 bar 上 BB 上/中轨）

> v2 / v3 / v4 依赖周线 K 线，请先在 **设置** 或数据更新流程中保证 `stock.kline.weekly` 已就绪。

## 与随机对照

在 UI 中分别打开 [随机 v1](../random/README.md) 与 RSI v1，对齐采样与 `goal` 后对比三步报告。

## 框架里能练到什么

- 设置面板中的 `data.required`、多周期 K 线、指标注入
- 报告中的单股 K 线、买卖点、版本对比
- `goal` 多阶段止盈止损（尤其 BB v3）

[← 演示总览](../README.md)
