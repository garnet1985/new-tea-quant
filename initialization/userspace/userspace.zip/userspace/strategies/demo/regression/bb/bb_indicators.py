#!/usr/bin/env python3
"""布林带演示策略共用工具（v1/v2+）。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.modules.data_contract.contracts import DATA_KEY

WEEKLY_KLINE_SLOT = DATA_KEY.STOCK_KLINE_WEEKLY


def bbands_params(settings: Dict[str, Any]) -> Dict[str, Any]:
    base = (settings.get("data") or {}).get("base") or {}
    indicators = base.get("indicators") or {}
    return dict(indicators["bbands"][0])


def bbands_lower_field_name(params: Dict[str, Any]) -> str:
    """
    与 ``StrategyDataInjectionService._build_indicator_field_name`` 写入字段一致。

    例：length=20, std=2.0 → ``bbands_bbl_20_2.020``
    """
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    sub_key = f"BBL_{length}_{std}"
    base = f"bbands_{sub_key}".lower()
    return f"{base}{length}"


def has_kline_warmup(rows: List[Dict[str, Any]], settings: Dict[str, Any]) -> bool:
    length = int(bbands_params(settings)["length"])
    return len(rows or []) >= length


def close_and_lower_band(
    record: Dict[str, Any], params: Dict[str, Any]
) -> Tuple[Optional[float], Optional[float]]:
    field = bbands_lower_field_name(params)
    close_raw = record.get("close")
    lower_raw = record.get(field)
    if close_raw is None or lower_raw is None:
        return None, None
    try:
        return float(close_raw), float(lower_raw)
    except (TypeError, ValueError):
        return None, None


def is_close_below_lower_band(record: Dict[str, Any], params: Dict[str, Any]) -> bool:
    close_value, lower_value = close_and_lower_band(record, params)
    if close_value is None or lower_value is None:
        return False
    return close_value < lower_value
