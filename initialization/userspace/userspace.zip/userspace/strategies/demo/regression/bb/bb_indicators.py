#!/usr/bin/env python3
"""布林带演示策略共用工具（v1/v2+）。"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.modules.data_contract.contracts import DATA_KEY

WEEKLY_KLINE_SLOT = DATA_KEY.STOCK_KLINE_WEEKLY

_BAND_SUFFIX = {
    "lower": "BBL",
    "middle": "BBM",
    "upper": "BBU",
}


def bbands_params(settings: Dict[str, Any]) -> Dict[str, Any]:
    base = (settings.get("data") or {}).get("base") or {}
    indicators = base.get("indicators") or {}
    return dict(indicators["bbands"][0])


def bbands_band_field_name(params: Dict[str, Any], band: str = "lower") -> str:
    """
    与 ``ContractIndicators._field_name`` 写入字段一致。

    例：length=20, std=2.0
    - lower → ``bbands_bbl_20_2.020``
    - middle → ``bbands_bbm_20_2.020``
    - upper → ``bbands_bbu_20_2.020``
    """
    suffix = _BAND_SUFFIX.get(str(band or "lower").strip().lower(), "BBL")
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    sub_key = f"{suffix}_{length}_{std}"
    base = f"bbands_{sub_key}".lower()
    return f"{base}{length}"


def bbands_lower_field_name(params: Dict[str, Any]) -> str:
    return bbands_band_field_name(params, "lower")


def has_kline_warmup(rows: List[Dict[str, Any]], settings: Dict[str, Any]) -> bool:
    length = int(bbands_params(settings)["length"])
    return len(rows or []) >= length


def close_and_lower_band(
    record: Dict[str, Any], params: Dict[str, Any]
) -> Tuple[Optional[float], Optional[float]]:
    close_raw = record.get("close")
    lower_value = bbands_band_value(record, params, "lower")
    if close_raw is None or lower_value is None:
        return None, None
    try:
        return float(close_raw), float(lower_value)
    except (TypeError, ValueError):
        return None, None


def bbands_band_value(
    record: Dict[str, Any], params: Dict[str, Any], band: str
) -> Optional[float]:
    field = bbands_band_field_name(params, band)
    raw = record.get(field)
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def is_high_at_or_above_band(
    record: Dict[str, Any], params: Dict[str, Any], band: str
) -> bool:
    high_raw = record.get("high")
    band_value = bbands_band_value(record, params, band)
    if high_raw is None or band_value is None:
        return False
    try:
        return float(high_raw) >= float(band_value)
    except (TypeError, ValueError):
        return False


def is_close_below_lower_band(record: Dict[str, Any], params: Dict[str, Any]) -> bool:
    close_value, lower_value = close_and_lower_band(record, params)
    if close_value is None or lower_value is None:
        return False
    return close_value < lower_value
