# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v1",
        "display_name": "布林带下轨v1 · 作为对比基准的版本",
        "description": "基准版本：仅日线收盘跌破布林下轨入场。",
        "category": "回归类策略",
        "keywords": ["布林带", "超卖"],
        "details": {"entry": ["日线收盘价低于布林带下轨则买入"]},
    },
    "analysis": {"enabled": True},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {"bbands": [{"length": 20, "std": 2}]},
        },
        "min_required_records": 30,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {"stages": [{"close_invest": True, "ratio": 0.2}]},
    },
    "portfolio": {
        "allocation": {
            "kelly_fraction": 0.5,
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
