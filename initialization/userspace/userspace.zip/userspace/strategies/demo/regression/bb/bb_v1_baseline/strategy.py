#!/usr/bin/env python3
"""布林带下轨回归演示策略 v1。"""

from __future__ import annotations

from typing import Any, Dict

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


def _bb_field(params: Dict[str, Any], band: str) -> str:
    suffix = {"lower": "BBL", "middle": "BBM", "upper": "BBU"}[band]
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    return f"bbands_{suffix}_{length}_{std}{length}".lower()


class BbLowerTouchStrategy(StrategyHooks):
    """收盘价低于日线布林下轨时买入。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        params = settings["data"]["base"]["indicators"]["bbands"][0]
        record = ctx.record_of_today
        close = float(record["close"])
        lower = float(record[_bb_field(params, "lower")])
        if close >= lower:
            return False
        ctx.capture("close", close)
        ctx.capture("bb_lower", lower)
        ctx.capture("bb_length", int(params["length"]))
        ctx.capture("bb_std", float(params.get("std", 2.0)))
        return True
