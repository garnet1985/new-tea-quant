#!/usr/bin/env python3
"""布林带下轨回归演示策略 v1。"""

from __future__ import annotations

from typing import Any, Dict

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


def _bb_field(params: Dict[str, Any], band: str) -> str:
    suffix = {"lower": "BBL", "middle": "BBM", "upper": "BBU"}[band]
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    # 与 pandas-ta / field_naming 一致：无 alias 时落盘为 bbl_20_2.0
    return f"{suffix}_{length}_{std}".lower()


class BbLowerTouchStrategy(StrategyHooks):
    """收盘价低于日线布林下轨时买入。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        settings = ctx.effective_settings_dict()
        params = settings["data"]["base"]["indicators"]["bbands"][0]
        record = records.latest
        close = float(record["close"])
        lower = float(record[_bb_field(params, "lower")])
        if close >= lower:
            return False
        return True
