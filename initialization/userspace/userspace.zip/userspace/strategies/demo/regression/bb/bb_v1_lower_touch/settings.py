settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v1",
        "display_name": "布林带下轨回归 · v1 基础",
        "description": "演示策略：日线收盘价落在布林带下轨下方时买入，演示均值回归「尺子」与 base K 线 indicators 注入。出场为固定止盈止损 + "
        "持仓期限，便于与后续 v2（周线过滤）、v3（protect/dynamic）对比。",
        "keywords": ["演示", "回归", "布林带", "BB"],
        "details": {
            "entry": [
                "BB(20, 2)：收盘价 < 下轨（相对近期均值偏低的启发式信号）",
                "数据：base stock.kline.daily + indicators.bbands",
                "建议对比：demo/regression/rsi/rsi_v1_without_value_anchor（另一把尺子）",
            ]
        },
    },
    "core": {},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        },
        "required": [],
        "min_required_records": 30,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
