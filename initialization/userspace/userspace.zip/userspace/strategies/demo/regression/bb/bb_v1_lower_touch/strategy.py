#!/usr/bin/env python3
"""布林带下轨回归演示策略 v1。"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

_BB_PKG = Path(__file__).resolve().parents[1]
if str(_BB_PKG) not in sys.path:
    sys.path.insert(0, str(_BB_PKG))

from bb_indicators import (  # noqa: E402
    bbands_params,
    close_and_lower_band,
    has_kline_warmup,
    is_close_below_lower_band,
)

logger = logging.getLogger(__name__)


class BbLowerTouchStrategy(StrategyHooks):
    """收盘价低于布林带下轨时产生买入信号。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        base_data_key = ctx.base_data_key
        record_of_today = self.get_record_of_today(data, base_data_key=base_data_key)
        if record_of_today is None:
            return None

        params = bbands_params(settings)
        klines = data.get(base_data_key) or []
        if not has_kline_warmup(klines, settings):
            return None
        if not is_close_below_lower_band(record_of_today, params):
            return None

        close_value, lower_value = close_and_lower_band(record_of_today, params)
        return self.build_opportunity(
            ctx,
            record_of_today,
            extra_fields={
                "close": close_value,
                "bb_lower": lower_value,
                "bb_length": int(params["length"]),
                "bb_std": float(params.get("std", 2.0)),
            },
        )
