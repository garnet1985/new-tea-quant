# 归因示例（bb_v2）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 入场在代码里，对照止损和止盈。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "stop_loss": {"values": [-0.15, -0.2, -0.25]},
        "take_profit": {"values": [0.15, 0.2, 0.3]},
    },
    "cross": False,
}
