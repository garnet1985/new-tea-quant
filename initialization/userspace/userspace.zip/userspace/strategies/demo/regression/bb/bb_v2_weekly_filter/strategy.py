#!/usr/bin/env python3
"""布林带下轨回归演示策略 v2：日线 + 周线同时跌破下轨。"""

from __future__ import annotations

from typing import Any, Dict

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


def _bb_field(params: Dict[str, Any], band: str) -> str:
    suffix = {"lower": "BBL", "middle": "BBM", "upper": "BBU"}[band]
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    return f"bbands_{suffix}_{length}_{std}{length}".lower()


class BbWeeklyFilterStrategy(StrategyHooks):
    """日线与周线收盘均低于各自布林下轨时买入。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        params = settings["data"]["base"]["indicators"]["bbands"][0]
        lower_key = _bb_field(params, "lower")

        daily = ctx.record_of_today
        close = float(daily["close"])
        lower = float(daily[lower_key])
        if close >= lower:
            return False

        weekly = ctx.data.items["stock.kline.weekly"][-1]
        weekly_close = float(weekly["close"])
        weekly_lower = float(weekly[lower_key])
        if weekly_close >= weekly_lower:
            return False

        ctx.capture("close", close)
        ctx.capture("bb_lower", lower)
        ctx.capture("weekly_close", weekly_close)
        ctx.capture("weekly_bb_lower", weekly_lower)
        ctx.capture("bb_length", int(params["length"]))
        ctx.capture("bb_std", float(params.get("std", 2.0)))
        return True
