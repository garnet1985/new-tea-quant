settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v3",
        "display_name": "布林带下轨v3 · 分阶段出场",
        "description": "布林带超卖策略：多周期K线收盘价格同时落入布林带下轨下方触发投资信号，改进止损止盈目标来减少风险。止损止盈不对称。",
        "category": "回归类策略",
        "keywords": ["布林带", "超卖", "保护止损", "追踪止损"],
        "details": {
            "entry": [
                "日线收盘价低于布林带下轨触发买入信号",
                "周线收盘价低于周线布林带下轨触发买入信号",
                "盈利20%时卖出半仓，并设置价格跌回买入成本的保护止损",
                "当盈利超过30%平仓30%，然后设置追踪止损 - 最大回撤超过前一日价格的10%就清仓，否则一直不平仓",
            ]
        },
    },
    "core": {},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        },
        "required": [
            {
                "data_key": "stock.kline.weekly",
                "params": {"adjust": "qfq"},
                "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
            }
        ],
        "min_required_records": 100,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {"ratio": 0.2, "exit_ratio": 0.5, "actions": ["set_protect_loss"]},
                {"ratio": 0.3, "exit_ratio": 0.3, "actions": ["set_dynamic_loss"]},
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
        "dynamic_loss": {"ratio": -0.1, "close_invest": True},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
