# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v3",
        "display_name": "布林带下轨v3 · 分阶段出场",
        "description": "相对 v2：入场相同，出场改为分阶段止盈 + 保护止损 / 追踪止损。",
        "category": "回归类策略",
        "keywords": ["布林带", "超卖", "保护止损", "追踪止损"],
        "details": {
            "entry": [
                "日线收盘价低于日线布林下轨",
                "周线收盘价低于周线布林下轨",
            ]
        },
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {"bbands": [{"length": 20, "std": 2}]},
        },
        "min_required_records": 100,
        "required": [
            {
                "data_key": "stock.kline.weekly",
                "indicators": {"bbands": [{"length": 20, "std": 2}]},
            }
        ],
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "dynamic_loss": {"close_invest": True, "ratio": -0.1},
        "protect_loss": {"close_invest": True, "ratio": 0},
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {
            "stages": [
                {"actions": ["set_protect_loss"], "exit_ratio": 0.5, "ratio": 0.2},
                {"actions": ["set_dynamic_loss"], "exit_ratio": 0.3, "ratio": 0.3},
            ]
        },
    },
    "portfolio": {
        "allocation": {
            "kelly_fraction": 0.5,
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
