settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v3",
        "display_name": "布林带下轨回归 · v3 分阶段出场",
        "description": "演示策略：入场与 v2 相同（日线 + 周线 BB 下轨），出场改为多阶段止盈，并在盈利后启用 protect_loss（保护止损）与 "
        "dynamic_loss（追踪止损）。演示「抄底信号」与「拿得住 / 卖得掉」可以分开配置。",
        "keywords": [
            "演示",
            "回归",
            "布林带",
            "BB",
            "多周期",
            "protect_loss",
            "dynamic_loss",
        ],
        "details": {
            "entry": [
                "继承 v2：日线下轨 + 周线下轨过滤（data.required: stock.kline.weekly）",
                "出场与 v2 差异：+20% 卖半仓并设置价格跌回买入成本的保护止损",
                "当盈利超过30%平仓30%，然后设置追踪止损 - 最大回撤超过前一日价格的10%就清仓，否则一直不平仓",
                "建议对比：demo/regression/bb/bb_v2_weekly_filter（固定 ±20% 出场）",
            ]
        },
    },
    "core": {},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        },
        "required": [
            {
                "data_key": "stock.kline.weekly",
                "params": {"adjust": "qfq"},
                "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
            }
        ],
        "min_required_records": 100,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {"ratio": 0.2, "exit_ratio": 0.5, "actions": ["set_protect_loss"]},
                {"ratio": 0.3, "exit_ratio": 0.3, "actions": ["set_dynamic_loss"]},
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
        "dynamic_loss": {"ratio": -0.1, "close_invest": True},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
