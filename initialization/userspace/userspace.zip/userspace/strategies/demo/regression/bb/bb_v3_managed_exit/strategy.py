#!/usr/bin/env python3
"""布林带下轨回归演示策略 v3：与 v2 相同入场；分阶段出场见 settings.goal。"""

from __future__ import annotations

from typing import Any, Dict

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


def _bb_field(params: Dict[str, Any], band: str) -> str:
    suffix = {"lower": "BBL", "middle": "BBM", "upper": "BBU"}[band]
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    return f"bbands_{suffix}_{length}_{std}{length}".lower()


class BbManagedExitStrategy(StrategyHooks):
    """日线+周线跌破下轨入场；protect/dynamic 出场由 goal 配置驱动。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        settings = ctx.effective_settings_dict()
        params = settings["data"]["base"]["indicators"]["bbands"][0]
        lower_key = _bb_field(params, "lower")

        daily = records.latest
        close = float(daily["close"])
        lower = float(daily[lower_key])
        if close >= lower:
            return False

        weekly = records.series("stock.kline.weekly").latest
        weekly_close = float(weekly["close"])
        weekly_lower = float(weekly[lower_key])
        if weekly_close >= weekly_lower:
            return False
        return True
