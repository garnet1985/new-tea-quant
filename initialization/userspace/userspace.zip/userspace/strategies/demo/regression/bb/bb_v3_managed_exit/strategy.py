#!/usr/bin/env python3
"""布林带下轨回归演示策略 v3：v2 入场 + protect/dynamic 分阶段出场。"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    StrategyHooks,
)

_BB_PKG = Path(__file__).resolve().parents[1]
if str(_BB_PKG) not in sys.path:
    sys.path.insert(0, str(_BB_PKG))

from bb_indicators import (  # noqa: E402
    WEEKLY_KLINE_SLOT,
    bbands_params,
    has_kline_warmup,
    is_close_below_lower_band,
)

logger = logging.getLogger(__name__)


class BbManagedExitStrategy(StrategyHooks):
    """与 v2 相同的多周期 BB 入场；出场由 settings.goal 的 protect/dynamic 配置驱动。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        base_data_key = ctx.base_data_key
        record_of_today = self.get_record_of_today(data, base_data_key=base_data_key)
        if record_of_today is None:
            return False

        params = bbands_params(settings)
        klines = data.get(base_data_key) or []
        if not has_kline_warmup(klines, settings):
            return False
        if not is_close_below_lower_band(record_of_today, params):
            return False

        weekly_rows = data.get(WEEKLY_KLINE_SLOT) or []
        if not has_kline_warmup(weekly_rows, settings):
            return False

        weekly_last = weekly_rows[-1]
        if not is_close_below_lower_band(weekly_last, params):
            return False
        return True
