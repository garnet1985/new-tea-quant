# 归因示例（bb_v4）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 止盈走自定义钩子，这里只对照单段止损。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "stop_loss": {"values": [-0.15, -0.2, -0.25]},
    },
    "cross": False,
}
