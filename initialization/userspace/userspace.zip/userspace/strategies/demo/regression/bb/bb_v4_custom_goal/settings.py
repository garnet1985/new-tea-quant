# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v4",
        "display_name": "布林带下轨v4 · 自定义出场",
        "description": "相对 v2：入场相同，出场改为自定义（中轨激活保护止损、上轨清仓），演示 is_take_profit。",
        "category": "回归类策略",
        "keywords": ["布林带", "超卖", "custom goal"],
        "details": {
            "entry": [
                "日线收盘价低于日线布林下轨",
                "周线收盘价低于周线布林下轨",
            ]
        },
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        },
        "required": [
            {
                "data_key": "stock.kline.weekly",
                "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
            }
        ],
        "min_required_records": 100,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {
                    "custom": "bb_middle",
                    "description": "日内最高价触及布林中轨",
                    "exit_ratio": 0,
                    "actions": ["set_protect_loss"],
                },
                {
                    "custom": "bb_upper",
                    "description": "日内最高价越过布林上轨",
                    "close_invest": True,
                },
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
}
