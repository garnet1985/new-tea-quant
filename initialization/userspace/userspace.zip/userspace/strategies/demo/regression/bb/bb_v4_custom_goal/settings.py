settings = {
    "is_enabled": True,
    "meta": {
        "key": "bb_v4",
        "display_name": "布林带下轨v4 · custom 出场",
        "description": "布林带超卖策略：多周期 K 线同时落入下轨下方入场；触及中轨后激活保护止损，越过上轨清仓。演示 goal.custom + StrategyHooks.is_take_profit。",
        "category": "回归类策略",
        "keywords": ["布林带", "超卖", "custom goal", "保护止损"],
        "details": {
            "entry": [
                "日线收盘价低于布林带下轨触发买入信号",
                "周线收盘价低于周线布林带下轨触发买入信号",
            ],
            "exit": [
                "custom bb_middle：日内 high 触及中轨 → 激活 protect_loss（exit_ratio=0，不操作仓位）",
                "custom bb_upper：日内 high 越过上轨 → close_invest 清仓",
                "protect_loss：价格跌回买入成本时清剩余仓位",
                "固定止损 -20%",
            ],
        },
    },
    "core": {},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        },
        "required": [
            {
                "data_key": "stock.kline.weekly",
                "params": {"adjust": "qfq"},
                "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
            }
        ],
        "min_required_records": 100,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {
                    "custom": "bb_middle",
                    "exit_ratio": 0,
                    "actions": ["set_protect_loss"],
                },
                {
                    "custom": "bb_upper", 
                    "close_invest": True,
                }
            ]
        },
        "protect_loss": {"ratio": 0, "close_invest": True},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
    "analysis": {"enabled": True},
}
