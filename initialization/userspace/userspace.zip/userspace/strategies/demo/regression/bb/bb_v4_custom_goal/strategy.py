#!/usr/bin/env python3
"""布林带下轨回归演示策略 v4：与 v2 相同入场；custom goal 出场。"""

from __future__ import annotations

from typing import Any, Dict

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


def _bb_field(params: Dict[str, Any], band: str) -> str:
    suffix = {"lower": "BBL", "middle": "BBM", "upper": "BBU"}[band]
    length = int(params["length"])
    std = float(params.get("std", 2.0))
    return f"bbands_{suffix}_{length}_{std}{length}".lower()


class BbCustomGoalStrategy(StrategyHooks):
    """日线+周线跌破下轨入场；中轨/上轨 custom 止盈由本类 is_take_profit 判定。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        params = settings["data"]["base"]["indicators"]["bbands"][0]
        lower_key = _bb_field(params, "lower")

        daily = ctx.record_of_today
        close = float(daily["close"])
        lower = float(daily[lower_key])
        if close >= lower:
            return False

        weekly = ctx.data.items["stock.kline.weekly"][-1]
        weekly_close = float(weekly["close"])
        weekly_lower = float(weekly[lower_key])
        if weekly_close >= weekly_lower:
            return False

        ctx.capture("close", close)
        ctx.capture("bb_lower", lower)
        ctx.capture("weekly_close", weekly_close)
        ctx.capture("weekly_bb_lower", weekly_lower)
        ctx.capture("bb_length", int(params["length"]))
        ctx.capture("bb_std", float(params.get("std", 2.0)))
        return True

    def is_take_profit(self, ctx: StrategyContext, *, custom: str, stage: Any) -> bool:
        _ = stage
        bar = ctx.data.items["bar"]
        params = ctx.effective_settings_dict()["data"]["base"]["indicators"]["bbands"][0]
        high = float(bar["high"])
        key = str(custom).strip().lower()
        if key == "bb_middle":
            return high >= float(bar[_bb_field(params, "middle")])
        if key == "bb_upper":
            return high >= float(bar[_bb_field(params, "upper")])
        return False
