# 归因战役配置（rsi_v1 实验）。不进指纹；Workbench 保存 settings 时不要改这份文件。
# 顶层 inputs = 共用「如果」轴；rolling.windows 只动区间。
# CLI sea/spa/soa 决定补产物深度，不另起副本。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [20, 25, 30]},
        "stop_loss": {
            "values": [
                {"stages": [{"close_invest": True, "ratio": -0.15}]},
                {"stages": [{"close_invest": True, "ratio": -0.2}]},
                {"stages": [{"close_invest": True, "ratio": -0.25}]},
            ],
        },
    },
    "cross": False,
    # TODO: 滚动验证的产品口径还没定，先不要当已完成功能。
    "rolling": {
        "windows": [
            {"start": "20230101", "end": "20260101"},
            {"start": "20230101", "end": "20231231"},
            {"start": "20240101", "end": "20241231"},
            {"start": "20250101", "end": "20251231"},
        ],
    },
}
