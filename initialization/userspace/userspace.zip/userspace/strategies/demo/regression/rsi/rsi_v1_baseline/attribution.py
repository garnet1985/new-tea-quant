# 归因示例（rsi_v1）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照超卖线和止损。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [15, 20, 25]},
        "stop_loss": {"values": [-0.15, -0.2, -0.25]},
    },
    "cross": False,
}
