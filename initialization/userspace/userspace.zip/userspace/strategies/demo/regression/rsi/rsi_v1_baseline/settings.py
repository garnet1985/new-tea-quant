# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v1",
        "display_name": "RSI超跌反弹v1 · 作为对比基准的版本",
        "description": "基线：仅用 RSI(14) 超卖入场，无基本面过滤。",
        "category": "回归类策略",
        "keywords": ["RSI", "超跌"],
        "details": {"entry": ["RSI(14) 低于 20 则买入"]},
        "is_enabled": True,
    },
    "analysis": {"enabled": True},
    "core": {"rsi_oversold_threshold": 20},
    "data": {
        "base": {"data_key": "stock.kline.daily", "indicators": {"rsi": [{"length": 14}]}},
        "min_required_records": 30,
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {
            "stages": [{"exit_ratio": 0.3, "ratio": 0.15}, {"close_invest": True, "ratio": 0.25}]
        },
    },
    "portfolio": {
        "allocation": {
            "max_portfolio_size": 10,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
