#!/usr/bin/env python3
"""RSI 超卖演示策略 v1 · 基线。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    StrategyHooks,
)

logger = logging.getLogger(__name__)


class RsiBaselineStrategy(StrategyHooks):
    """当 RSI(14) 低于 ``core.rsi_oversold_threshold`` 时产生买入信号。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        base_data_key = ctx.base_data_key
        record_of_today = self.get_record_of_today(data, base_data_key=base_data_key)
        if record_of_today is None or not self._has_rsi_warmup(
            data, settings, base_data_key=base_data_key
        ):
            return False

        rsi_value = self._rsi_value(record_of_today, settings)
        if rsi_value is None:
            return False
        threshold = self._rsi_oversold_threshold(settings)
        if rsi_value >= threshold:
            return False

        ctx.capture("rsi", rsi_value)
        ctx.capture("rsi_length", self._rsi_length(settings))
        ctx.capture("rsi_oversold_threshold", threshold)
        return True

    @staticmethod
    def _rsi_length(settings: Dict[str, Any]) -> int:
        return int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])

    def _has_rsi_warmup(
        self, data: Dict[str, Any], settings: Dict[str, Any], *, base_data_key: str
    ) -> bool:
        klines = data.get(base_data_key) or []
        return len(klines) >= self._rsi_length(settings)

    def _rsi_value(
        self, record_of_today: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[float]:
        raw = record_of_today.get(f"rsi{self._rsi_length(settings)}")
        if raw is None:
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _rsi_oversold_threshold(settings: Dict[str, Any]) -> float:
        return float(settings["core"]["rsi_oversold_threshold"])
