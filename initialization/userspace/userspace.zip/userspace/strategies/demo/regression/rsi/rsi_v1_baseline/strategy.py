#!/usr/bin/env python3
"""RSI 超卖演示策略 v1 · 基线。"""

from __future__ import annotations

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


class RsiBaselineStrategy(StrategyHooks):
    """RSI(14) 低于 ``core.rsi_oversold_threshold`` 时买入。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(settings["core"]["rsi_oversold_threshold"])
        rsi = float(ctx.record_of_today[f"rsi{length}"])
        if rsi >= threshold:
            return False
        ctx.capture("rsi", rsi)
        ctx.capture("rsi_length", length)
        ctx.capture("rsi_oversold_threshold", threshold)
        return True
