settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v1",
        "display_name": "RSI超跌反弹v1",
        "description": "日线超卖反弹演示策略：RSI(14) 低于阈值时产生买入信号，配合固定止盈止损与持仓期限退出。",
        "keywords": ["超卖", "技术面", "RSI"],
        "details": {
            "entry": ["RSI(14) 低于超卖阈值（见 core.rsi_oversold_threshold，默认 20）"]
        },
    },
    "core": {"rsi_oversold_threshold": 20},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [],
        "min_required_records": 30,
    },
    "goal": {
        "expiration": {"fixed_window_in_days": 30, "mode": "trading_day"},
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {
            "stages": [
                {"ratio": 0.2, "exit_ratio": 0.5},
                {"ratio": 0.3, "close_invest": True},
            ]
        },
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "initial_capital": 1000000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
