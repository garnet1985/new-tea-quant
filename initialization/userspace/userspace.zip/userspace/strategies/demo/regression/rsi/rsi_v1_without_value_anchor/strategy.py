#!/usr/bin/env python3
"""Example Strategy — RSI 超卖演示策略。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    Opportunity,
    StrategyHooks,
)

logger = logging.getLogger(__name__)


class ExampleStrategy(StrategyHooks):
    """当 RSI(14) 低于 ``core.rsi_oversold_threshold`` 时产生买入信号。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def scan_opportunity(self, ctx: StrategyContext) -> Optional[Opportunity]:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        base_data_key = ctx.base_data_key
        record_of_today = self.get_record_of_today(data, base_data_key=base_data_key)
        if record_of_today is None or not self._has_rsi_warmup(
            data, settings, base_data_key=base_data_key
        ):
            return None

        rsi_value = self._rsi_value(record_of_today, settings)
        if rsi_value is None or not self._is_oversold(rsi_value, settings):
            return None

        return self.build_opportunity(
            ctx,
            record_of_today,
            extra_fields={"rsi_value": rsi_value},
        )

    def _has_rsi_warmup(
        self, data: Dict[str, Any], settings: Dict[str, Any], *, base_data_key: str
    ) -> bool:
        rsi_length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        klines = data.get(base_data_key) or []
        return len(klines) >= rsi_length

    def _rsi_value(
        self, record_of_today: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[float]:
        rsi_length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        return record_of_today.get(f"rsi{rsi_length}")

    def _is_oversold(self, rsi_value: float, settings: Dict[str, Any]) -> bool:
        threshold = float(settings["core"]["rsi_oversold_threshold"])
        return rsi_value < threshold
