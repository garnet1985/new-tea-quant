settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v2",
        "display_name": "RSI超跌反弹v2 · 财报准入",
        "description": "演示策略：RSI(14) "
        "超卖触发买入，并要求最新已披露季度净利润同比不低于阈值。演示意义：技术信号负责「何时看」，基本面负责「能不能买」——避免在盈利恶化的下跌里接飞刀。",
        "keywords": ["演示", "回归", "RSI", "财报", "基本面"],
        "details": {
            "entry": [
                "RSI(14) 低于超卖阈值（见 core.rsi_oversold_threshold，默认 20）",
                "最新已披露季度 netprofit_yoy ≥ core.min_netprofit_yoy（默认 0，即不同比下滑）",
                "财报 PIT 由 stock.finance.quarterly 的 ann_date 时间轴 + DataCursor "
                "切片保证",
            ]
        },
    },
    "core": {"rsi_oversold_threshold": 20, "min_netprofit_yoy": 0.0},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [{"data_key": "stock.finance.quarterly", "params": {}}],
        "min_required_records": 30,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
