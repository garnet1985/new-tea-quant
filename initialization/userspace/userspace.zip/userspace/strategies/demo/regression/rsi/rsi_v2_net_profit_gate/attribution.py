# 归因示例（rsi_v2）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照超卖线和净利润同比门槛。先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [15, 20, 25]},
        "min_netprofit_yoy": {"values": [0, 0.1, 0.2]},
    },
    "cross": False,
}
