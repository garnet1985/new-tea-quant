# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v2",
        "display_name": "RSI超跌反弹v2 · 净利润同比门槛",
        "description": "相对 v1：在 RSI 超卖之外，要求最新已披露季度净利润同比不低于阈值，过滤盈利恶化的接刀。",
        "category": "回归类策略",
        "keywords": ["RSI", "超卖", "净利润"],
        "details": {"entry": ["RSI(14) 低于 20", "最新已披露季度净利润同比 ≥ 同比阈值（默认是0）"]},
        "is_enabled": True,
    },
    "core": {"min_netprofit_yoy": 0, "rsi_oversold_threshold": 20},
    "data": {
        "base": {"data_key": "stock.kline.daily", "indicators": {"rsi": [{"length": 14}]}},
        "min_required_records": 30,
        "required": [{"data_key": "stock.finance.quarterly"}],
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {"stages": [{"close_invest": True, "ratio": 0.2}]},
    },
    "portfolio": {
        "allocation": {
            "kelly_fraction": 0.5,
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {"max_cache_days": 10, "use_strict_previous_trading_day": False, "watch_list": ""},
    "simulation": {
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
    },
}
