settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v2",
        "display_name": "RSI超跌反弹v2 · 不偏离估值",
        "description": "回归类策略：RSI(14) 指标低于20时买入，要求最新已披露季度净利润同比不低于阈值。预期结果：在盈利恶化的下跌里接飞刀。",
        "category": "回归类策略",
        "keywords": ["RSI", "超卖"],
        "details": {
            "entry": [
                "RSI(14) 指标低于20",
                "净盈利指标在正常范围内（默认0，即不要求同比下滑）",
                "止损20%，止盈20%，持满30天退出",
            ]
        },
    },
    "core": {"rsi_oversold_threshold": 20, "min_netprofit_yoy": 0.0},
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [{"data_key": "stock.finance.quarterly", "params": {}}],
        "min_required_records": 30,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
