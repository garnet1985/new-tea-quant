#!/usr/bin/env python3
"""RSI 超卖 + 净利润同比门槛 · v2。"""

from __future__ import annotations

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


class RsiFundamentalGateStrategy(StrategyHooks):
    """RSI 超卖，且最新已披露季度净利同比不低于阈值。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        core = settings["core"]
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(core["rsi_oversold_threshold"])

        rsi = float(ctx.record_of_today[f"rsi{length}"])
        if rsi >= threshold:
            return False

        min_yoy = core.get("min_netprofit_yoy")
        if min_yoy is None:
            return True

        finance_rows = list(ctx.data.items.get("stock.finance.quarterly") or [])
        if not finance_rows:
            return False
        yoy_raw = finance_rows[-1].get("netprofit_yoy")
        if yoy_raw is None:
            return False
        if float(yoy_raw) < float(min_yoy):
            return False
        return True
