#!/usr/bin/env python3
"""RSI 超卖 + 净利润同比门槛 · v2。"""

from __future__ import annotations

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


class RsiFundamentalGateStrategy(StrategyHooks):
    """RSI 超卖，且最新已披露季度净利同比不低于阈值。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        core = settings["core"]
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(core["rsi_oversold_threshold"])
        min_yoy = float(core["min_netprofit_yoy"])

        rsi = float(ctx.record_of_today[f"rsi{length}"])
        if rsi >= threshold:
            return False

        finance = ctx.data.items["stock.finance.quarterly"][-1]
        yoy = float(finance["netprofit_yoy"])
        if yoy < min_yoy:
            return False

        ctx.capture("rsi", rsi)
        ctx.capture("rsi_length", length)
        ctx.capture("rsi_oversold_threshold", threshold)
        ctx.capture("netprofit_yoy", yoy)
        ctx.capture("min_netprofit_yoy", min_yoy)
        return True
