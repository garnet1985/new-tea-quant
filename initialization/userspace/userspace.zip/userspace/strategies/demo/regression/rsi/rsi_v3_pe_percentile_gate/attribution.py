# 归因示例（rsi_v3）。不进回测指纹；工作台保存 settings.py 时不要改这份文件。
# 对照超卖线，以及关掉 / 收紧 PE 分位门槛（None 表示不设上限）。
# 先跑完对应回测，再跑 sea / spa / soa。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [15, 20, 25]},
        "max_pe_percentile": {"values": [None, 20, 30]},
    },
    "cross": False,
}
