# 归因战役（rsi_v3）。不进指纹；Workbench 保存 settings 时不要改这份文件。
# 顶层 inputs = 枚举 / 价格共用的「如果」轴。
# allocation 只属于组合层：锚定当前 version，只改资金分配和选仓。

attribution = {
    "inputs": {
        "rsi_oversold_threshold": {"values": [20, 25, 30, 35]},
        "max_pe_percentile": {"values": [None, 20, 30]},
        "stop_loss": {"values": [-0.10, -0.15, -0.20, -0.25]},
        "take_profit": {"values": [0.10, 0.15, 0.20, 0.25]},
        "opportunity_merge_gap": {"values": [0, 1, 3]},
    },
    "allocation": {
        "mode": {"values": ["equal_shares", "equal_capital", "kelly"]},
        "max_portfolio_size": {"values": [5, 10, 15, 20]},
        "initial_capital": {"values": [10000, 20000, 50000, 100000]},
        "opportunity_selection": {
            "values": [
                [{"rsi": "ASC"}, {"pe_percentile": "ASC"}],
                [],
                [{"rsi": -70}, {"pe_percentile": -30}],
            ]
        },
    },
    # 可选：仅这两轴笛卡尔，其余仍单因素；勿开全轴 cross
    "joint_sweep": [["stop_loss", "take_profit"]],
    "cross": False,
    # TODO: 滚动验证的产品口径还没定，先不要当已完成功能。
    "rolling": {
        "windows": [
            {"start": "20230101", "end": "20260101"},
            {"start": "20230101", "end": "20231231"},
            {"start": "20240101", "end": "20241231"},
            {"start": "20250101", "end": "20251231"},
        ],
    },
}
