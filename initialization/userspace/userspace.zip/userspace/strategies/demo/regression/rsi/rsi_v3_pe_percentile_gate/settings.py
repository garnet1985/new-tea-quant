settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v3",
        "display_name": "RSI超跌反弹v3 · 财报 + PE分位",
        "description": "演示策略：在 v2（RSI 超卖 + 财报准入）基础上，要求 PE "
        "处于自身历史较低分位。演示意义：超卖可能是便宜，也可能是价值陷阱前的下跌——用相对估值过滤「跌完仍偏贵」。",
        "keywords": ["演示", "回归", "RSI", "财报", "PE", "估值"],
        "details": {
            "entry": [
                "继承 v2：RSI(14) 超卖 + 最新披露季度 netprofit_yoy ≥ 0",
                "PE 历史分位 ≤ core.max_pe_percentile（默认 30，即比约 70% 历史更便宜）",
                "分位基于 stock.indicators.daily 的 core.pe_metric（默认 pe_ttm）与 "
                "DataCursor 日频前缀",
            ]
        },
    },
    "core": {
        "rsi_oversold_threshold": 20,
        "min_netprofit_yoy": 0.0,
        "max_pe_percentile": 30.0,
        "pe_metric": "pe_ttm",
        "min_pe_history_days": 60,
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [
            {"data_key": "stock.finance.quarterly", "params": {}},
            {"data_key": "stock.indicators.daily", "params": {}},
        ],
        "min_required_records": 60,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
