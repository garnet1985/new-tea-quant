# Restored / persisted by Strategy Workbench into userspace settings.py.
# Manual edits are allowed; next save from Workbench may reformat this file.

settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v3",
        "display_name": "RSI超跌反弹v3 · PE历史分位",
        "description": "日线超卖反弹演示策略：RSI(14) "
        "低于阈值时产生买入信号，配合固定止盈止损与持仓期限退出。演示意义：超卖可能是便宜，也可能是价值陷阱前的下跌——用相对估值过滤「跌完仍偏贵」",
        "category": "回归类策略",
        "keywords": ["RSI", "超卖"],
        "details": {
            "entry": [
                "RSI(14) 指标低于20",
                "净盈利指标在正常范围内（默认0，即不要求同比下滑）PE历史分位低于30%阈值",
                "止损20%，止盈20%，持满30天退出",
            ]
        },
        "is_enabled": True,
    },
    "analysis": {"enabled": True},
    "core": {
        "max_pe_percentile": 30,
        "min_netprofit_yoy": 0,
        "min_pe_history_days": 60,
        "pe_metric": "pe_ttm",
        "rsi_oversold_threshold": 20,
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "indicators": {"rsi": [{"length": 14}]},
            "params": {"adjust": "qfq"},
        },
        "min_required_records": 60,
        "required": [
            {"data_key": "stock.finance.quarterly", "params": {}},
            {"data_key": "stock.indicators.daily", "params": {}},
        ],
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0,
    },
    "goal": {
        "stop_loss": {"stages": [{"close_invest": True, "ratio": -0.2}]},
        "take_profit": {"stages": [{"close_invest": True, "ratio": 0.2}]},
    },
    "portfolio": {
        "allocation": {
            "kelly_fraction": 0.5,
            "lots_per_trade": 1,
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "mode": "equal_capital",
            "skip_trade_when_insufficient": True,
        },
        "base_version": "latest",
        "initial_capital": 100000,
        "output": {"save_equity_curve": True, "save_trades": True},
    },
    "scanner": {
        "adapters": ["console"],
        "max_cache_days": 10,
        "use_strict_previous_trading_day": False,
        "watch_list": "",
    },
    "simulation": {
        "execution": {"end_date": "", "mode": "entity_based", "start_date": ""},
        "assumption": {
            "template": "custom",
            "tradability": {
                "delisted_exit_price": "last_tradable_close",
                "edges": {
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                    "no_next_tick": "skip_trade",
                },
                "enter_price": "next_open",
                "exit_price": "close",
                "liquidity": {"max_participation_rate": 0.1, "participation_on_exceed": "clip"},
                "monitor_price": "close",
                "slippage": {"enter_bps": 5, "exit_bps": 5},
            },
        },
    },
}
