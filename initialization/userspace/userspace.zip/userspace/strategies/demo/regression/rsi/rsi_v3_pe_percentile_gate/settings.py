settings = {
    "is_enabled": True,
    "meta": {
        "key": "rsi_v3",
        "display_name": "RSI超跌反弹v3 · PE历史分位",
        "description": "日线超卖反弹演示策略：RSI(14) 低于阈值时产生买入信号，配合固定止盈止损与持仓期限退出。演示意义：超卖可能是便宜，也可能是价值陷阱前的下跌——用相对估值过滤「跌完仍偏贵」",
        "category": "回归类策略",
        "keywords": ["RSI", "超卖"],
        "details": {
            "entry": [
                "RSI(14) 指标低于20", 
                "净盈利指标在正常范围内（默认0，即不要求同比下滑）"
                "PE历史分位低于30%阈值", 
                "止损20%，止盈20%，持满30天退出"
            ]
        },
    },
    "core": {
        "rsi_oversold_threshold": 20,
        "min_netprofit_yoy": 0.0,
        "max_pe_percentile": 30.0,
        "pe_metric": "pe_ttm",
        "min_pe_history_days": 60,
    },
    "data": {
        "base": {
            "data_key": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {"rsi": [{"length": 14}]},
        },
        "required": [
            {"data_key": "stock.finance.quarterly", "params": {}},
            {"data_key": "stock.indicators.daily", "params": {}},
        ],
        "min_required_records": 60,
    },
    "goal": {
        "stop_loss": {"stages": [{"ratio": -0.2, "close_invest": True}]},
        "take_profit": {"stages": [{"ratio": 0.2, "close_invest": True}]},
    },
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },
    "simulation": {
        "execution": {"start_date": "", "end_date": "", "mode": "entity_based"},
        "assumption": {
            "template": "custom",
            "tradability": {
                "monitor_price": "close",
                "enter_price": "next_open",
                "exit_price": "close",
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",
                    "allow_enter_at_limit_up": False,
                    "allow_exit_at_limit_down": False,
                },
                "liquidity": {
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",
                },
                "delisted_exit_price": "last_tradable_close",
            },
        },
    },
    "portfolio": {
        "base_version": "latest",
        "initial_capital": 100000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {"save_trades": True, "save_equity_curve": True},
    },
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
