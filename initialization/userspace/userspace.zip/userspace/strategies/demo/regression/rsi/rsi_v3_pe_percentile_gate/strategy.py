#!/usr/bin/env python3
"""RSI 超卖 + 净利同比 + PE 历史分位 · v3。"""

from __future__ import annotations

from typing import List, Tuple

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


def _pe_percentile(rows: List[dict], metric: str, min_history_days: int) -> Tuple[float, float]:
    values: List[float] = []
    for row in rows:
        raw = row.get(metric)
        if raw is None:
            continue
        value = float(raw)
        if value > 0:
            values.append(value)
    if len(values) < min_history_days:
        raise ValueError("pe history too short")
    current = values[-1]
    rank = sum(1 for value in values if value <= current)
    return current, 100.0 * rank / len(values)


class RsiPePercentileGateStrategy(StrategyHooks):
    """相对 v2：再加 PE 历史分位上限过滤。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        core = settings["core"]
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(core["rsi_oversold_threshold"])
        min_yoy = float(core["min_netprofit_yoy"])
        pe_metric = str(core["pe_metric"])
        min_pe_days = int(core["min_pe_history_days"])
        max_pe_pct = float(core["max_pe_percentile"])

        rsi = float(ctx.record_of_today[f"rsi{length}"])
        if rsi >= threshold:
            return False

        finance = ctx.data.items["stock.finance.quarterly"][-1]
        yoy = float(finance["netprofit_yoy"])
        if yoy < min_yoy:
            return False

        try:
            pe, pe_pct = _pe_percentile(
                list(ctx.data.items["stock.indicators.daily"]),
                pe_metric,
                min_pe_days,
            )
        except (KeyError, TypeError, ValueError):
            return False
        if pe_pct > max_pe_pct:
            return False

        ctx.capture("rsi", rsi)
        ctx.capture("netprofit_yoy", yoy)
        ctx.capture("pe", pe)
        ctx.capture("pe_percentile", pe_pct)
        return True
