#!/usr/bin/env python3
"""RSI 超卖 + 净利同比 + PE 历史分位 · v3。"""

from __future__ import annotations

from typing import List, Tuple

from core.modules.strategy.contracts import StrategyContext, StrategyHooks


def _pe_percentile(rows: List[dict], metric: str, min_history_days: int) -> Tuple[float, float]:
    values: List[float] = []
    for row in rows:
        raw = row.get(metric)
        if raw is None:
            continue
        value = float(raw)
        if value > 0:
            values.append(value)
    if len(values) < min_history_days:
        raise ValueError("pe history too short")
    current = values[-1]
    rank = sum(1 for value in values if value <= current)
    return current, 100.0 * rank / len(values)


class RsiPePercentileGateStrategy(StrategyHooks):
    """相对 v2：再加 PE 历史分位上限过滤。"""

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        core = settings["core"]
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(core["rsi_oversold_threshold"])
        pe_metric = str(core["pe_metric"])
        min_pe_days = int(core["min_pe_history_days"])

        rsi = float(ctx.record_of_today[f"rsi{length}"])
        if rsi >= threshold:
            return False
        ctx.capture("rsi", rsi)

        min_yoy = core.get("min_netprofit_yoy")
        if min_yoy is not None:
            finance_rows = list(ctx.data.items.get("stock.finance.quarterly") or [])
            if not finance_rows:
                return False
            yoy_raw = finance_rows[-1].get("netprofit_yoy")
            if yoy_raw is None:
                return False
            if float(yoy_raw) < float(min_yoy):
                return False

        max_pe_pct = core.get("max_pe_percentile")
        if max_pe_pct is not None:
            try:
                pe, pe_pct = _pe_percentile(
                    list(ctx.data.items["stock.indicators.daily"]),
                    pe_metric,
                    min_pe_days,
                )
            except (KeyError, TypeError, ValueError):
                return False
            if pe_pct > float(max_pe_pct):
                return False
            ctx.capture("pe_percentile", pe_pct)
        return True
