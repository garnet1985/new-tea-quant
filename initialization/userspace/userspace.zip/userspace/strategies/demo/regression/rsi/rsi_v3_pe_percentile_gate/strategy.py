#!/usr/bin/env python3
"""RSI 超卖 + 财报准入 + PE 历史分位演示策略 v3。"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from core.modules.data_contract.contracts import DATA_KEY
from core.modules.strategy.contracts import (
    CalendarAsOfResult,
    StrategyContext,
    StrategyHooks,
)

logger = logging.getLogger(__name__)

_FINANCE_SLOT = DATA_KEY.STOCK_FINANCE_QUARTERLY
_INDICATORS_SLOT = DATA_KEY.STOCK_INDICATORS_DAILY


def pe_percentile_from_rows(
    rows: List[Dict[str, Any]],
    metric: str,
    *,
    min_history_days: int,
) -> Optional[Tuple[float, float]]:
    """
    基于 cursor 日频前缀计算 PE 经验分位（0–100）。

    仅统计 ``metric`` > 0 的样本；样本数不足 ``min_history_days`` 时返回 None。
    """
    values: List[float] = []
    for row in rows:
        raw = row.get(metric)
        if raw is None:
            continue
        try:
            value = float(raw)
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        values.append(value)

    if len(values) < max(1, int(min_history_days)):
        return None

    current = values[-1]
    rank = sum(1 for value in values if value <= current)
    percentile = 100.0 * rank / len(values)
    return current, percentile


class RsiPePercentileGateStrategy(StrategyHooks):
    """v2 逻辑 + ``stock.indicators.daily`` PE 历史分位过滤。"""

    def on_calendar_asof(self, ctx: StrategyContext) -> CalendarAsOfResult:
        return super().on_calendar_asof(ctx)

    def has_opportunity(self, ctx: StrategyContext) -> bool:
        settings = ctx.effective_settings_dict()
        data = ctx.data.items_with_meta()
        base_data_key = ctx.base_data_key
        record_of_today = self.get_record_of_today(data, base_data_key=base_data_key)
        if record_of_today is None or not self._has_rsi_warmup(
            data, settings, base_data_key=base_data_key
        ):
            return False

        rsi_value = self._rsi_value(record_of_today, settings)
        if rsi_value is None or not self._is_oversold(rsi_value, settings):
            return False

        finance_rows = data.get(_FINANCE_SLOT) or []
        if not finance_rows:
            return False
        finance_row = finance_rows[-1]

        netprofit_yoy = finance_row.get("netprofit_yoy")
        if netprofit_yoy is None:
            return False
        try:
            netprofit_yoy_value = float(netprofit_yoy)
        except (TypeError, ValueError):
            return False
        if netprofit_yoy_value < self._min_netprofit_yoy(settings):
            return False

        indicator_rows = data.get(_INDICATORS_SLOT) or []
        pe_stats = pe_percentile_from_rows(
            indicator_rows,
            self._pe_metric(settings),
            min_history_days=self._min_pe_history_days(settings),
        )
        if pe_stats is None:
            return False
        pe_value, pe_percentile = pe_stats
        if pe_percentile > self._max_pe_percentile(settings):
            return False

        ctx.capture("rsi", rsi_value)
        ctx.capture("netprofit_yoy", netprofit_yoy_value)
        ctx.capture("pe", pe_value)
        ctx.capture("pe_percentile", pe_percentile)
        return True

    def _has_rsi_warmup(
        self, data: Dict[str, Any], settings: Dict[str, Any], *, base_data_key: str
    ) -> bool:
        rsi_length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        klines = data.get(base_data_key) or []
        return len(klines) >= rsi_length

    def _rsi_value(
        self, record_of_today: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[float]:
        rsi_length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        raw = record_of_today.get(f"rsi{rsi_length}")
        if raw is None:
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None

    def _is_oversold(self, rsi_value: float, settings: Dict[str, Any]) -> bool:
        threshold = float(settings["core"]["rsi_oversold_threshold"])
        return rsi_value < threshold

    @staticmethod
    def _min_netprofit_yoy(settings: Dict[str, Any]) -> float:
        core = settings.get("core") or {}
        if "min_netprofit_yoy" not in core:
            return 0.0
        return float(core["min_netprofit_yoy"])

    @staticmethod
    def _pe_metric(settings: Dict[str, Any]) -> str:
        core = settings.get("core") or {}
        metric = str(core.get("pe_metric") or "pe_ttm").strip()
        return metric or "pe_ttm"

    @staticmethod
    def _min_pe_history_days(settings: Dict[str, Any]) -> int:
        core = settings.get("core") or {}
        if "min_pe_history_days" not in core:
            return 60
        return max(1, int(core["min_pe_history_days"]))

    @staticmethod
    def _max_pe_percentile(settings: Dict[str, Any]) -> float:
        core = settings.get("core") or {}
        if "max_pe_percentile" not in core:
            return 30.0
        return float(core["max_pe_percentile"])
