#!/usr/bin/env python3
"""滚动对照演示：RSI 超卖。回测只跑 2023，2024–2025 留给滚动窗口。"""

from __future__ import annotations

from core.modules.strategy.contracts import Records, StrategyContext, StrategyHooks


class RollingRsiStrategy(StrategyHooks):
    """RSI(14) 低于 ``core.rsi_oversold_threshold`` 时买入。"""

    def is_opportunity(self, ctx: StrategyContext, records: Records) -> bool:
        settings = ctx.effective_settings_dict()
        length = int(settings["data"]["base"]["indicators"]["rsi"][0]["length"])
        threshold = float(settings["core"]["rsi_oversold_threshold"])
        rsi = float(records.latest[f"rsi{length}"])
        if rsi >= threshold:
            return False
        return True
