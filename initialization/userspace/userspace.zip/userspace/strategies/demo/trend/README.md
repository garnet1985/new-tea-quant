# 趋势 / 热点演示（`demo/trend/`）

## 当前状态：**暂无可用 demo**

原「个股资金流热度」实验线已移除（per-entity 架构下难以做出可靠横截面 demo）。数据表 `stock.moneyflow.daily` 仍可用于您自己的策略；重做 demo 需截面排名或 tag 预计算等能力。

## 将来想说明什么

顺势不一定比猜底简单；趋势策略也会假突破、回撤连亏。重点是 **入场与出场纪律同样重要**。

## 现在可在 UI 里对照什么

- **出场纪律**：打开 [BB v3](../regression/README.md)（展示名含「v3 分阶段出场」），在 **价格回测** 报告里看分阶段出场效果。
- **抄底 vs 顺势**（概念上）：对比 RSI v1 与将来趋势 demo 的三步报告（趋势 demo 就绪后再做）。

扩展规划见 [SW_INDUSTRY_AND_TREND_PLAN.md](../../extensions/data_source/docs/SW_INDUSTRY_AND_TREND_PLAN.md)。

[← 演示总览](../README.md)
