# settings_example.py — 策略配置字段说明（SOT；复制到正式策略目录后按需删减）
#
# 新建策略：复制 _template/empty_strategy/ 到新目录，或复制本文件到 userspace/strategies/<your_path>/settings.py。
#
# 最少建议填写：is_enabled、meta.display_name、core、data.base、goal
# 其余块可整段省略，使用系统默认值。
#
# 策略目录 ID = 相对 userspace/strategies/ 的路径（结果目录、内部引用）。
# CLI / API 请用 meta.key（短 alias），不必复制完整路径：
#   python cli.py se --strategy rsi_v1
#
# 使用 data.required 且引用 DATA_KEY 时，在 strategy.py 顶部：
#   from core.modules.data_contract.contracts import DATA_KEY
#
# 约定摘要：
# - 回测时间窗：simulation.execution.start_date / end_date（enum / price / portfolio 共用）
# - 股票采样：仅配置 sampling；use_sampling=False（默认）时可整段省略
# - 交易费率：仅配置根级 fees（勿在 portfolio 下再写 fees）
# - 成交假设：simulation.assumption（template 短路或显式 tradability）
# - 主观风控：simulation.risk_control（skip_enter_when / force_exit_when；与 assumption 平级）
# - 市场制度：根级 market_profile（省略则 china_a_stock）
# - 命名：enter/exit（不再 buy/sell）；一根 K 线 = 一个 tick
# - st 含 SST，star_st 含 S*ST；枚举写入 metadata.stock_status_at_trigger / CSV 列

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    "is_enabled": True,              # 必填，是否启用（扫描 / 默认发现）

    # 用户可见文档块；系统策略 ID 由目录路径决定，不在此填写 name
    "meta": {
        "key": "my_strategy",         # 必填，全局唯一；CLI --strategy 使用此 alias
        "display_name": "我的策略",   # 必填，UI / 报告展示名
        "description": "策略说明：入场逻辑、适用场景、演示目的等。",  # 强烈建议填写
        "category": "示例",         # 选填，UI 列表归类用；缺省归入「未知归类」
        "keywords": ["关键字1", "关键字2"],         # 选填，标签/检索用
        "details": {                  # 选填，结构化说明（如入场条件条目）
            "entry": [
                "示例：RSI(14) 低于 core.rsi_oversold_threshold 时产生买入信号",
            ],
        },
    },

    # -----------------------------------------------------------------------
    # 2. core — 策略私有参数（strategy.py / StrategyHooks 里读取）
    # -----------------------------------------------------------------------
    "core": {
        "rsi_oversold_threshold": 20,  # 示例：RSI 超卖线，可任意增删键名
        # "momentum_threshold": 0.05,
    },

    # -----------------------------------------------------------------------
    # 3. data — K 线与指标
    # -----------------------------------------------------------------------
    "data": {
        "base": {
            "data_key": "stock.kline.daily",  # 省略时默认 stock.kline.daily
            "params": {
                "adjust": "qfq",     # 选填，默认 qfq；可选 raw | hfq
            },
            # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
            "indicators": {
                # "rsi": [{"length": 14}],
                # "sma": [{"length": 5}, {"length": 20}],
                # "macd": [{"fast": 12, "slow": 26, "signal": 9}],
            },
        },
        # 多周期示例：base 驱动回测主时间轴；required 注入辅助周期（slot = data_key）
        # "required": [
        #     {
        #         "data_key": "stock.kline.weekly",
        #         "params": {"adjust": "qfq"},
        #         "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        #     },
        # ],
        "required": [  # 选填，默认 []；data_key 见 DataKey
            # {"data_key": "macro.gdp", "params": {}},
            # {"data_key": "tag", "params": {"tag_scenario": "activity-ratio20"}},
        ],
        "min_required_records": 100,  # 选填，默认 100；历史 K 线最少条数
    },

    # -----------------------------------------------------------------------
    # 4. sampling — 股票池采样（可整段省略）
    # -----------------------------------------------------------------------
    # use_sampling 默认 False：全市场股票池，可整段省略本块。
    # 仅当需要缩小股票池时再写，例如：
    "sampling": {
        "use_sampling": False,
        # strategy 选填，默认 uniform
        # uniform | stratified | random | continuous | pool | blacklist | weighted
        "strategy": "pool",
        "sampling_amount": 10,       # 选填，默认 10；pool 时对白名单截断
        "pool": {"stock_ids": ["000001.SZ"]},  # 或 {"file": "stock_lists/pool.txt"}
        # "continuous": {"start_idx": 0},
        # "blacklist": {"stock_ids": [], "file": "stock_lists/blacklist.txt"},
        # "random": {"seed": 42},
        # "stratified": {"seed": 42},
    },

    # -----------------------------------------------------------------------
    # 5. goal — 止盈 / 止损 / 到期
    # -----------------------------------------------------------------------
    "goal": {
        "expiration": {
            "fixed_window_in_days": 30,
            # natural_day | trading_day | open_day（与 Investment 持有期计数一致）
            "mode": "open_day",
        },
        "stop_loss": {               # 选填
            "stages": [
                {
                    # 无 name 字段：运行期按 ratio 推断（-0.1→loss10%，-0.2→loss20%）
                    "ratio": -0.1,           # 亏损比例（负数）
                    "close_invest": True,    # True=全平；False 时用 exit_ratio
                    # "exit_ratio": 0.5,     # 0~1，部分平仓比例
                },
            ],
        },
        "take_profit": {             # 选填；多阶段时至少一阶段 close_invest=True 或 exit_ratio 合计为 1
            "stages": [
                {
                    # 无 name 字段：运行期按 ratio 推断（0.1→win10%，0.2→win20%）
                    # （必填）触发阈值：正数表示盈利比例
                    "ratio": 0.1,
                    # （必填）部分平仓比例（0~1）；全平用 close_invest=True
                    # 0.5 代表平掉当前持仓的 50%
                    "exit_ratio": 0.5,
                    # 追加动作（可选）：
                    # - （选填）set_protect_loss: 启用保本线 - 如果价格跌回到本金，按照protect_loss的配置操作
                    # - （选填）set_dynamic_loss: 启用动态止损 - 如果价格跌回到最高点回撤 N%，按照dynamic_loss的配置操作
                    "actions": ["set_protect_loss"],
                },
                {
                    # 无 name：0.2 → win20%
                    "ratio": 0.2,
                    # close_invest=True 表示直接清仓
                    "close_invest": True,
                    "actions": ["set_dynamic_loss"],
                },

            ]
        },

        # （选填）保本止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "protect_loss": {
            "ratio": 0,                   # 回到成本价
            "close_invest": True          # 触发时清仓
        },

        # （选填）动态止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "dynamic_loss": {
            "ratio": -0.1,                # 从最高点回撤 10%
            "close_invest": True          # 触发时清仓
        },
    },

    # =======================================================================
    # 6) 枚举器配置（大多可省略）
    # =======================================================================
    # 调度/性能参数（entities_per_job、memory_budget_mb 等）在 worker.json → job_pipeline.enumerator.dispatch
    "enumerator": {
        # （选填， 默认 False）是否输出更详细调度日志
        "is_verbose": False,
    },

    # =======================================================================
    # 7) 公共交易费率（可省略）
    # =======================================================================
    # （选填）全链路模拟共用费率；勿在其它块下再写 fees 覆盖。
    "fees": {
        "commission_rate": 0.00025,  # （选填，有默认值）佣金率
        "min_commission": 5.0,       # （选填，有默认值）最低佣金
        "stamp_duty_rate": 0.001,    # （选填，有默认值）印花税（卖出）
        "transfer_fee_rate": 0.0,    # （选填，有默认值）过户费
    },

    # =======================================================================
    # 7b) market_profile — 市场制度（可省略，默认 china_a_stock）
    # =======================================================================
    # 根级字符串；决定涨跌幅限制、最小申报单位、交易日历映射等（枚举算涨跌停价、组合手数）。
    # 可选值见 core/modules/market_profile/markets/ 或工作台 market_profile 下拉。
    # "market_profile": "china_a_stock",

    # =======================================================================
    # 8) simulation — execution / assumption / risk_control
    # =======================================================================
    # execution：时间窗 + 调度 mode
    # assumption：成交假设 + check_targets 目标冲突顺序
    # risk_control：主观风控（与 assumption 平级；不决定成交价）
    #
    "simulation": {
        "execution": {
            "start_date": "",            # 选填 YYYYMMDD；空= data.json default_start_date
            "end_date": "",              # 选填 YYYYMMDD；空= latest completed trading date
            "mode": "entity_based",      # entity_based | slice_based
        },

        "assumption": {
            # standard | strict | ideal | extreme → 短路用预设 tradability
            # custom | 省略显式块时用下方 tradability（引擎仍认 none，UI 已不暴露）
            "template": "standard",

            # check_targets 内互斥目标短路顺序（默认：先止损 → 止盈 → 过期）
            # 同 bar 多目标都满足时，先命中者武装出场；不含 settlement（门禁写死）
            "target_check_order": [
                "check_stop_loss",
                "check_take_profit",
                "check_expiration",
            ],

            # template 为 none/custom 时生效；命名预设时会被预设覆盖（可省略本块）
            "tradability": {
                "monitor_price": "close",        # 盯价：tick 字段
                "enter_price": "touch",          # 进场：touch（贴近限价）| next_open（简化）| open | close
                "exit_price": "close",           # 出场成交价
                "slippage": {"enter_bps": 5.0, "exit_bps": 5.0},
                "edges": {
                    "no_next_tick": "skip_trade",          # skip_trade | use_last_close
                    "allow_enter_at_limit_up": False,      # 涨停价是否允许进场
                    "allow_exit_at_limit_down": False,     # 跌停价是否允许出场
                },
                "liquidity": {
                    # 上限股数 ≈ tick.volume × rate；（0, 1]；1 = 不限制
                    "max_participation_rate": 0.1,
                    "participation_on_exceed": "clip",     # clip | skip
                },
                # 退市强平用哪根 tick 定价（模拟假设；退市是否强平见 risk_control / 引擎恒生效）
                "delisted_exit_price": "last_tradable_close",  # | same_tick_close
            },
        },

        "risk_control": {
            # 不进仓：触发日 status 命中 → 跳过 price/portfolio（枚举 CSV 仍保留）
            "skip_enter_when": [],               # e.g. ["st", "star_st"]
            # 持仓强平：与上对称；退市恒生效（勿写入列表）
            "force_exit_when": [],               # e.g. ["st"] 或 [{"status": "st", "close_invest": True}]
            # PENDING_TO_ENTER 挂单风控（仅计交易日；退市恒 abort）
            "pending_enter": {
                "max_wait_open_days": 5,         # 自 trigger 次一开市日起最多等 N 个交易日
                "max_entry_drift": None,         # |候选价-trigger|/trigger；null=关闭；超则 abort
                "abort_enter_when": [],          # 挂起期间 status；e.g. ["st", "star_st"]
            },
        },
    },

    # =======================================================================
    # 9) portfolio — 资金组合配置（大多可省略）
    # =======================================================================
    # 进场：必须有枚举器写好的 entry_date、entry_price_raw（缺一即跳过该机会）。
    # 出场事件：与枚举器 exit / completed targets 一致。
    "portfolio": {
        # （选填， 默认 "latest"）读取枚举产物的版本选择
        "base_version": "latest",

        # （选填， 默认 1_000_000）初始资金
        "initial_capital": 1_000_000,

        # （选填）资金分配参数
        "allocation": {
            # （选填， 默认 "equal_capital"）资金分配模式：
            # - equal_capital：等额资金分配
            # - equal_shares：等额股数分配
            # - kelly：凯利公式分配
            # - custom：自定义分配
            "mode": "equal_capital",
            # （选填， 默认 10）最大持仓数
            "max_portfolio_size": 10,
            # （选填， 默认 0.3）单票最大权重（0~1）
            "max_weight_per_stock": 0.3,
            # （选填， 默认 1）每笔交易手数（手数由 market_profile 决定）
            "lots_per_trade": 1,
            # （选填， 默认 0.5）kelly 模式参数
            "kelly_fraction": 0.5,
        },

        # （选填）输出开关（有默认值）
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # =======================================================================
    # 10) 扫描器配置（可省略）
    # =======================================================================
    "scanner": {
        # （选填， 默认 ["console"]）输出适配器列表
        # 表示如何继续处理用当前策略扫描出的投资机会 - 可以某种方式通知，可以使用第三方服务自动下单，可以进行机器学习等等。
        # 取决于您在 adapter 里扩展了什么，系统默认只自带 console（命令行输出）。其他适配方式需自行扩展
        # 示例：["console"], ["console", "sms", "machine_learning"], ["wechat", "email"]
        "adapters": ["console"],

        # （选填， 默认 True）是否严格按“上一个交易日”进行扫描
        # True=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会拒绝扫描。
        # False=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会扫描2025年6月30日当天的策略产生的机会。
        "use_strict_previous_trading_day": True,
        
        # （选填， 默认 10）扫描缓存天数
        # 保留最近 N 个扫描日期目录，多于这个数量的结果会被自动删除。
        "max_cache_days": 10,

        # （选填， 默认 ""）股票列表文件路径（相对策略目录或绝对路径）；非空时须为存在的文本文件，每行一个股票代码
        # 复制为正式策略后按需填写，例如："stock_lists/watch.txt"
        "watch_list": "",
    },

    # =======================================================================
    # 11) analysis — 回测后自动归因（可省略，默认关闭）
    # =======================================================================
    # 不进指纹。True 时 simulate 在写完 overall 报告后跑 Analyzer，生成 analysis/report.json。
    "analysis": {
        "enabled": True,
    },
}
