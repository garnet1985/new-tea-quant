"""userspace 系统目录：config、db、backup、updater、.ntq。"""
