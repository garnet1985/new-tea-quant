# 备份目录（`userspace/system/backup/`）

承接表备份产物的目录。普通用户一般**不必手改**这里；通过框架备份/恢复能力使用即可。

## 定位

- 跨表备份 / 恢复入口：`DataManager` 的 backup/restore 能力（见 `core/modules/data_manager`）
- 底层依赖各表 model 的 `export_data` / `import_data`
- 产物默认落在本目录下的 `data/`

## 目录结构（示意）

```text
userspace/system/backup/
  README.md
  data/
    {backup_date}/
      all_tables/                 # 全表备份时
      {table}.tar.gz|zip          # 单表备份
      {table}_{start}_{end}.tar.gz|zip
```

## 相关

- 演示数据打包等维护者流程：`python devcli.py -h`（如 `ex` / `pu`）
- 勿将大体积备份提交进 Git
