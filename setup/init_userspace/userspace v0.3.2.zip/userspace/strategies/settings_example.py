# settings_example.py — 策略配置字段说明（复制到正式策略后按需删减）
#
# 最少建议填写：name、core、data.base_required_data、goal
# 其余块可整段省略，使用系统默认值。
#
# 使用 extra_required_data_sources 且引用 DataKey 时，在 settings.py 顶部：
#   from core.modules.data_contract.contract_const import DataKey
#
# 约定摘要：
# - 采样与回测日期：仅配置 sampling（枚举/价格/资金共用）
# - 交易费率：仅配置根级 fees
# - 成交假设：根级 simulation；template 为 deterministic/extreme 时仅写 template（不可覆盖细项）
# - 要改滑点、edges、价模型等须 template: "custom" 并逐项填写（见 Case B）
# - 整段省略 simulation 时等价于 {"template": "deterministic"}（系统预设，偏乐观）

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    "is_enabled": True,              # 必填，是否启用
    "name": "my_strategy",           # 必填，策略唯一名（目录名、日志）
    "description": "My first strategy",  # 必填，说明文字
    "market_profile": "china_a_stock",  # 选填，默认是A股，建议最好声明

    # -----------------------------------------------------------------------
    # 2. core — 策略私有参数（strategy_worker 里读取）
    # -----------------------------------------------------------------------
    "core": {
        "rsi_oversold_threshold": 20,  # 示例：RSI 超卖线，可任意增删键名
        # "momentum_threshold": 0.05,
    },
    # -----------------------------------------------------------------------
    # 3. data — K 线与指标
    # -----------------------------------------------------------------------
    "data": {
        "base_required_data": {
            "params": {
                "term": "daily",     # 选填，默认 daily
                "adjust": "qfq",     # 选填，默认 qfq；可选 raw | hfq
            },
        },
        "extra_required_data_sources": [  # 选填，默认 []；data_id 见 DataKey
            # {"data_id": "macro.gdp", "params": {}},
            # {"data_id": "tag", "params": {"tag_scenario": "my-scenario"}},
        ],
        "min_required_records": 100,  # 选填，默认 100；历史 K 线最少条数

        # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
        "indicators": {
            # "rsi": [{"length": 14}],
            # "sma": [{"length": 5}, {"length": 20}],
            # "macd": [{"fast": 12, "slow": 26, "signal": 9}],
        },
    },

    # -----------------------------------------------------------------------
    # 4. sampling — 股票池与回测区间（三步共用）
    # -----------------------------------------------------------------------
    "sampling": {
        "use_sampling": False,       # 选填，默认 False；True=按下方规则缩小股票池
        "start_date": "",            # 选填，默认 ""；回测开始 YYYYMMDD，空=自动
        "end_date": "",              # 选填，默认 ""；回测结束 YYYYMMDD，空=自动

        # strategy 选填，默认 continuous
        # uniform | stratified | random | continuous | pool | blacklist
        "strategy": "continuous",
        "sampling_amount": 50,       # 选填，默认 10；采样股票数量

        "continuous": {
            "start_idx": 0,          # 选填，默认 0；连续采样起始下标
        },
        # 仅在与 strategy 一致时填写对应子块：
        # "pool": {"stock_ids": ["000001.SZ"], "file": "stock_lists/pool.txt"},
        # "blacklist": {"stock_ids": [], "file": "stock_lists/blacklist.txt"},
        # "random": {"seed": 42},
        # "stratified": {"seed": 42},
    },

    # -----------------------------------------------------------------------
    # 5. goal — 止盈 / 止损 / 到期
    # -----------------------------------------------------------------------
    "goal": {
        "expiration": {              # 选填；不写则只按止盈止损结束
            "fixed_window_in_days": 30,  # 选填，默认 30；最长持仓天数（日历日）
            "is_trading_days": True,     # 选填，默认 True（预留，当前按日历日计）
        },
        "stop_loss": {               # 选填
            "stages": [
                {
                    "name": "loss10%",
                    "ratio": -0.1,           # 亏损比例（负数）
                    "close_invest": True,    # True=全部卖出；False 时用 sell_ratio
                    # "sell_ratio": 0.5,     # 0~1，部分卖出比例
                },
            ],
        },
        "take_profit": {             # 选填；多阶段时至少一阶段 close_invest=True 或 sell_ratio 合计为 1
            "stages": [
                {
                    "name": "win10%",
                    # （必填）触发阈值：正数表示盈利比例
                    "ratio": 0.1,
                    # （必填）部分卖出比例（0~1）
                    # 0.5代表卖出投资总股数的50%
                    "sell_ratio": 0.5,
                    # 追加动作（可选）：
                    # - （选填）set_protect_loss: 启用保本线 - 如果价格跌回到本金，按照protect_loss的配置操作
                    # - （选填）set_dynamic_loss: 启用动态止损 - 如果价格跌回到最高点回撤 N%，按照dynamic_loss的配置操作
                    "actions": ["set_protect_loss"],
                },
                {
                    "name": "win20%",
                    "ratio": 0.2,
                    # close_invest=True 表示直接清仓
                    "close_invest": True,
                    "actions": ["set_dynamic_loss"],
                },

            ]
        },

        # （选填）保本止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "protect_loss": {
            "ratio": 0,                   # 回到成本价
            "close_invest": True          # 触发时清仓
        },

        # （选填）动态止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "dynamic_loss": {
            "ratio": -0.1,                # 从最高点回撤 10%
            "close_invest": True          # 触发时清仓
        },
    },

    # =======================================================================
    # 6) 枚举器配置（大多可省略）
    # =======================================================================
    # 不再包含 use_sampling / max_test_versions（已迁移到 sampling 与统一目录策略）。
    "enumerator": {
        # （选填， 默认 3）枚举产物在磁盘上最多保留的版本个数（实现跟进）
        "max_output_versions": 3,

        # （选填， 默认 "auto"）并发 worker（"auto" 或整数）
        "max_workers": "auto",

        # （选填， 默认 False）是否输出更详细调度日志
        "is_verbose": False,

        # （选填， 默认 "auto"）Memory-aware scheduler 参数（"auto" 或整数）
        "memory_budget_mb": "auto",
        "warmup_batch_size": "auto",
        "min_batch_size": "auto",
        "max_batch_size": "auto",
        "monitor_interval": 5,
    },

    # =======================================================================
    # 7) 公共交易费率（可省略）
    # =======================================================================
    # （选填）全链路模拟共用费率；请勿在 price_simulator / capital_simulator 下再写 fees 覆盖。
    "fees": {
        "commission_rate": 0.00025,  # （选填，有默认值）佣金率
        "min_commission": 5.0,       # （选填，有默认值）最低佣金
        "stamp_duty_rate": 0.001,    # （选填，有默认值）印花税（卖出）
        "transfer_fee_rate": 0.0,    # （选填，有默认值）过户费
    },

    # =======================================================================
    # 8) 回测执行假设 simulation（可省略；枚举器内生效，下游只读枚举产物）
    # =======================================================================
    # --- Case A：预设模板（只写 template，细节由系统固定）---
    # "simulation": {"template": "deterministic"},
    # "simulation": {"template": "extreme"},
    #
    # --- Case B：custom + 偏悲观 A 股成交假设（改细项必须用 custom）---
    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {
            "buy_bps": 5.0,
            "sell_bps": 5.0,
        },
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "extreme_same_bar_order": "stop_first",
    },

    # --- Case C：同日收盘买、收盘卖（无次日 deferred）---
    # "simulation": {
    #     "template": "custom",
    #     "monitor_price_model": "close",
    #     "buy_price_model": "close",
    #     "sell_price_model": "close",
    #     "slippage": {"buy_bps": 5, "sell_bps": 5},
    #     "edges": {"no_next_bar": "skip_trade"},
    # },

    # --- Case D：信号日收盘确认，当日开盘买（需 custom；适用于已确认可当日成交的假设）---
    # "simulation": {
    #     "template": "custom",
    #     "monitor_price_model": "close",
    #     "buy_price_model": "open",
    #     "sell_price_model": "close",
    # },

    # --- Case E：买卖均次日开盘（卖也 next_open，触发后次日 open 平仓）---
    # "simulation": {
    #     "template": "custom",
    #     "monitor_price_model": "close",
    #     "buy_price_model": "next_open",
    #     "sell_price_model": "next_open",
    #     "edges": {"no_next_bar": "use_last_close"},
    # },

    # --- Case F：extreme 预设（仅 template，不可附带 slippage/edges 等）---
    # "simulation": {"template": "extreme"},

    # --- Case G：custom 下只改卖出价模型 ---
    # "simulation": {
    #     "template": "custom",
    #     "monitor_price_model": "close",
    #     "buy_price_model": "next_open",
    #     "sell_price_model": "next_open",
    # },

    # --- Case H：custom — 样本末尾 skip 无法次日成交的信号 ---
    # "simulation": {
    #     "template": "custom",
    #     "monitor_price_model": "close",
    #     "buy_price_model": "next_open",
    #     "sell_price_model": "close",
    #     "edges": {"no_next_bar": "skip_trade"},
    # },

    # =======================================================================
    # 9) 价格因子模拟器配置（大多可省略）
    # =======================================================================
    # 不再包含 use_sampling、start_date/end_date（见 sampling）；费率仅根级 fees。
    # 读取枚举 CSV 的 buy_price、buy_date（必填）、sell_date、completed_targets；缺 buy 字段则跳过该机会。
    "price_simulator": {
        # （选填， 默认 "latest"）读取枚举产物的版本选择
        # 支持："latest" / "1" / "2" ...（目录：userspace/strategies/<策略名>/results/simulations/enum/）
        "base_version": "latest",

        # （选填， 默认 "auto"）并发 worker（"auto" 或整数）
        "max_workers": "auto",
    },

    # =======================================================================
    # 10) 资金分配模拟器配置（大多可省略）
    # =======================================================================
    # 不再包含 use_sampling、start_date/end_date（见 sampling）；费率仅根级 fees。
    # 买入：必须有枚举器写好的 buy_date、buy_price（缺一即跳过该机会，不回退 trigger_*）。
    # 卖出事件：targets 各行 date + price，与枚举器 completed_targets 一致。
    "capital_simulator": {
        # （选填， 默认 "latest"）读取枚举产物的版本选择（含义同 price_simulator.base_version）
        "base_version": "latest",

        # （选填， 默认 "auto"）并发 worker（"auto" 或整数）
        "max_workers": "auto",

        # （选填， 默认 1_000_000）初始资金
        "initial_capital": 1_000_000,

        # （选填）资金分配参数（各字段有默认值，见 StrategyCapitalSimulatorSettings）
        "allocation": {
            # （选填， 默认 "equal_capital"）资金分配模式：
            # - equal_capital：等额资金分配
            # - equal_shares：等额股数分配
            # - kelly：凯利公式分配
            # - custom：自定义分配
            "mode": "equal_capital",
            # （选填， 默认 10）最大持仓数
            "max_portfolio_size": 10,
            # （选填， 默认 0.3）单票最大权重（0~1）
            "max_weight_per_stock": 0.3,
            # （选填， 默认 1）equal_shares 模式：买入手数 = market_profile 最小手数 × lots_per_trade
            "lots_per_trade": 1,
            # （选填， 默认 0.5）kelly 模式参数
            "kelly_fraction": 0.5,
            # （选填， 默认 false）计划仓位资金不足时是否跳过该笔开仓；
            # true = 资金不够整手则不做（偏悲观）；false = 在额度内尽量买满整手
            # 仅认 skip_trade_when_insufficient；已移除 on_insufficient_funds、lot_size
            "skip_trade_when_insufficient": True,
        },

        # （选填）输出开关（有默认值）
        # - save_trades：是否保存逐笔交易日志
        # - save_equity_curve：是否保存每日权益曲线
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # =======================================================================
    # 11) 扫描器配置（可省略）
    # =======================================================================
    "scanner": {
        # （选填， 默认 "auto"）并发 worker（"auto" 或整数）
        "max_workers": "auto",

        # （选填， 默认 ["console"]）输出适配器列表
        # 表示如何继续处理用当前策略扫描出的投资机会 - 可以某种方式通知，可以使用第三方服务自动下单，可以进行机器学习等等。
        # 取决于您在 adapter 里扩展了什么，系统默认只自带 console（命令行输出）。其他适配方式需自行扩展
        # 示例：["console"], ["console", "sms", "machine_learning"], ["wechat", "email"]
        "adapters": ["console"],

        # （选填， 默认 True）是否严格按“上一个交易日”进行扫描
        # True=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会拒绝扫描。
        # False=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会扫描2025年6月30日当天的策略产生的机会。
        "use_strict_previous_trading_day": True,
        
        # （选填， 默认 10）扫描缓存天数
        # 保留最近 N 个扫描日期目录，多于这个数量的结果会被自动删除。
        "max_cache_days": 10,

        # （选填， 默认 ""）股票列表文件路径（相对策略目录或绝对路径）；非空时须为存在的文本文件，每行一个股票代码
        # 复制为正式策略后按需填写，例如："stock_lists/watch.txt"
        "watch_list": "",
    },
}
