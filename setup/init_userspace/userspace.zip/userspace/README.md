# userspace（用户空间）

框架**唯一建议修改/扩展**的业务侧目录。升级 `core/` 时尽量不动 `system/`，日常只改 `strategies/`。

## 顶层三分

| 目录 | 中文 | 说明 |
|------|------|------|
| [strategies/](strategies/) | **策略** | 每天用：`settings.py`、`strategy_worker.py`、`results/` |
| [extensions/](extensions/) | **扩展** | 标签、数据源、Data Contract、自定义表、扫描适配器 |
| [system/](system/) | **系统** | 配置、DuckDB 库文件、备份、升级器；**勿删整目录** |

## extensions/

| 子目录 | 说明 |
|--------|------|
| [tags/](extensions/tags/) | 标签场景与 `tag_worker.py` |
| [data_source/](extensions/data_source/) | 数据源 mapping、handlers、providers |
| [data_contract/](extensions/data_contract/) | Data Contract：`mapping.py` + `loaders/` |
| [tables/](extensions/tables/) | 自定义表 `schema.py` + `model.py`（`cust_*`） |
| [adapters/](extensions/adapters/) | 扫描结果输出适配器 |

## system/

| 子目录 | 说明 |
|--------|------|
| [config/](system/config/) | 本地 JSON 配置（数据库、data、markets 等） |
| [db/](system/db/) | DuckDB 三域：`data.duckdb`、`tag.duckdb`、`strategy.duckdb` |
| [backup/](system/backup/) | 表导出备份 |
| [updater/](system/updater/) | 应用升级流水线 |
| `.ntq/` | 内部缓存（升级、临时文件），勿手改 |

## 与 CLI

入口：仓库根 [`cli.py`](../cli.py)（原 `start-cli.py`）。在策略 `settings.py` 里设置 `is_enabled: True` 后，多数命令可不写 `--strategy`。

配置字段说明：[strategies/settings_example.py](strategies/settings_example.py)、[extensions/tags/settings_example.py](extensions/tags/settings_example.py)。
