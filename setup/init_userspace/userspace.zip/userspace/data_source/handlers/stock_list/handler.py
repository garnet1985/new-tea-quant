"""
股票列表 Handler：Tushare L+D+P 全量；维度表与映射在 on_before_save 写入。
"""
from typing import List, Dict, Any, Optional, Set, Tuple
import logging

from core.modules.data_source.base_class.base_handler import BaseHandler
from core.utils.date.date_utils import DateUtils

from .helper import (
    format_mapped_records_with_defaults,
    save_stock_dimension_mappings,
)

logger = logging.getLogger(__name__)

CACHE_KEY = "stock_list_last_update"
CACHE_DATE_FIELD = "last_checked_at"


class TushareStockListHandler(BaseHandler):
    """股票列表：缓存短路 → get_stock_list_full → 主表 + 维度/映射。"""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if context.get("force_refresh"):
            logger.info("stock_list force_refresh：跳过日缓存，调用 API 更新")
            return None
        dm = context["data_manager"]
        try:
            cache = dm.db_cache.load(CACHE_KEY, field="json")
            if self._is_valid_cache(cache):
                data = dm.stock.list.load_all()
                logger.info(
                    "✅ stock_list 命中缓存，从 DB 直接返回（共 %s 只）",
                    len(data) if data else 0,
                )
                return {"data": data}
            logger.info("ℹ️ stock_list 缓存校验失败，本次将调用 API 更新")
        except Exception:
            pass
        return None

    def on_after_mapping(self, context: Dict[str, Any], mapped_records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        formatted = format_mapped_records_with_defaults(mapped_records)
        # 独立副本：normalize 会按 sys_stock_list schema 裁剪字段，维度仍从 raw 读取
        context["_stock_list_raw_records"] = [dict(r) for r in formatted]
        logger.info("✅ 股票列表映射完成，共 %s 只", len(formatted))
        return formatted

    def on_before_save(self, context: Dict[str, Any], normalized_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        dm = context["data_manager"]
        main_records = normalized_data.get("data", [])
        if not main_records:
            return {"data": []}

        time_str = DateUtils.today()
        for r in main_records:
            r["last_update"] = time_str

        if context.get("is_dry_run"):
            return {"data": main_records}

        raw_records = context.get("_stock_list_raw_records") or []
        boards, markets, industries, areas = self._group_dimension_values(raw_records)
        logger.info(
            "维度字典批次: board=%s market=%s industry=%s area=%s（raw 样本字段=%s）",
            len(boards),
            len(markets),
            len(industries),
            len(areas),
            sorted(raw_records[0].keys()) if raw_records else [],
        )

        list_svc = dm.stock.list
        val_to_id = {
            "board": list_svc.ensure_and_sync_boards(boards),
            "market": list_svc.ensure_and_sync_markets(markets),
            "industry": list_svc.ensure_and_sync_industries(industries),
            "area": list_svc.ensure_and_sync_areas(areas),
        }
        dimensions = self._build_dimensions(main_records, raw_records)
        if (
            list_svc.industry_map_model
            and list_svc.board_map_model
            and list_svc.market_map_model
            and list_svc.area_map_model
        ):
            save_stock_dimension_mappings(
                dimensions,
                val_to_id,
                list_svc.industry_map_model,
                list_svc.board_map_model,
                list_svc.market_map_model,
                list_svc.area_map_model,
            )

        try:
            dm.db_cache.save(CACHE_KEY, json={CACHE_DATE_FIELD: time_str})
        except Exception:
            pass

        return {"data": main_records}

    def _is_valid_cache(self, cache: Optional[Dict[str, Any]]) -> bool:
        if not cache:
            return False
        cache_date = cache.get(CACHE_DATE_FIELD)
        return bool(cache_date and DateUtils.is_today(cache_date))

    def _group_dimension_values(
        self, raw_records: List[Dict[str, Any]]
    ) -> Tuple[List[str], List[str], List[str], List[str]]:
        boards: Set[str] = set()
        markets: Set[str] = set()
        industries: Set[str] = set()
        areas: Set[str] = set()
        for record in raw_records:
            for key, target in (
                ("board", boards),
                ("market", markets),
                ("industry", industries),
                ("area", areas),
            ):
                v = (record.get(key) or "").strip()
                if v:
                    target.add(v)
        return list(boards), list(markets), list(industries), list(areas)

    def _build_dimensions(
        self, main_records: List[Dict[str, Any]], raw_records: List[Dict[str, Any]]
    ) -> List[Tuple[str, str, str, str, str]]:
        dimensions: List[Tuple[str, str, str, str, str]] = []
        for i, r in enumerate(main_records):
            stock_id = str(r.get("id") or "")
            raw = raw_records[i] if i < len(raw_records) else {}
            dimensions.append(
                (
                    stock_id,
                    (raw.get("industry") or "").strip(),
                    (raw.get("board") or "").strip(),
                    (raw.get("market") or "").strip(),
                    (raw.get("area") or "").strip(),
                )
            )
        return dimensions
