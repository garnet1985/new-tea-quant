# Adapter 用户指南（userspace）

本指南面向「要把扫描结果接到自己渠道」的用户，例如控制台打印、webhook、写文件、消息推送。

Adapter 不负责选股逻辑，只消费 Strategy 产出的 `Opportunity` 列表。

---

## 1. 运行链路

1. Strategy 扫描得到 `Opportunity` 列表
2. Scanner 读取策略 `scanner.adapters`
3. 框架加载 `userspace/extensions/adapters/<name>/adapter.py`
4. 依次调用 `process(opportunities, context)`

---

## 2. 目录约定

```text
userspace/extensions/adapters/<adapter_name>/
├── adapter.py
└── settings.py
```

- `<adapter_name>` 与策略里 `scanner.adapters` 字符串一致
- `adapter.py` 中类须继承 `BaseOpportunityAdapter`

---

## 3. 在策略中启用

```python
"scanner": {
    "max_workers": "auto",
    "adapters": ["console", "my_adapter"],
}
```

---

## 4. 运行

```bash
python cli.py scan --strategy demo/random/random_v1_null_baseline
```

---

## 5. 参考

- [README.md](README.md)
- `core/modules/adapter/README.md`
- 示例：`console/`、`example/`
