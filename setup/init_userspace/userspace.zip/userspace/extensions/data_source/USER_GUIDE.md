# 数据源用户指南（userspace）

本指南介绍如何在 `userspace/extensions/data_source/` 里：

- 选择并启用现有数据源（`mapping.py`）
- 新增/修改数据源抓取逻辑（`handlers/`）
- 配置外部数据提供方（`providers/`）

---

## 1. 先理解三件事

### data source 是什么？

一种「要抓的数据」，对应 `mapping.py` 的一个 key（如 `stock_klines`、`stock_moneyflow`）。

### handler 是什么？

把「我要抓什么」变成可执行任务，并把结果清洗成可入库的行数据（fetch → normalize → 写库）。

### provider 是什么？

具体调用外部 API 的实现（Tushare / AKShare 等）。handler 通过 provider 拿原始数据。

---

## 2. 用现有数据源（只配置不写代码）

### Step 1. 配置 provider（可选）

Tushare：创建 `providers/tushare/auth_token.txt`（一行 token），或设置环境变量 `TUSHARE_TOKEN`。  
详见 [providers/README.md](providers/README.md)。

### Step 2. 启用/禁用 data source

编辑 `mapping.py`：

```python
DATA_SOURCES = {
    "stock_klines": {
        "handler": "stock_klines.KlineHandler",
        "is_enabled": True,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
    "stock_moneyflow": {
        "handler": "stock_moneyflow.StockMoneyflowHandler",
        "is_enabled": True,
        "depends_on": ["stock_list", "latest_completed_trading_date"],
    },
}
```

### Step 3. 运行更新

```bash
python cli.py -r                    # 全部已启用数据源
python cli.py -r stock_klines       # 单个（表名或 key）
python cli.py renew stock_moneyflow
```

---

## 3. 开发样本池

若 `data.json` 配置了 `use_sample_stock_list`，框架会在**读 stock list、写 per-stock 表**时自动过滤，无需在 handler 里重复处理。

- K 线、指标等：按 `stock_list` 逐股拉取，天然只拉池内股
- Moneyflow 等「按日全市场」接口：API 仍返回全市场，**落库前**过滤池外 id

清理 DB 历史池外数据（示例）：

```sql
DELETE FROM sys_stock_moneyflow
WHERE id NOT IN (SELECT id FROM sys_stock_list);
```

详见 [`system/config/README.md`](../../system/config/README.md)。

---

## 4. 新增 data source（简要流程）

1. 在 `handlers/<name>/` 新建 `handler.py`（+ `config.py`）
2. 在 `mapping.py` 注册 key、`handler` 类名、`depends_on`
3. 小范围验证：`python cli.py -r <key>`

Handler 约定见 `core/modules/data_source/README.md`。

---

## 5. 常见问题

**handler 加载失败？**  
检查 `handler` 字段是否为 `<模块>.<类名>`，文件是否在 `handlers/<模块>/handler.py`。

**depends_on 缺失？**  
依赖的 data source 须已启用；保留关键字如 `latest_completed_trading_date` 拼写须正确。

**配置了 500 样本池但某表仍很大？**  
可能是启用样本池**之前**写入的全市场历史；renew 不会删旧行，需手动 SQL 或后续 prune。

---

## 6. 参考

- 入口：[README.md](README.md)
- providers：[providers/README.md](providers/README.md)
- Core：`core/modules/data_source/README.md`
