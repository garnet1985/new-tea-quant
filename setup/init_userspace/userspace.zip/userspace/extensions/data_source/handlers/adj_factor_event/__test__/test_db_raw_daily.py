"""L3：DB sys_stock_klines 优先取 raw daily 辅助测试。"""
from __future__ import annotations

from unittest.mock import MagicMock

import pandas as pd

from userspace.extensions.data_source.handlers.adj_factor_event.handler import (
    AdjFactorEventHandler,
)
from userspace.extensions.data_source.handlers.adj_factor_event.helper import (
    AdjFactorEventHandlerHelper as helper,
)


def _make_handler() -> AdjFactorEventHandler:
    return AdjFactorEventHandler(
        data_source_key="adj_factor_event",
        schema=MagicMock(),
        config=MagicMock(),
        providers={},
    )


class TestDbRawDailyHelper:
    def test_build_raw_price_map_from_db_rows(self):
        rows = [
            {"id": "000001.SZ", "term": "daily", "date": "20250601", "close": 10.1},
            {"id": "000001.SZ", "term": "daily", "date": "20250602", "close": 10.2},
        ]
        m = helper.build_raw_price_map_from_db_rows(rows)
        assert m["20250601"] == 10.1
        assert m["20250602"] == 10.2

    def test_db_cover_range_and_event_dates(self):
        rows = [
            {"term": "daily", "date": "20250601", "close": 1.0},
            {"term": "daily", "date": "20250610", "close": 2.0},
        ]
        assert helper.db_daily_klines_cover_range(rows, "20250601", "20250610")
        raw_map = helper.build_raw_price_map_from_db_rows(rows)
        assert helper.raw_price_map_covers_event_dates(raw_map, ["20250605"])

    def test_db_cover_range_fails_when_span_too_narrow(self):
        rows = [{"term": "daily", "date": "20250605", "close": 1.0}]
        assert not helper.db_daily_klines_cover_range(rows, "20250601", "20250610")


class TestFetchRawDaily:
    def test_uses_db_when_sufficient(self):
        handler = _make_handler()
        kline_model = MagicMock()
        kline_model.load.return_value = [
            {"term": "daily", "date": "20250601", "close": 11.0},
            {"term": "daily", "date": "20250610", "close": 12.0},
        ]
        dm = MagicMock()
        dm.get_table.return_value = kline_model
        context = {"data_manager": dm}

        df = handler._fetch_raw_daily(
            context,
            "000001.SZ",
            "20250601",
            "20250610",
            required_event_dates=["20250605"],
        )
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert "trade_date" in df.columns

    def test_fallback_tushare_when_db_empty(self):
        handler = _make_handler()
        kline_model = MagicMock()
        kline_model.load.return_value = []
        dm = MagicMock()
        dm.get_table.return_value = kline_model

        tushare_df = pd.DataFrame(
            {"trade_date": ["20250601"], "close": [9.9]}
        )
        handler._invoke_provider = MagicMock(return_value=tushare_df)  # type: ignore[method-assign]

        df = handler._fetch_raw_daily(
            {"data_manager": dm},
            "000001.SZ",
            "20250601",
            "20250610",
        )
        handler._invoke_provider.assert_called_once()
        assert len(df) == 1
