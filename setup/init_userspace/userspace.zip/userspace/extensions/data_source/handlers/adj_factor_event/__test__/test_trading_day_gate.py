"""adj_factor_event L0 交易日门控 + L1 探测窗辅助测试。"""
from __future__ import annotations

from unittest.mock import MagicMock

import pandas as pd
import pytest

from core.modules.data_source.data_class.api_job import ApiJob
from core.modules.data_source.data_class.api_job_bundle import ApiJobBundle
from userspace.extensions.data_source.handlers.adj_factor_event.handler import (
    AdjFactorEventHandler,
)
from userspace.extensions.data_source.handlers.adj_factor_event.helper import (
    AdjFactorEventHandlerHelper as helper,
)


def _mock_calendar(open_days_in_range):
    """open_days_in_range: list of cal_date strings for any load_range(is_open=1)."""

    cal = MagicMock()

    def _max_on_or_before(as_of, *, is_open_only=False):
        # 简化：as_of 若在 open set 则返回 as_of，否则往前找
        candidates = [d for d in sorted(open_days_in_range) if d <= as_of[:8]]
        return candidates[-1] if candidates else ""

    cal.load_max_cal_date_on_or_before.side_effect = _max_on_or_before
    cal.load_range.side_effect = (
        lambda start, end, is_open=1, market="SSE": [
            {"cal_date": d}
            for d in open_days_in_range
            if start <= d <= end
        ]
    )
    return cal


class TestTradingDayGate:
    def test_no_pending_when_last_update_covers_latest(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        assert not helper.has_pending_trading_days_since_last_update(
            "2025-06-09 18:00:00",
            "20250609",
            trade_calendar_model=cal,
        )

    def test_pending_when_new_open_day_after_last_check(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        assert helper.has_pending_trading_days_since_last_update(
            "2025-06-06 18:00:00",
            "20250609",
            trade_calendar_model=cal,
        )

    def test_no_last_update_means_pending(self):
        cal = _mock_calendar(["20250609"])
        assert helper.has_pending_trading_days_since_last_update(
            None,
            "20250609",
            trade_calendar_model=cal,
        )

    def test_filter_stocks_pending(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        lu = {
            "000001.SZ": "2025-06-09 10:00:00",
            "000002.SZ": "2025-06-05 10:00:00",
        }
        pending = helper.filter_stocks_with_pending_trading_days(
            ["000001.SZ", "000002.SZ", "600000.SH"],
            lu,
            "20250609",
            trade_calendar_model=cal,
        )
        assert pending == {"000002.SZ", "600000.SH"}

    def test_probe_start_is_next_open_after_last_checked(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        start = helper.resolve_adj_factor_probe_start(
            "2025-06-05 22:00:00",
            "20250609",
            trade_calendar_model=cal,
        )
        assert start == "20250606"

    def test_has_factor_change_in_range(self):
        df = pd.DataFrame(
            {
                "trade_date": ["20250605", "20250606", "20250609"],
                "adj_factor": [1.0, 1.0, 1.05],
            }
        )
        assert not helper.has_factor_change_in_range(df, "20250606", "20250606")
        assert helper.has_factor_change_in_range(df, "20250606", "20250609")

    def test_resolve_chain_verify_fetch_start(self):
        existing = [
            {"event_date": "20200301", "factor": 1.0},
            {"event_date": "20210601", "factor": 1.1},
        ]
        assert helper.resolve_chain_verify_fetch_start(existing, "20080101") == "20200301"


def _make_handler() -> AdjFactorEventHandler:
    return AdjFactorEventHandler(
        data_source_key="adj_factor_event",
        schema=MagicMock(),
        config=MagicMock(),
        providers={},
    )


def _adj_bundle(stock_id: str) -> ApiJobBundle:
    return ApiJobBundle(
        bundle_id=f"adj_factor_event_batch_{stock_id}",
        apis=[
            ApiJob(
                api_name="adj_factor",
                job_id="adj_factor",
                method="get_adj_factor",
            )
        ],
    )


class TestHandlerTradingDayGate:
    def test_l0_skips_when_all_candidates_up_to_date(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        adj_model = MagicMock()
        adj_model.load_stock_last_update_map.return_value = {
            "000001.SZ": "2025-06-09 10:00:00",
        }

        dm = MagicMock()
        dm.get_table.return_value = cal
        dm.stock.kline._adj_factor_event = adj_model

        handler = _make_handler()
        context: dict = {"data_manager": dm}
        jobs = [_adj_bundle("000001.SZ")]

        out = handler._apply_trading_day_gate(context, jobs, "20250609")
        assert out == []
        assert context["_adj_factor_probe_by_stock"] == {}

    def test_l0_includes_stock_without_db_last_update(self):
        """表内全员跟上时，库外/无 last_update 的新股仍须进候选。"""
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        adj_model = MagicMock()
        adj_model.load_stock_last_update_map.return_value = {
            "000001.SZ": "2025-06-09 10:00:00",
        }

        dm = MagicMock()
        dm.get_table.return_value = cal
        dm.stock.kline._adj_factor_event = adj_model

        handler = _make_handler()
        context: dict = {"data_manager": dm}
        jobs = [_adj_bundle("000001.SZ"), _adj_bundle("600000.SH")]

        out = handler._apply_trading_day_gate(context, jobs, "20250609")
        assert len(out) == 1
        assert handler._extract_stock_id(out[0]) == "600000.SH"
        assert "600000.SH" not in context["_adj_factor_probe_by_stock"]

    def test_l0_keeps_only_pending_and_sets_probe_window(self):
        cal = _mock_calendar(["20250605", "20250606", "20250609"])
        adj_model = MagicMock()
        adj_model.load_stock_last_update_map.return_value = {
            "000001.SZ": "2025-06-09 10:00:00",
            "000002.SZ": "2025-06-05 10:00:00",
        }
        dm = MagicMock()
        dm.get_table.return_value = cal
        dm.stock.kline._adj_factor_event = adj_model

        handler = _make_handler()
        context: dict = {"data_manager": dm}
        jobs = [_adj_bundle("000001.SZ"), _adj_bundle("000002.SZ")]

        out = handler._apply_trading_day_gate(context, jobs, "20250609")
        assert len(out) == 1
        assert handler._extract_stock_id(out[0]) == "000002.SZ"
        assert context["_adj_factor_probe_by_stock"]["000002.SZ"] == (
            "20250606",
            "20250609",
        )
