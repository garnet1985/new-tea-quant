"""
复权因子事件 Handler

日常 incremental（L0→L3）：
  L0：DB last_update + sys_trade_calendar（依赖 latest_completed_trading_date）筛股；
  L1：窄窗 Tushare adj_factor 探测 factor 变化；
  L2：有变化则拉全链起点 adj_factor + 前链校验；
  L3：有尾部则窄窗 raw（DB sys_stock_klines 优先）+ 腾讯 qfq append；无变化/无尾部只戳 last_update。
异常或 renew -f：全量 3 API + refresh。
"""
from typing import List, Dict, Any, Optional, Tuple
import logging
import os
import pandas as pd

from core.modules.data_source.base_class.base_handler import BaseHandler
from core.modules.data_source.base_class.base_provider import BaseProvider
from core.modules.data_source.data_class.api_job import ApiJob
from core.modules.data_source.data_class.api_job_bundle import ApiJobBundle
from core.modules.data_source.data_class.config import DataSourceConfig
from .helper import AdjFactorEventHandlerHelper as helper
from core.infra.project_context import ConfigManager


logger = logging.getLogger(__name__)


class AdjFactorEventHandler(BaseHandler):
    """
    复权因子事件 Handler

    incremental：每股 bundle 默认仅 adj_factor；save 阶段按前链校验决定 touch / append / refresh。
    force_refresh：bundle 含 adj_factor + daily_kline + qfq_kline 全量。
    """

    def __init__(
        self,
        data_source_key: str,
        schema,
        config: DataSourceConfig,
        providers: Dict[str, BaseProvider],
        depend_on_data_source_names: List[str] = None,
    ):
        super().__init__(data_source_key, schema, config, providers, depend_on_data_source_names or [])

    def on_after_build_jobs(
        self,
        context: Dict[str, Any],
        jobs: List[ApiJobBundle],
        entity_date_ranges: Dict[str, Tuple[str, str]],
    ) -> List[ApiJobBundle]:
        """incremental：L0 交易日门控筛股 + 仅保留 adj_factor job（窄窗参数在 on_build_job_payload）。"""
        if context.get("force_refresh"):
            return jobs

        latest = str(context.get("latest_completed_trading_date") or "").strip()
        trimmed: List[ApiJobBundle] = []
        for bundle in jobs:
            adj_jobs = [
                job
                for job in bundle.apis
                if job.api_name == "adj_factor"
                or job.job_id == "adj_factor"
                or job.method == "get_adj_factor"
            ]
            if not adj_jobs:
                continue
            trimmed.append(
                ApiJobBundle(
                    bundle_id=bundle.bundle_id,
                    apis=adj_jobs,
                    tuple_order_map=bundle.tuple_order_map,
                    start_date=bundle.start_date,
                    end_date=bundle.end_date,
                )
            )

        if not trimmed:
            return trimmed

        trimmed = self._apply_trading_day_gate(context, trimmed, latest)
        if not trimmed:
            return []

        if trimmed:
            logger.info(
                f"📋 [adj_factor_event] incremental：{len(trimmed)} 个 bundle 待拉 adj_factor（L0 通过后）"
            )
        return trimmed

    def _apply_trading_day_gate(
        self,
        context: Dict[str, Any],
        jobs: List[ApiJobBundle],
        latest_ymd: str,
    ) -> List[ApiJobBundle]:
        """L0：按股 MAX(last_update) + 交易日历筛 renew 候选；候选为空则 0 API。"""
        if not latest_ymd:
            return jobs

        data_manager = context.get("data_manager")
        if not data_manager:
            return jobs

        adj_model = data_manager.stock.kline._adj_factor_event
        trade_cal = data_manager.get_table("sys_trade_calendar")
        lu_map = adj_model.load_stock_last_update_map()

        stock_ids = []
        for bundle in jobs:
            sid = self._extract_stock_id(bundle)
            if sid:
                stock_ids.append(sid)

        pending = helper.filter_stocks_with_pending_trading_days(
            stock_ids,
            lu_map,
            latest_ymd,
            trade_calendar_model=trade_cal,
        )

        if not pending:
            logger.info(
                "📋 [adj_factor_event] L0：renew 候选 0 股（%d 股均已覆盖 %s），跳过 API",
                len(stock_ids),
                latest_ymd,
            )
            context["_adj_factor_probe_by_stock"] = {}
            return []

        probe_by_stock: Dict[str, Tuple[str, str]] = {}
        for sid in pending:
            if sid in lu_map and lu_map.get(sid):
                probe_start = helper.resolve_adj_factor_probe_start(
                    lu_map[sid],
                    latest_ymd,
                    trade_calendar_model=trade_cal,
                )
                probe_by_stock[sid] = (probe_start, latest_ymd)

        context["_adj_factor_probe_by_stock"] = probe_by_stock
        skipped = len(stock_ids) - len(pending)
        if skipped:
            logger.info(
                "📋 [adj_factor_event] L0：跳过 %d 股（已覆盖最新交易日），待处理 %d 股",
                skipped,
                len(pending),
            )

        return [b for b in jobs if self._extract_stock_id(b) in pending]

    def on_build_job_payload(
        self,
        entity_info: Any,
        apis: List[ApiJob],
        context: Dict[str, Any],
    ) -> Optional[str]:
        """注入 ts_code/symbol；incremental 日常为窄窗 adj_factor（L1），无历史则全历史。"""
        entity_id = entity_info.get("id") if isinstance(entity_info, dict) else str(entity_info)
        if not entity_id:
            return None

        latest = context.get("latest_completed_trading_date")
        default_start = ConfigManager.get_default_start_date()
        probe_win = (context.get("_adj_factor_probe_by_stock") or {}).get(str(entity_id))

        for job in apis:
            job.params = job.params or {}
            is_qfq = (
                job.api_name == "qfq_kline"
                or job.job_id == "qfq_kline"
                or job.method == "get_qfq_kline"
            )
            if is_qfq:
                job.params.pop("ts_code", None)
                job.params["symbol"] = helper.convert_to_tx_symbol(str(entity_id))
            else:
                job.params.pop("symbol", None)
                job.params["ts_code"] = str(entity_id)
            if probe_win and not context.get("force_refresh"):
                job.params["start_date"] = probe_win[0]
                job.params["end_date"] = probe_win[1]
            else:
                if default_start:
                    job.params["start_date"] = default_start
                if latest:
                    job.params["end_date"] = latest

        return str(entity_id)

    def on_after_batch_api_job_bundles_complete(
        self,
        context: Dict[str, Any],
        batch_items: List[Tuple[Any, Dict[str, Any]]],
    ) -> None:
        """每股独立 save；batch 仅表示调度批次。"""
        for job_bundle, fetched_data in batch_items:
            self._save_adj_factor_bundle(context, job_bundle, fetched_data)

    def _save_adj_factor_bundle(
        self,
        context: Dict[str, Any],
        job_bundle: ApiJobBundle,
        fetched_data: Dict[str, Any],
    ) -> None:
        stock_id = self._extract_stock_id(job_bundle)
        if not stock_id:
            return

        if context.get("is_dry_run"):
            return

        adj_df = fetched_data.get("adj_factor")
        if adj_df is None or (isinstance(adj_df, pd.DataFrame) and adj_df.empty):
            logger.warning(f"⚠️ [{stock_id}] adj_factor 为空，跳过（不更新 last_update）")
            return

        data_manager = context["data_manager"]
        existing = data_manager.stock.kline.load_adj_factor_events(stock_id)
        latest_ymd = str(context.get("latest_completed_trading_date") or "").strip()
        probe_win = (context.get("_adj_factor_probe_by_stock") or {}).get(stock_id)

        if (
            not context.get("force_refresh")
            and probe_win
            and existing
            and latest_ymd
        ):
            probe_start, probe_end = probe_win
            if not helper.has_factor_change_in_range(
                adj_df, probe_start, probe_end
            ):
                data_manager.stock.kline.update_adj_factor_last_update(stock_id)
                logger.info(
                    f"✅ [{stock_id}] L1：探测窗 {probe_start}~{probe_end} 无 factor 变化，"
                    "已更新 last_update"
                )
                return
            chain_start = helper.resolve_chain_verify_fetch_start(
                existing,
                ConfigManager.get_default_start_date() or probe_start,
            )
            if chain_start and (chain_start < probe_start or len(adj_df) < 3):
                adj_df = self._fetch_adj_factor(
                    context, stock_id, chain_start, probe_end or latest_ymd
                )
                if adj_df is None or (
                    isinstance(adj_df, pd.DataFrame) and adj_df.empty
                ):
                    logger.warning(
                        f"⚠️ [{stock_id}] 前链扩展 adj_factor 为空，跳过"
                    )
                    return

        if context.get("force_refresh"):
            self._save_with_bundle_data(
                context, stock_id, adj_df, fetched_data, existing, mode="refresh"
            )
            return

        first_kline_ymd = helper.resolve_first_kline_ymd(existing, adj_df)
        chain_ok, chain_reason, expected_chain = helper.verify_event_chain_prefix(
            existing, adj_df, first_kline_ymd
        )

        if not existing:
            logger.info(f"📋 [{stock_id}] 无历史事件，全量 refresh")
            self._save_full_refresh(context, stock_id, adj_df, existing)
            return

        if not chain_ok:
            logger.warning(
                f"⚠️ [{stock_id}] 前链校验失败 ({chain_reason})，降级全量 refresh"
            )
            self._save_full_refresh(context, stock_id, adj_df, existing)
            return

        tail_keys = expected_chain[len(existing) :]
        if not tail_keys:
            if not helper.events_support_append(existing):
                logger.warning(
                    f"⚠️ [{stock_id}] 前链一致但无 anchor，降级全量 refresh 以补齐"
                )
                self._save_full_refresh(context, stock_id, adj_df, existing)
                return
            data_manager.stock.kline.update_adj_factor_last_update(stock_id)
            logger.info(f"✅ [{stock_id}] 前链一致、无尾部新事件，已更新 last_update")
            return

        if not helper.events_support_append(existing):
            logger.warning(f"⚠️ [{stock_id}] 库内无 anchor，降级全量 refresh")
            self._save_full_refresh(context, stock_id, adj_df, existing)
            return

        tail_dates = [d for d, _ in tail_keys]
        fetch_range = helper.date_range_for_event_dates(
            tail_dates,
            buffer_days=7,
            end_date_cap=context.get("latest_completed_trading_date"),
        )
        if not fetch_range:
            logger.warning(f"⚠️ [{stock_id}] 无法计算尾部拉取范围，跳过（不更新 last_update）")
            return

        fetch_start, fetch_end = fetch_range
        daily_df, qfq_result = self._fetch_daily_and_qfq(
            context,
            stock_id,
            fetch_start,
            fetch_end,
            required_event_dates=tail_dates,
        )
        if daily_df is None or (isinstance(daily_df, pd.DataFrame) and daily_df.empty):
            logger.warning(
                f"⚠️ [{stock_id}] 尾部 daily_kline 为空，跳过 append（不更新 last_update）"
            )
            return

        qfq_map = (
            helper.parse_akshare_qfq_price_map(qfq_result)
            if isinstance(qfq_result, pd.DataFrame)
            else {}
        )
        if not qfq_map:
            logger.warning(
                f"⚠️ [{stock_id}] 尾部腾讯 qfq 为空，跳过 append（不更新 last_update）"
            )
            return

        raw_price_map = helper.build_raw_price_map(daily_df)
        tail_events = helper.build_events_for_chain_keys(
            stock_id, adj_df, raw_price_map, qfq_map, tail_keys
        )
        if not tail_events or len(tail_events) != len(tail_keys):
            logger.warning(
                f"⚠️ [{stock_id}] 尾部事件构建不完整，跳过 append（不更新 last_update）"
            )
            return

        data_manager.stock.kline.save_adj_factor_events(tail_events)
        data_manager.stock.kline.update_adj_factor_last_update(stock_id)
        logger.info(
            f"✅ [{stock_id}] 前链校验通过，append {len(tail_events)} 个事件"
            f"（窄窗 {fetch_start}~{fetch_end}）"
        )

    def _save_with_bundle_data(
        self,
        context: Dict[str, Any],
        stock_id: str,
        adj_df: pd.DataFrame,
        fetched_data: Dict[str, Any],
        existing: List[Dict[str, Any]],
        mode: str = "refresh",
    ) -> None:
        """使用 bundle 内已拉取的 daily+qfq 做全量 build + append/refresh。"""
        daily_df = fetched_data.get("daily_kline")
        qfq_result = fetched_data.get("qfq_kline")

        if daily_df is None or (isinstance(daily_df, pd.DataFrame) and daily_df.empty):
            logger.warning(f"⚠️ [{stock_id}] daily_kline 为空，跳过")
            return

        qfq_map = (
            helper.parse_akshare_qfq_price_map(qfq_result)
            if isinstance(qfq_result, pd.DataFrame)
            else {}
        )
        if not qfq_map:
            logger.warning(f"⚠️ [{stock_id}] 腾讯前复权解析后为空，跳过")
            return

        raw_price_map = helper.build_raw_price_map(daily_df)
        first_kline_ymd = helper.resolve_first_kline_ymd(
            existing, adj_df, daily_kline_df=daily_df, qfq_map=qfq_map
        )
        if not first_kline_ymd:
            logger.warning(f"⚠️ [{stock_id}] 无第一根K线日期，跳过")
            return

        events_to_save = helper.build_adj_factor_events(
            stock_id=stock_id,
            adj_factor_df=adj_df,
            raw_price_map=raw_price_map,
            qfq_map=qfq_map,
            first_kline_ymd=first_kline_ymd,
        )
        if not events_to_save:
            logger.warning(f"⚠️ [{stock_id}] build_adj_factor_events 返回空，跳过")
            return

        data_manager = context["data_manager"]
        can_append, tail = helper.split_append_tail(existing, events_to_save)

        if can_append and mode != "refresh":
            data_manager.stock.kline.save_adj_factor_events(tail)
            data_manager.stock.kline.update_adj_factor_last_update(stock_id)
            logger.info(f"✅ [{stock_id}] append {len(tail)} 个复权事件（保留 {len(existing)} 条）")
            return

        data_manager.stock.kline.delete_adj_factor_events(stock_id)
        data_manager.stock.kline.save_adj_factor_events(events_to_save)
        data_manager.stock.kline.update_adj_factor_last_update(stock_id)
        logger.info(f"✅ [{stock_id}] refresh 保存 {len(events_to_save)} 个复权事件")

    def _save_full_refresh(
        self,
        context: Dict[str, Any],
        stock_id: str,
        adj_df: pd.DataFrame,
        existing: List[Dict[str, Any]],
    ) -> None:
        """按需全量拉 daily+qfq 后 refresh（绝不用窄窗 adj_factor 做 delete+save）。"""
        default_start = ConfigManager.get_default_start_date()
        end_date = context.get("latest_completed_trading_date")
        if not default_start or not end_date:
            logger.warning(f"⚠️ [{stock_id}] 缺少 default_start/end_date，无法全量 refresh")
            return

        daily_df, qfq_result = self._fetch_daily_and_qfq(
            context, stock_id, default_start, end_date
        )
        fetched_data = {
            "adj_factor": adj_df,
            "daily_kline": daily_df,
            "qfq_kline": qfq_result,
        }
        self._save_with_bundle_data(
            context, stock_id, adj_df, fetched_data, existing, mode="refresh"
        )

    def _fetch_adj_factor(
        self,
        context: Dict[str, Any],
        stock_id: str,
        start_date: str,
        end_date: str,
    ) -> Any:
        return self._invoke_provider(
            context,
            "tushare",
            "get_adj_factor",
            ts_code=stock_id,
            start_date=start_date,
            end_date=end_date,
        )

    def _load_db_daily_klines(
        self,
        context: Dict[str, Any],
        stock_id: str,
        start_date: str,
        end_date: str,
    ) -> List[Dict[str, Any]]:
        data_manager = context.get("data_manager")
        if not data_manager:
            return []
        kline_model = data_manager.get_table("sys_stock_klines")
        if kline_model is None:
            return []
        try:
            return (
                kline_model.load(
                    "id = %s AND term = %s AND date BETWEEN %s AND %s",
                    (stock_id, "daily", start_date, end_date),
                    order_by="date ASC",
                )
                or []
            )
        except Exception as exc:
            logger.debug(f"[{stock_id}] 读取 sys_stock_klines 失败: {exc}")
            return []

    def _fetch_raw_daily(
        self,
        context: Dict[str, Any],
        stock_id: str,
        start_date: str,
        end_date: str,
        *,
        required_event_dates: Optional[List[str]] = None,
    ) -> Any:
        """raw 日线：优先 DB ``sys_stock_klines``，不足则 fallback Tushare daily_kline。"""
        db_rows = self._load_db_daily_klines(
            context, stock_id, start_date, end_date
        )
        if db_rows and helper.db_daily_klines_cover_range(
            db_rows, start_date, end_date
        ):
            raw_map = helper.build_raw_price_map_from_db_rows(db_rows)
            dates_ok = (
                not required_event_dates
                or helper.raw_price_map_covers_event_dates(
                    raw_map, required_event_dates
                )
            )
            if dates_ok:
                logger.info(
                    f"📋 [{stock_id}] raw daily 用 DB（{start_date}~{end_date}，"
                    f"{len(db_rows)} 条）"
                )
                return helper.db_daily_klines_to_dataframe(db_rows)

        logger.info(
            f"📋 [{stock_id}] raw daily fallback Tushare（{start_date}~{end_date}）"
        )
        return self._invoke_provider(
            context,
            "tushare",
            "get_daily_kline",
            ts_code=stock_id,
            start_date=start_date,
            end_date=end_date,
        )

    def _fetch_daily_and_qfq(
        self,
        context: Dict[str, Any],
        stock_id: str,
        start_date: str,
        end_date: str,
        *,
        required_event_dates: Optional[List[str]] = None,
    ) -> Tuple[Any, Any]:
        daily_df = self._fetch_raw_daily(
            context,
            stock_id,
            start_date,
            end_date,
            required_event_dates=required_event_dates,
        )
        qfq_df = self._invoke_provider(
            context,
            "akshare",
            "get_qfq_kline",
            symbol=helper.convert_to_tx_symbol(stock_id),
            start_date=start_date,
            end_date=end_date,
        )
        return daily_df, qfq_df

    def _invoke_provider(
        self,
        context: Dict[str, Any],
        provider_name: str,
        method: str,
        **kwargs,
    ) -> Any:
        providers = context.get("providers") or self.context.get("providers") or {}
        provider = providers.get(provider_name)
        if provider is None:
            raise ValueError(f"Provider 未注册: {provider_name}")
        fn = getattr(provider, method, None)
        if fn is None:
            raise ValueError(f"{provider_name} 无方法 {method}")
        return provider.invoke_with_retry(method, lambda: fn(**kwargs))

    def _extract_stock_id(self, job_bundle: ApiJobBundle) -> Optional[str]:
        bid = job_bundle.bundle_id or ""
        prefix = "adj_factor_event_batch_"
        if bid.startswith(prefix):
            return bid[len(prefix) :]
        return None

    def on_prepare_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """预处理：CSV 导入检查、should_generate_csv。"""
        context = super().on_prepare_context(context)
        self._latest_completed_trading_date = context.get("latest_completed_trading_date")

        data_manager = context["data_manager"]
        adj_model = data_manager.stock.kline._adj_factor_event
        context["should_generate_csv"] = False

        if hasattr(adj_model, "is_table_empty"):
            is_empty = adj_model.is_table_empty()
        else:
            try:
                is_empty = adj_model.count() == 0
            except Exception:
                return context

        if is_empty:
            if hasattr(adj_model, "get_latest_csv_file") and hasattr(adj_model, "import_from_csv"):
                if self._is_csv_exist_and_valid(adj_model):
                    cnt = adj_model.import_from_csv()
                    if cnt > 0:
                        logger.info(f"✅ 从CSV导入 {cnt} 条，表已恢复")
        else:
            if hasattr(adj_model, "get_latest_csv_file") and hasattr(adj_model, "get_current_quarter_csv_name"):
                if self._is_csv_expired(adj_model, base_date=self._latest_completed_trading_date) or not self._is_csv_exist_and_valid(adj_model):
                    context["should_generate_csv"] = True

        return context

    def _is_csv_exist_and_valid(self, adj_model) -> bool:
        if not hasattr(adj_model, "get_latest_csv_file"):
            return False
        csv_file = adj_model.get_latest_csv_file()
        if not csv_file or not os.path.exists(csv_file):
            return False
        try:
            df = pd.read_csv(csv_file, nrows=1)
            return all(c in df.columns for c in ["id", "event_date", "factor", "qfq_diff"])
        except Exception:
            return False

    def _is_csv_expired(self, adj_model, base_date: str = None) -> bool:
        if not hasattr(adj_model, "get_latest_csv_file") or not hasattr(adj_model, "get_current_quarter_csv_name"):
            return True
        csv_file = adj_model.get_latest_csv_file()
        if not csv_file:
            return True
        current_name = adj_model.get_current_quarter_csv_name(base_date=base_date)
        return os.path.basename(csv_file) != current_name

    def on_after_normalize(self, context: Dict[str, Any], normalized_data: Dict[str, Any]) -> Dict[str, Any]:
        """immediate 模式数据已在 on_after_single_api_job_bundle_complete 保存，返回空。"""
        data_manager = context.get("data_manager")
        if data_manager and context.get("should_generate_csv"):
            adj_model = data_manager.stock.kline._adj_factor_event
            if hasattr(adj_model, "get_current_quarter_csv_name") and hasattr(adj_model, "csv_dir") and hasattr(adj_model, "export_to_csv"):
                base_date = getattr(self, "_latest_completed_trading_date", None)
                csv_name = adj_model.get_current_quarter_csv_name(base_date=base_date)
                csv_path = os.path.join(adj_model.csv_dir, csv_name)
                if not os.path.exists(csv_path):
                    exported = adj_model.export_to_csv(file_path=csv_path)
                    logger.info(f"✅ 导出季度CSV: {exported} 条 -> {csv_name}")
        return normalized_data
