#!/usr/bin/env python3
"""CorporateFinanceHandler ann_date 归一化测试。"""

from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock

from userspace.extensions.data_source.handlers.corporate_finance.handler import (
    CorporateFinanceHandler,
)


def _handler_with_mapping() -> tuple[CorporateFinanceHandler, MagicMock]:
    config = MagicMock()
    config.get_apis.return_value = {
        "finance_data": SimpleNamespace(
            result_mapping={
                "end_date": "end_date",
                "ann_date": "ann_date",
                "netprofit_yoy": "netprofit_yoy",
            }
        )
    }
    handler = CorporateFinanceHandler(
        data_source_key="corporate_finance",
        schema={},
        config=config,
        providers={},
    )
    return handler, config


class TestCorporateFinanceHandlerNormalize(unittest.TestCase):
    def test_normalize_keeps_ann_date_and_sorts(self):
        handler, config = _handler_with_mapping()
        context = {"config": config}
        result = [
            {
                "end_date": "20240630",
                "ann_date": "20240831",
                "netprofit_yoy": 2.0,
            },
            {
                "end_date": "20240331",
                "ann_date": "20240430",
                "netprofit_yoy": 1.0,
            },
            {
                "end_date": "20240930",
                "ann_date": "20241030",
                "netprofit_yoy": 3.0,
            },
        ]
        normalized = handler._normalize_single_stock_data(context, result, "000001.SZ")
        rows = normalized["data"]
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[0]["ann_date"], "20240430")
        self.assertEqual(rows[-1]["ann_date"], "20241030")
        self.assertEqual(rows[-1]["quarter"], "2024Q3")

    def test_normalize_skips_rows_without_ann_date(self):
        handler, config = _handler_with_mapping()
        context = {"config": config}
        result = [{"end_date": "20240331", "netprofit_yoy": 1.0}]
        normalized = handler._normalize_single_stock_data(context, result, "000001.SZ")
        self.assertEqual(normalized["data"], [])


if __name__ == "__main__":
    unittest.main()
