"""stock_moneyflow handler 单元测试。"""
from unittest.mock import MagicMock

from core.modules.data_source.data_class.api_job import ApiJob
from core.modules.data_source.data_class.api_job_bundle import ApiJobBundle
from userspace.extensions.data_source.handlers.stock_moneyflow.handler import StockMoneyflowHandler


def _make_handler():
    return StockMoneyflowHandler(
        data_source_key="stock_moneyflow",
        schema={},
        config=MagicMock(),
        providers={},
    )


def test_on_before_fetch_expands_trading_days():
    handler = _make_handler()
    base = ApiJob(
        api_name="moneyflow",
        provider_name="tushare",
        method="get_moneyflow",
        params={},
    )
    bundle = ApiJobBundle(bundle_id="stock_moneyflow_batch", apis=[base])

    calendar = MagicMock()
    calendar.load_open_dates.return_value = ["20250611", "20250612"]

    context = {
        "_entity_date_ranges": {"_global": ("20250611", "20250612")},
        "latest_completed_trading_date": "20250612",
        "data_manager": MagicMock(calendar=calendar),
    }

    jobs = handler.on_before_fetch(context, [bundle])
    assert len(jobs) == 2
    assert jobs[0].params["trade_date"] == "20250611"
    assert jobs[0].job_id == "stock_moneyflow_20250611"
    assert jobs[1].params["trade_date"] == "20250612"


def test_on_after_fetch_groups_by_trade_date():
    handler = _make_handler()
    import pandas as pd

    df = pd.DataFrame(
        [{"ts_code": "000001.SZ", "trade_date": "20250612", "net_mf_amount": 100.0}]
    )
    out = handler.on_after_fetch(
        {},
        {"stock_moneyflow_20250612": df},
        [],
    )
    assert "moneyflow" in out
    assert "20250612" in out["moneyflow"]
    assert len(out["moneyflow"]["20250612"]) == 1
