"""
个股资金流向 Handler（stock_moneyflow）

Tushare moneyflow：按 trade_date 全市场一次，写入 sys_stock_moneyflow。
"""
from typing import Any, Dict, List, Optional
import logging

from core.modules.data_source.base_class.base_handler import BaseHandler
from core.modules.data_source.base_class.base_provider import BaseProvider
from core.modules.data_source.data_class.api_job import ApiJob
from core.modules.data_source.data_class.api_job_bundle import ApiJobBundle
from core.modules.data_source.data_class.config import DataSourceConfig
from core.modules.data_source.service.normalization import normalization_helper as nh
from core.utils.date.date_utils import DateUtils


logger = logging.getLogger(__name__)

_JOB_ID_PREFIX = "stock_moneyflow_"


class StockMoneyflowHandler(BaseHandler):
    """个股资金流向 Handler，绑定表 sys_stock_moneyflow。"""

    def __init__(
        self,
        data_source_key: str,
        schema,
        config: DataSourceConfig,
        providers: Dict[str, BaseProvider],
        depend_on_data_source_names: List[str] = None,
    ):
        super().__init__(
            data_source_key,
            schema,
            config,
            providers,
            depend_on_data_source_names or [],
        )

    def on_before_fetch(self, context: Dict[str, Any], apis: List) -> List:
        """将全局 (start_date, end_date) 展开为每个开市日一个 moneyflow(trade_date) 任务。"""
        base_api = self._extract_base_api(apis)
        if not base_api:
            return apis

        entity_date_ranges = context.get("_entity_date_ranges") or {}
        global_range = entity_date_ranges.get("_global")
        if not global_range:
            logger.warning("stock_moneyflow：无 _global 日期区间，跳过")
            return []

        start_date, end_date = global_range
        start_date = str(start_date or "").strip()
        end_date = str(end_date or context.get("latest_completed_trading_date") or "").strip()
        if not start_date or not end_date or start_date > end_date:
            logger.info("stock_moneyflow：日期区间为空或无效 start=%s end=%s", start_date, end_date)
            return []

        data_manager = context.get("data_manager")
        open_dates = []
        if data_manager and getattr(data_manager, "calendar", None):
            open_dates = data_manager.calendar.load_open_dates(start_date, end_date)
        if not open_dates:
            cur = start_date
            while cur <= end_date:
                open_dates.append(cur)
                cur = DateUtils.add_days(cur, 1)

        expanded: List[ApiJob] = []
        for trade_date in open_dates:
            expanded.append(
                ApiJob(
                    api_name=base_api.api_name,
                    provider_name=base_api.provider_name,
                    method=base_api.method,
                    params={
                        **(base_api.params or {}),
                        "trade_date": trade_date,
                    },
                    api_params=base_api.api_params,
                    depends_on=base_api.depends_on,
                    rate_limit=base_api.rate_limit,
                    job_id=f"{_JOB_ID_PREFIX}{trade_date}",
                )
            )
        logger.info("✅ stock_moneyflow：为 %s 个交易日生成拉取任务", len(expanded))
        return expanded

    @staticmethod
    def _extract_base_api(apis: List) -> Optional[ApiJob]:
        if not apis:
            return None
        first = apis[0]
        if isinstance(first, ApiJobBundle):
            return first.apis[0] if first.apis else None
        if isinstance(first, ApiJob):
            return first
        return None

    def on_after_fetch(
        self,
        context: Dict[str, Any],
        fetched_data: Dict[str, Any],
        apis: List[ApiJob],
    ) -> Dict[str, Any]:
        """{ job_id: df } → { moneyflow: { trade_date: records } }。"""
        unified: Dict[str, Dict[str, Any]] = {"moneyflow": {}}
        for job_id, result in (fetched_data or {}).items():
            if not isinstance(job_id, str) or not job_id.startswith(_JOB_ID_PREFIX):
                continue
            trade_date = job_id[len(_JOB_ID_PREFIX) :]
            if not trade_date:
                continue
            records = nh.result_to_records(result)
            if records:
                unified["moneyflow"][trade_date] = records
        return unified

    def on_after_mapping(
        self, context: Dict[str, Any], mapped_records: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        if not mapped_records:
            return mapped_records
        mapped_records = self.filter_records_by_required_fields(
            mapped_records, required_fields=["id", "date"]
        )
        logger.info("✅ stock_moneyflow 映射完成，共 %s 条", len(mapped_records))
        return mapped_records

    def normalize_data(self, context: Dict[str, Any], fetched_data: Any) -> Dict[str, Any]:
        config = context.get("config")
        if config and config.get_save_mode() in ("immediate", "batch"):
            return {"data": []}
        return super().normalize_data(context, fetched_data)
