"""
交易日历 Handler：Tushare trade_cal（SSE）→ sys_trade_calendar。

全量 refresh：start_date 来自 data.json（合并 core 默认），不传 end_date；
Tushare 返回到其自然上界（含未来日历）。与 default_end_date 无关。
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
import logging

from core.infra.project_context import ConfigManager
from core.modules.data_source.base_class.base_handler import BaseHandler
from core.utils.date.date_utils import DateUtils

from .config import CACHE_KEY_LAST_SYNC, MARKET_SSE, RENEW_IF_OVER_DAYS


logger = logging.getLogger(__name__)


class TradeCalendarHandler(BaseHandler):
    """A 股交易日历（SSE 全市场统一历）。"""

    @staticmethod
    def _renew_skip_threshold_days(context: Dict[str, Any]) -> int:
        config = context.get("config")
        if config is not None:
            threshold = config.get_over_time_threshold()
            if threshold is not None and threshold > 0:
                return int(threshold)
        return RENEW_IF_OVER_DAYS

    @staticmethod
    def _last_sync_yyyymmdd(context: Dict[str, Any]) -> str:
        dm = context.get("data_manager")
        if not dm:
            return ""
        try:
            cache = dm.db_cache.load(CACHE_KEY_LAST_SYNC, field="json")
            if not cache:
                return ""
            synced_at = str(cache.get("synced_at") or "").strip()
            if not synced_at:
                return ""
            return DateUtils.str_to_format(
                synced_at, DateUtils.FMT_YYYYMMDD, DateUtils.FMT_DATETIME
            )
        except Exception:
            return ""

    def on_before_run(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if context.get("force_refresh"):
            logger.info("trade_calendar force_refresh：跳过 sync 频率限制")
            return None

        threshold_days = self._renew_skip_threshold_days(context)
        last_sync = self._last_sync_yyyymmdd(context)
        if not last_sync:
            return None

        try:
            days_since = DateUtils.diff_days(last_sync, DateUtils.today())
        except Exception:
            return None

        if days_since < threshold_days:
            logger.info(
                "trade_calendar 距上次 sync %s 天（<%s 天），跳过 renew；"
                "上次 sync=%s；强制更新请用 renew --renew-force",
                days_since,
                threshold_days,
                last_sync,
            )
            return {"data": []}

        return None

    @staticmethod
    def _resolve_sync_start_date() -> str:
        """userspace/config/data.json default_start_date；未配置则用 core 合并后的系统默认。"""
        start = str(ConfigManager.get_default_start_date() or "").strip()
        if start:
            return start
        fallback = str(DateUtils.DEFAULT_START_DATE or "").strip()
        if fallback:
            return fallback
        return "20080101"

    def on_prepare_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        context = super().on_prepare_context(context)
        start_date = self._resolve_sync_start_date()
        context["start_date"] = start_date
        context.pop("end_date", None)
        logger.info(
            "trade_calendar 拉取：start=%s，end=（不传，由 Tushare 决定上界；market=%s）",
            start_date,
            MARKET_SSE,
        )
        return context

    def _calculate_entity_date_ranges(
        self, last_update_map: Dict[str, Optional[str]]
    ) -> Dict[str, Tuple[str, Optional[str]]]:
        start_date = str(self.context.get("start_date") or "").strip()
        if not start_date:
            return super()._calculate_entity_date_ranges(last_update_map)
        end_date = self.context.get("end_date")
        if end_date is not None and not str(end_date).strip():
            end_date = None
        return {"_global": (start_date, end_date)}

    def on_after_mapping(
        self,
        context: Dict[str, Any],
        mapped_records: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for item in mapped_records:
            cal_date = str(item.get("cal_date") or "").strip().replace("-", "")
            if len(cal_date) != 8 or not cal_date.isdigit():
                continue
            raw_open = item.get("is_open")
            try:
                is_open = int(raw_open)
            except (TypeError, ValueError):
                continue
            if is_open not in (0, 1):
                continue
            rows.append(
                {
                    "market": MARKET_SSE,
                    "cal_date": cal_date,
                    "is_open": is_open,
                }
            )
        logger.info("trade_calendar 映射有效行：%s", len(rows))
        return rows

    def on_before_save(
        self,
        context: Dict[str, Any],
        normalized_data: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        if self._is_dry_run():
            return normalized_data

        data_manager = context.get("data_manager")
        model = data_manager.get_table("sys_trade_calendar")
        deleted = model.delete("market = %s", (MARKET_SSE,))
        logger.info("trade_calendar 清空 %s 旧记录：%s 行", MARKET_SSE, deleted)

        start_date = str(context.get("start_date") or "")
        end_date = context.get("end_date")
        try:
            data_manager.db_cache.save(
                CACHE_KEY_LAST_SYNC,
                json={
                    "market": MARKET_SSE,
                    "start_date": start_date,
                    "end_date": str(end_date).strip() if end_date else None,
                    "end_date_omitted": end_date is None
                    or not str(end_date or "").strip(),
                    "synced_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "row_count": len((normalized_data or {}).get("data") or []),
                },
            )
        except Exception as e:
            logger.warning("trade_calendar 写入 sys_cache 失败: %s", e)

        return normalized_data
