"""
新浪财经 Provider 实现

纯 API 封装，不包含业务逻辑。

历史 ``api.finance.sina.com.cn/stock/hs_kline.json`` 已返回 ``{"msg":"404"}``；
现使用 ``money.finance.sina.com.cn`` 的 ``CN_MarketData.getKLineData``，并规范为
``{"data": [["日期", "开盘", "最高", "最低", "收盘", "成交量"], ...]}`` 供 CalendarService 解析。
"""
import requests
from typing import Dict, Any, List
import logging

from core.modules.data_source.base_class.base_provider import BaseProvider


logger = logging.getLogger(__name__)

# 旧端点（已 404），保留常量便于排查
_LEGACY_KLINE_URL = "http://api.finance.sina.com.cn/stock/hs_kline.json"
# 当前可用：日 K scale=240
_KLINE_URL = (
    "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
    "CN_MarketData.getKLineData"
)


class SinaProvider(BaseProvider):
    """
    新浪财经 数据提供者

    纯 API 封装，不包含业务逻辑。
    """

    provider_name = "sina"
    requires_auth = False
    auth_type = None

    api_limits = {
        "get_daily_kline": 60,
    }

    default_rate_limit = 60

    def _initialize(self):
        """初始化新浪财经 Provider（无需认证）"""
        self.base_url = _KLINE_URL
        self.default_headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Referer": "https://finance.sina.com.cn/",
        }

    @staticmethod
    def _normalize_kline_rows(raw: Any) -> List[List[str]]:
        """将 API 原始行转为 ``[日期, 开, 高, 低, 收, 量]`` 列表。"""
        if not isinstance(raw, list):
            return []
        rows: List[List[str]] = []
        for item in raw:
            if isinstance(item, dict):
                rows.append(
                    [
                        str(item.get("day") or item.get("date") or ""),
                        str(item.get("open", "")),
                        str(item.get("high", "")),
                        str(item.get("low", "")),
                        str(item.get("close", "")),
                        str(item.get("volume", "")),
                    ]
                )
            elif isinstance(item, (list, tuple)) and len(item) >= 1:
                rows.append([str(x) for x in item])
        return rows

    def get_daily_kline(
        self,
        symbol: str,
        datalen: int = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        获取日 K 线。

        Args:
            symbol: 新浪代码，如 ``sh000001``（上证指数）
            datalen: 返回条数上限

        Returns:
            ``{"data": [["YYYY-MM-DD", open, high, low, close, volume], ...]}``
        """
        try:
            params: Dict[str, str] = {
                "symbol": symbol,
                "scale": "240",
                "ma": "no",
            }
            if datalen is not None:
                params["datalen"] = str(datalen)

            response = requests.get(
                self.base_url,
                params=params,
                headers=self.default_headers,
                timeout=15,
            )
            response.raise_for_status()
            payload = response.json()

            if isinstance(payload, dict):
                if payload.get("msg") in ("404", 404):
                    raise ValueError(
                        f"新浪财经 K 线接口不可用（legacy 已下线）: {_LEGACY_KLINE_URL}"
                    )
                if "data" in payload:
                    rows = self._normalize_kline_rows(payload.get("data"))
                elif "result" in payload and isinstance(payload["result"], dict):
                    inner = payload["result"].get("data")
                    rows = self._normalize_kline_rows(inner)
                else:
                    raise ValueError(f"新浪财经 API 返回未知结构: {list(payload.keys())}")
            elif isinstance(payload, list):
                rows = self._normalize_kline_rows(payload)
            else:
                raise ValueError(f"新浪财经 API 返回类型异常: {type(payload).__name__}")

            if not rows:
                raise ValueError("新浪财经 API 未返回 K 线数据")

            return {"data": rows}

        except requests.exceptions.RequestException as e:
            raise self.handle_error(e, "get_daily_kline")
        except Exception as e:
            raise self.handle_error(e, "get_daily_kline")
