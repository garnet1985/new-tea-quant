"""
Tushare Provider 实现

纯 API 封装，不包含业务逻辑
"""
import tushare as ts
from typing import Dict, Any, Optional
import logging

from core.modules.data_source.base_class.base_provider import BaseProvider


logger = logging.getLogger(__name__)


class TushareProvider(BaseProvider):
    """
    Tushare 数据提供者
    
    纯 API 封装，不包含业务逻辑
    """
    
    provider_name = "tushare"
    requires_auth = True
    auth_type = "token"

    # 各 API 限流（每分钟请求数）— 全项目唯一配置源，Handler config 不再重复声明
    # Tushare 对每个接口分别限流，daily/weekly/monthly 各自独立计数
    api_limits = {
        "get_stock_list": 800,          # 股票列表（单状态 stock_basic）
        "get_stock_list_full": 800,     # 股票列表 L+D+P 合并
        "get_namechange": 800,          # 股票曾用名 / ST 时段
        "get_daily_kline": 700,         # 日线数据
        "get_weekly_kline": 700,        # 周线数据
        "get_monthly_kline": 700,       # 月线数据
        "get_daily_basic": 500,         # 日线基本面 daily_basic（Tushare 500次/分钟）
        "get_moneyflow": 500,           # 个股资金流向 moneyflow
        "get_adj_factor": 800,          # 复权因子，使用K线限流
        "get_finance_data": 500,        # 财务数据（fina_indicator接口限制500次/分钟）
        "get_trade_cal": 200,           # 交易日历，宏观数据接口限制200次/分钟
        "get_gdp": 200,                 # GDP数据，宏观数据接口限制200次/分钟
        "get_cpi": 200,                 # CPI数据，宏观数据接口限制200次/分钟
        "get_ppi": 200,                 # PPI数据，宏观数据接口限制200次/分钟
        "get_pmi": 200,                 # PMI数据，宏观数据接口限制200次/分钟
        "get_shibor": 200,              # Shibor数据，宏观数据接口限制200次/分钟
        "get_lpr": 200,                 # LPR数据，宏观数据接口限制200次/分钟
        "get_money_supply": 200,        # 货币供应量，宏观数据接口限制200次/分钟
        "get_moneyflow_ind_ths": 200,   # 行业资金流向，宏观数据接口限制200次/分钟
        "get_index_daily": 500,         # 指数日线，指数接口限制500次/分钟
        "get_index_weekly": 500,        # 指数周线，指数接口限制500次/分钟
        "get_index_monthly": 500,       # 指数月线，指数接口限制500次/分钟
        "get_index_weight": 200,        # 指数权重，指数接口限制200次/分钟
    }
    
    default_rate_limit = 200  # 默认限流（保守值）
    
    def _initialize(self):
        """初始化 Tushare API 客户端"""
        token = self.config.get("token")
        if not token:
            raise ValueError("Tushare token is required")
        
        ts.set_token(token)
        self.api = ts.pro_api()

    _RETRY_ATTEMPTS = 5
    _RETRY_BASE_DELAY = 2.5

    def _call(self, api_name: str, fn):
        """Tushare HTTP 调用统一走指数退避重试（DNS/连接瞬时故障）。"""
        return self.invoke_with_retry(
            api_name,
            fn,
            max_retries=self._RETRY_ATTEMPTS,
            base_delay=self._RETRY_BASE_DELAY,
        )
    
    # ========== API 方法（纯封装）==========
    
    def get_stock_list(self, **kwargs):
        """
        获取股票列表（单次 stock_basic，可传 list_status）

        Tushare API: stock_basic
        """
        return self._call("get_stock_list", lambda: self.api.stock_basic(**kwargs))

    def get_stock_list_full(self, **kwargs):
        """
        获取 L/D/P 全量股票列表（三次 stock_basic 合并去重）。

        kwargs 中 list_status / list_statuses 由本方法接管，勿与单次拉取混用。
        """
        import pandas as pd

        def _fetch():
            params = dict(kwargs)
            params.pop("list_status", None)
            statuses = params.pop("list_statuses", ("L", "D", "P"))
            frames = []
            for status in statuses:
                df = self.api.stock_basic(list_status=status, **params)
                if df is not None and not df.empty:
                    frames.append(df)
            if not frames:
                return pd.DataFrame()
            merged = pd.concat(frames, ignore_index=True)
            if "ts_code" in merged.columns:
                merged = merged.drop_duplicates(subset=["ts_code"], keep="first")
            return merged

        return self._call("get_stock_list_full", _fetch)

    def get_namechange(self, ts_code: str = "", **kwargs):
        """
        股票曾用名（含 ST 简称段及 start_date/end_date）。

        Tushare API: namechange
        注意：接口的 start_date/end_date 参数按公告日过滤，同步 ST 时段时应只传 ts_code。
        """
        params = dict(kwargs)
        if ts_code:
            params["ts_code"] = ts_code
        return self._call("get_namechange", lambda: self.api.namechange(**params))
    
    def get_daily_kline(self, ts_code: str, start_date: str, end_date: str, **kwargs):
        """
        获取日线数据
        
        Tushare API: daily
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 日线数据
        """
        return self._call(
            "get_daily_kline",
            lambda: self.api.daily(
                ts_code=ts_code,
                start_date=start_date,
                end_date=end_date,
                **kwargs,
            ),
        )
    
    def get_weekly_kline(self, ts_code: str, start_date: str, end_date: str, **kwargs):
        """
        获取周线数据
        
        Tushare API: weekly
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 周线数据
        """
        return self._call(
            "get_weekly_kline",
            lambda: self.api.weekly(
                ts_code=ts_code,
                start_date=start_date,
                end_date=end_date,
                **kwargs,
            ),
        )
    
    def get_monthly_kline(self, ts_code: str, start_date: str, end_date: str, **kwargs):
        """
        获取月线数据
        
        Tushare API: monthly
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 月线数据
        """
        return self._call(
            "get_monthly_kline",
            lambda: self.api.monthly(
                ts_code=ts_code,
                start_date=start_date,
                end_date=end_date,
                **kwargs,
            ),
        )
    
    def get_adj_factor(self, ts_code: str, start_date: str, end_date: str, **kwargs):
        """
        获取复权因子
        
        Tushare API: adj_factor
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 复权因子数据
        """
        return self._call(
            "get_adj_factor",
            lambda: self.api.adj_factor(
                ts_code=ts_code,
                start_date=start_date,
                end_date=end_date,
                **kwargs,
            ),
        )
    
    def get_finance_data(self, ts_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取财务数据
        
        Tushare API: fina_indicator
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD) 或季度 (YYYYQ[1-4])
            end_date: 结束日期 (YYYYMMDD) 或季度 (YYYYQ[1-4])
        
        Returns:
            DataFrame: 财务数据
        """
        def _fetch():
            params = {"ts_code": ts_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.fina_indicator(**params)

        return self._call("get_finance_data", _fetch)
    
    def get_gdp(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 GDP 数据
        
        Tushare API: cn_gdp
        
        Args:
            start_date: 开始季度 (YYYYQ[1-4])，会转换为 start_q 参数
            end_date: 结束季度 (YYYYQ[1-4])，会转换为 end_q 参数
        
        Returns:
            DataFrame: GDP数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_q"] = start_date
            if end_date:
                params["end_q"] = end_date
            return self.api.cn_gdp(**params)

        return self._call("get_gdp", _fetch)
    
    def get_cpi(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 CPI 数据
        
        Tushare API: cn_cpi
        
        Args:
            start_date: 开始月份 (YYYYMM)，会转换为 start_m 参数
            end_date: 结束月份 (YYYYMM)，会转换为 end_m 参数
        
        Returns:
            DataFrame: CPI数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_m"] = start_date
            if end_date:
                params["end_m"] = end_date
            return self.api.cn_cpi(**params)

        return self._call("get_cpi", _fetch)
    
    def get_ppi(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 PPI 数据
        
        Tushare API: cn_ppi
        
        Args:
            start_date: 开始月份 (YYYYMM)，会转换为 start_m 参数
            end_date: 结束月份 (YYYYMM)，会转换为 end_m 参数
        
        Returns:
            DataFrame: PPI数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_m"] = start_date
            if end_date:
                params["end_m"] = end_date
            return self.api.cn_ppi(**params)

        return self._call("get_ppi", _fetch)
    
    def get_pmi(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 PMI 数据
        
        Tushare API: cn_pmi
        
        Args:
            start_date: 开始月份 (YYYYMM)，会转换为 start_m 参数
            end_date: 结束月份 (YYYYMM)，会转换为 end_m 参数
        
        Returns:
            DataFrame: PMI数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_m"] = start_date
            if end_date:
                params["end_m"] = end_date
            return self.api.cn_pmi(**params)

        return self._call("get_pmi", _fetch)
    
    def get_shibor(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 Shibor 数据
        
        Tushare API: shibor
        
        Args:
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: Shibor数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.shibor(**params)

        return self._call("get_shibor", _fetch)
    
    def get_lpr(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取 LPR 数据
        
        Tushare API: shibor_lpr
        
        Args:
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: LPR数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.shibor_lpr(**params)

        return self._call("get_lpr", _fetch)
    
    def get_daily_basic(self, ts_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取日线基本面数据
        
        Tushare API: daily_basic
        
        Args:
            ts_code: 股票代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 日线基本面数据
        """
        def _fetch():
            params = {"ts_code": ts_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.daily_basic(**params)

        return self._call("get_daily_basic", _fetch)

    def get_moneyflow(
        self,
        trade_date: str = None,
        ts_code: str = None,
        start_date: str = None,
        end_date: str = None,
        **kwargs,
    ):
        """
        获取个股资金流向数据

        Tushare API: moneyflow

        全市场按日：trade_date=YYYYMMDD；单股区间：ts_code + start_date/end_date。
        """
        def _fetch():
            params = {**kwargs}
            if trade_date:
                params["trade_date"] = trade_date
            if ts_code:
                params["ts_code"] = ts_code
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.moneyflow(**params)

        return self._call("get_moneyflow", _fetch)
    
    def get_money_supply(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取货币供应量数据
        
        Tushare API: cn_m
        
        Args:
            start_date: 开始月份 (YYYYMM)，会转换为 start_m 参数
            end_date: 结束月份 (YYYYMM)，会转换为 end_m 参数
        
        Returns:
            DataFrame: 货币供应量数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_m"] = start_date
            if end_date:
                params["end_m"] = end_date
            return self.api.cn_m(**params)

        return self._call("get_money_supply", _fetch)
    
    def get_trade_cal(self, exchange: str = '', start_date: str = None, end_date: str = None, **kwargs):
        """
        获取交易日历
        
        Tushare API: trade_cal
        
        Args:
            exchange: 交易所代码（空字符串表示所有交易所）
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 交易日历数据，包含 cal_date 和 is_open 字段
        """
        params = {"exchange": exchange or "SSE", **kwargs}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        return self._call("get_trade_cal", lambda: self.api.trade_cal(**params))
    
    def get_moneyflow_ind_ths(self, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取行业资金流向数据（同花顺）
        
        Tushare API: moneyflow_ind_ths
        
        Args:
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 行业资金流向数据
        """
        def _fetch():
            params = kwargs.copy()
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.moneyflow_ind_ths(**params)

        return self._call("get_moneyflow_ind_ths", _fetch)
    
    def get_index_daily(self, ts_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取指数日线数据
        
        Tushare API: index_daily
        
        Args:
            ts_code: 指数代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 指数日线数据
        """
        def _fetch():
            params = {"ts_code": ts_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.index_daily(**params)

        return self._call("get_index_daily", _fetch)
    
    def get_index_weekly(self, ts_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取指数周线数据
        
        Tushare API: index_weekly
        
        Args:
            ts_code: 指数代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 指数周线数据
        """
        def _fetch():
            params = {"ts_code": ts_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.index_weekly(**params)

        return self._call("get_index_weekly", _fetch)
    
    def get_index_monthly(self, ts_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取指数月线数据
        
        Tushare API: index_monthly
        
        Args:
            ts_code: 指数代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 指数月线数据
        """
        def _fetch():
            params = {"ts_code": ts_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.index_monthly(**params)

        return self._call("get_index_monthly", _fetch)
    
    def get_index_weight(self, index_code: str, start_date: str = None, end_date: str = None, **kwargs):
        """
        获取指数成分股权重数据
        
        Tushare API: index_weight
        
        Args:
            index_code: 指数代码
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD)
        
        Returns:
            DataFrame: 指数成分股权重数据
        """
        def _fetch():
            params = {"index_code": index_code, **kwargs}
            if start_date:
                params["start_date"] = start_date
            if end_date:
                params["end_date"] = end_date
            return self.api.index_weight(**params)

        return self._call("get_index_weight", _fetch)
