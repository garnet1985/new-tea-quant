# 标签场景（`userspace/extensions/tags/`）

这里是**标签用户空间**：定义「要算什么标签」（`settings.py`）和「怎么算」（`tag_worker.py`），框架负责按日期和实体批量执行并落库。

## 三个概念

- **scenario（场景）**：一套相关标签的业务问题，对应一个目录；**系统 ID = 目录路径**（如 `demo/market_cap_tier`）
- **tag（标签）**：场景内的一个分类维度（如 `market_cap_tier`）
- **tag_value**：某实体在某日写入的标签值（JSON，常见形态 `{"value": ...}`）

Tag 的用途：Strategy 复用已算好的特征，避免重复算因子；投资上也可作为可复用的判断结论。

当前 userspace **仅支持 `entity_based`**（贴附在实体时间序列上）。`general` 类宏观标签尚未对用户开放同等配置形态。

---

## 一分钟上手

1. 打开 [`demo/market_cap_tier/settings.py`](demo/market_cap_tier/settings.py)，确认 `"is_enabled": True`
2. 仓库根目录执行：

```bash
python cli.py tag --scenario demo/market_cap_tier
```

跑所有已启用场景：

```bash
python cli.py tag
```

---

## 从 0 新建场景

### Step 1）复制模板

```bash
python cli.py -t -new my_scenario
```

或手动复制：

```bash
cp -R userspace/extensions/tags/_template/empty_scenario userspace/extensions/tags/my_scenario
```

或手动建目录：

```text
userspace/extensions/tags/my_scenario/
├── settings.py
└── tag_worker.py
```

### Step 2）写 `settings.py`

最少建议：`is_enabled`、`meta.display_name`、`data.base_required_data`、`tags`。  
完整字段见 [`settings_example.py`](settings_example.py) 或 [`_template/empty_scenario/settings.py`](_template/empty_scenario/settings.py)。

要点：

- **不要**在根级写 `name` — 由目录路径决定 `tag_key`
- 计算区间 / 更新模式 → `calculation`（`update_mode`、`execution_mode`、`recompute` 等）
- 数据声明 → `data.base_required_data` + `extra_required_data_sources` + `min_required_records`
- 业务阈值 → `core`（worker 自行读取）
- **不要**写 `performance` — 见 `worker.json` → `job_pipeline.tag`

### Step 3）写 `tag_worker.py`

继承 `BaseTagWorker`，实现 `calculate_tag(...)`。  
[`_template/empty_scenario/tag_worker.py`](_template/empty_scenario/tag_worker.py) 已列出常用钩子。

### Step 4）运行

```bash
python cli.py tag --scenario my_scenario
```

---

## 目录结构

```text
userspace/extensions/tags/
├── README.md
├── USER_GUIDE.md
├── settings_example.py      # 配置字段 SOT
├── _template/               # 可复制模板（不参与 discovery）
│   └── empty_scenario/
└── demo/
    └── market_cap_tier/     # 市值档位示例
        ├── settings.py
        └── tag_worker.py
```

---

## 更多说明

- 用户指南：[USER_GUIDE.md](USER_GUIDE.md)
- 模块设计：`core/modules/tag/README.md`
