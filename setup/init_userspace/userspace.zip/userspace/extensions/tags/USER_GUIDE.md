# 标签用户指南（userspace）

本指南给「要自己写标签场景」的用户：快速跑通一个场景，并知道如何从示例扩展到可复用资产。

配置字段的完整说明见同目录 [`settings_example.py`](settings_example.py)（SOT）。

---

## 1. 标签场景由什么组成？

每个场景目录通常两份核心文件：

- `settings.py` — 声明算什么、需要什么数据、怎么更新
- `tag_worker.py` — 实现每个业务日的标签计算逻辑

框架负责：发现与调度、按实体/日期并发、结果落库。  
你负责：标签定义与业务计算。

目录在 `userspace/extensions/tags/` 下；**场景 ID（`tag_key`）= 相对该目录的路径**，例如 `demo/market_cap_tier`。  
不要在 `settings.py` 根级写 `name`，展示名写在 `meta.display_name`。

---

## 2. 当前支持的类型

- **`entity_based`（V1 唯一支持）**：标签贴附在某个实体时间序列上（如每只股票一条 tag 链）
- **`general`**：宏观/全局类标签 — 配置形态尚未对用户开放，勿手写

`data.base_required_data` 须为 **PER_ENTITY + TIME_SERIES** 的 `DataKey`（如日 K、指标、指数 K 线等）。框架据此推导 `target_entity` 与 tag 时间轴。

---

## 3. 最小可运行模板

目录：

```text
userspace/extensions/tags/my_scenario/
├── settings.py
└── tag_worker.py
```

`settings.py` 示例：

```python
Settings = {
    "is_enabled": True,
    "meta": {
        "display_name": "我的标签场景",
        "description": "demo",
    },
    "core": {},
    "calculation": {
        "update_mode": "incremental",
        "recompute": False,
        "execution_mode": "entity_timeline",
        "start_date": "",
        "end_date": "",
    },
    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
        },
        "extra_required_data_sources": [],
        "min_required_records": 0,
    },
    "tags": [
        {
            "name": "my_tag",
            "display_name": "我的标签",
            "description": "demo",
        },
    ],
}
```

`tag_worker.py` 示例：

```python
from typing import Any, Dict, Optional

from core.modules.tag.engines.shared.base_worker import BaseTagWorker


class MyTagWorker(BaseTagWorker):
    def calculate_tag(
        self,
        as_of_date: str,
        historical_data: Dict[str, Any],
        tag_definition: Any,
    ) -> Optional[Dict[str, Any]]:
        klines = historical_data.get("stock.kline.daily", [])
        if not klines:
            return None
        latest = klines[-1]
        # 落库值为 JSON；标量建议 {"value": ...}
        return {"value": {"as_of_date": as_of_date, "close": latest.get("close")}}
```

---

## 4. 运行命令

仓库根目录：

```bash
python cli.py tag
python cli.py tag --scenario demo/market_cap_tier
```

`--scenario` 填 **目录路径**（`tag_key`），不是 `meta.display_name`。

并发与分片等运行时性能在 `core/default_config/worker.json` → `job_pipeline.tag`；scenario 的 `settings.py` **不要**写 `performance` 块。

---

## 5. 参考示例

| 路径 | 说明 |
|------|------|
| [`demo/market_cap_tier/`](demo/market_cap_tier/) | 市值档位 low/mid/high，仅在档位变化日写入 |
| [`settings_example.py`](settings_example.py) | 各字段注释与默认值 |

---

## 6. 常见问题

### Q1：场景没被执行？

- 检查 `Settings["is_enabled"]`
- `--scenario` 是否与目录路径一致（如 `demo/market_cap_tier`）

### Q2：`historical_data` 里没有你要的数据？

- 检查 `data.base_required_data` / `extra_required_data_sources` 的 `data_id`
- 检查 worker 里 `historical_data` 的 key 是否与 Data Contract 一致

### Q3：标签写入太多？

- 仅在状态变化时返回非 `None`（参考 `demo/market_cap_tier`）
- `tags[].name` 保持稳定，避免历史定义混乱

### Q4：开发环境只有 500 只股票？

- `userspace/system/config/data.json` 里 `use_sample_stock_list` 会**全局**限制股票池（读 `stock.list`、写 per-stock 表均生效）
- 详见 [`system/config/README.md`](../../system/config/README.md)

---

## 7. 相关文档

- 入口：[README.md](README.md)
- 模块设计：`core/modules/tag/README.md`
- 策略 settings 对照：`userspace/strategies/settings_example.py`（`data` / `calculation` 命名风格类似）
