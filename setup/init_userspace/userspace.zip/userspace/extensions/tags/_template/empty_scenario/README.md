# 空白 Tag 场景模板（`_template/empty_scenario/`）

可直接复制改动的 Tag 起点。**不会**出现在 CLI / discovery 列表（跳过 `_` 开头目录）。

## 怎么用

```bash
cp -R userspace/extensions/tags/_template/empty_scenario userspace/extensions/tags/my_scenario
# 或
python cli.py -t -new my_scenario
```

然后：

1. 改 `settings.py`：`is_enabled: True`、`meta.display_name`、`tags` 等（顶层变量名保持 `Settings`）
2. 改 `tag_worker.py`：重命名 `EmptyTagWorker`，实现 `calculate_tag`
3. 按需删减 settings 块、删除未使用的 worker 钩子

## 文件说明

| 文件 | 作用 |
|------|------|
| `settings.py` | 与 [`settings_example.py`](../../settings_example.py) 同步的完整配置示例 |
| `tag_worker.py` | 常用钩子骨架，主逻辑为空 |

字段说明以 [`settings_example.py`](../../settings_example.py) 为准。

[← Tag 用户空间](../../README.md)
