# 空白 Tag 场景模板 — 复制整个 empty_scenario/ 到新目录后改名、改 meta、实现 tag_worker。
# 字段说明见 ../../settings_example.py（与本文件内容同步）。
# 系统不会扫描 _template/ 目录；复制后请将 is_enabled 设为 True。

Settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    # 必填，是否启用（discovery 扫描 / CLI 默认可选）
    "is_enabled": False,

    # 用户可见文档块；系统 tag_key 由目录路径决定，不在此填写 name
    "meta": {
        # 必填，UI / 报告展示名
        "display_name": "空白 Tag 场景模板",
        "description": "复制 _template/empty_scenario/ 到新目录后修改；本模板不写入任何 tag 值。",
        # 选填，默认 []；标签 / 检索用
        "keywords": ["示例"],         
        # 选填，默认 {}；结构化说明
        "details": {                  
            "logic": [
                "示例：在 example_tag_1 条件不满足时使用 example_tag_2",
            ],
        },
        # 选填，默认 []
        "category": ["your category"],  
    },

    # -----------------------------------------------------------------------
    # 2. core — scenario 私有参数（tag_worker 里读取）
    # -----------------------------------------------------------------------
    # 选填，默认 {}；键名由 worker 自行约定
    "core": {                       
        # "low_cap_max_threshold": 50.0,
    },

    # -----------------------------------------------------------------------
    # 3. calculation — 计算区间与执行模式（整段可省略）
    # -----------------------------------------------------------------------
    "calculation": {
        # 选填，默认 "incremental"
        # incremental — 在已有 tag 值基础上按区间延伸（日常跑批）
        # refresh     — 对目标区间按全量重算语义处理 tag 值（改逻辑 / 修历史后使用）
        "update_mode": "incremental",

        # 选填，默认 False。一次性运维开关：True 时本次运行等价 refresh，且可能重建 scenario 元数据
        # 与 update_mode 不同：recompute 不描述日常增量策略，仅用于开发修数 / 强制重建
        "recompute": False,

        # 选填，默认 "entity_timeline"
        # entity_timeline — 各实体按各自交易日推进（常规打标）
        # calendar_slice  — 日历切片 + on_calendar_asof（当前须 recompute=True 或 update_mode=refresh）
        "execution_mode": "entity_timeline",

        # 选填，默认 ""；计算起始日 YYYYMMDD，空字符串 = 系统默认起始日
        "start_date": "",

        # 选填，默认 ""；计算结束日 YYYYMMDD，空字符串 = 系统默认结束日（通常最新已完成交易日）
        "end_date": "",
    },

    # -----------------------------------------------------------------------
    # 4. data — 数据契约（与 strategy 命名对齐）
    # -----------------------------------------------------------------------
    "data": {
        # 必填。Tag 贴附在哪个实体时间序列上，同时驱动 tag 时间轴（= 原 tag_time_axis_based_on）
        # 须为 PER_ENTITY + TIME_SERIES 的 DataKey，例如：
        #   stock.kline.daily | stock.kline.weekly | stock.indicators.daily
        #   stock.finance.quarterly | index.kline.daily | index.weight.daily
        "base_required_data": {
            # 必填
            "data_id": "stock.kline.daily",  
            # 选填，默认 {}；依 data_id 而定
            "params": {                      
                # 选填，默认 qfq；可选 raw | hfq
                "adjust": "qfq",              
            },
            # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
            "indicators": {},
        },
        # 选填，默认 []；计算 tag 所需的辅助数据源（不含 base）
        "extra_required_data_sources": [
            {"data_id": "macro.gdp", "params": {}},
        ],
        # 选填，默认 0；calculation.update_mode=incremental 时须显式配置（可为 0）
        # as_of 之前至少需要的 history 条数（warmup / min bars）
        "min_required_records": 0,
    },

    # -----------------------------------------------------------------------
    # 5. tags — 标签定义（一个 scenario 下可多个 tag）
    # -----------------------------------------------------------------------
    # 必填，至少 1 项
    "tags": [                            
        {
            # 必填，机器识别码（对应 tag_definition.name）；字母数字下划线
            "name": "example_tag_1",     
            # 选填，默认与 name 相同
            "display_name": "example tag 1",  
            # 选填，默认 ""
            "description": "标签 1 说明",       
        },
        {
            "name": "example_tag_2",
            "display_name": "example tag 2",
            "description": "举例：当 example_tag_1 条件不满足时使用的互斥标签",
        },
    ],
}
