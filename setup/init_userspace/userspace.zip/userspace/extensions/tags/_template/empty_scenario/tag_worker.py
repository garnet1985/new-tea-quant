#!/usr/bin/env python3
"""空白 Tag 场景模板 — 复制后在此实现 calculate_tag 等钩子。"""

from __future__ import annotations

from typing import Any, Dict, Optional

from core.modules.tag.engines.shared.base_worker import BaseTagWorker
from core.modules.tag.models.tag_model import TagModel

__all__ = ["EmptyTagWorker"]


class EmptyTagWorker(BaseTagWorker):
    """
    空白 Tag Worker 模板。

    复制到新 scenario 目录后：
    1. 重命名本类（如 ``MarketCapTierTagWorker``）
    2. 在 ``calculate_tag`` 中实现打标逻辑
    3. 按需启用 ``on_calendar_asof``（``calculation.execution_mode: calendar_slice`` 时使用）
    4. 删除未使用的钩子
    """

    # ------------------------------------------------------------------
    # 打标主钩子
    # ------------------------------------------------------------------

    def calculate_tag(
        self,
        as_of_date: str,
        historical_data: Dict[str, Any],
        tag_definition: TagModel,
    ) -> Optional[Dict[str, Any]]:
        """
        计算单个 tag 值（必填）。

        entity_timeline：按实体时间轴逐日调用。
        calendar_slice：配合 ``on_calendar_asof`` 使用。

        返回 None 表示本日不写 tag；否则返回：
        ``{"value": ..., "start_date": "...", "end_date": "..."}``

        常用上下文：
        - ``self.entity`` — 当前实体 id / type
        - ``self.config`` — settings 字典（含 core / data）
        - ``self.tracker`` — 跨日临时状态
        - ``historical_data[data_id]`` — 按 data_id 索引的历史数据列表
        """
        _ = as_of_date, historical_data, tag_definition
        return None

    def on_calendar_asof(
        self,
        ctx,
        settings: Dict[str, Any],
    ):
        """
        日历横截面钩子（``calculation.execution_mode: calendar_slice`` 时生效）。

        ``ctx.stocks`` 为当日全市场数据视图；``ctx.carry`` 为跨日状态。
        默认：不写 tag，仅透传 carry。
        """
        return super().on_calendar_asof(ctx, settings)

    # ------------------------------------------------------------------
    # 生命周期钩子
    # ------------------------------------------------------------------

    def on_init(self) -> None:
        """Worker 实例化完成后调用。"""
        pass

    def on_before_execute_tagging(self) -> None:
        """开始遍历日期前调用；可初始化 tracker。"""
        pass

    def on_tag_created(
        self,
        as_of_date: str,
        tag_definition: TagModel,
        tag_value: Dict[str, Any],
    ) -> None:
        """calculate_tag 成功写入 tag 值后调用。"""
        pass

    def on_as_of_date_calculate_complete(self, as_of_date: str) -> None:
        """单个 as_of_date 全部 tag 计算完成后调用。"""
        pass

    def on_calculate_error(
        self,
        as_of_date: str,
        error: Exception,
        tag_definition: TagModel,
    ) -> bool:
        """calculate_tag 抛异常时调用；返回 False 可中止后续处理。"""
        return True

    def on_after_execute_tagging(self, result: Dict[str, Any]) -> None:
        """全部日期处理完成后调用。"""
        pass
