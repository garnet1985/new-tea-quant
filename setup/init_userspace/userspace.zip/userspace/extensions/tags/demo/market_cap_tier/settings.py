"""
市值档位 Tag 场景（settings.py）

按总市值将股票划分为 low / mid / high，仅在档位变化日写入 tag。
查询某日有效档位：取 as_of_date <= 查询日 的最后一条记录的 value。
"""
Settings = {
    "is_enabled": True,

    "meta": {
        "display_name": "市值分类",
        "description": "根据市值划分档位，仅在档位变化日写入"
    },

    "core": {
        # 阈值单位：亿元；库内 total_market_value 为万元
        "micro_cap_max_threshold": 10.0,
        "low_cap_max_threshold": 30.0,
        "mid_cap_max_threshold": 100.0,
    },

    "calculation": {
        "update_mode": "incremental",
        "recompute": True,
        "execution_mode": "entity_timeline",
        "start_date": "",
        "end_date": "",
    },

    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
        },
        "extra_required_data_sources": [
            {"data_id": "stock.indicators.daily", "params": {}},
        ],
        "min_required_records": 1,
    },

    "tags": [
        {
            "name": "market_cap_tier",
            "display_name": "市值",
            "description": (
                "micro：<= micro_cap_max_threshold（亿）；"
                "low / mid / high 依次递增；仅在档位变化日写入"
            ),
        },
    ],
}
