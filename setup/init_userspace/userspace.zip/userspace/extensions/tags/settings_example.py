# settings_example.py — Tag 配置字段说明（SOT；复制到正式 scenario 目录后按需删减）
#
# 新建 Tag scenario：复制 _template/empty_scenario/ 到新目录，或复制本文件到 userspace/extensions/tags/<your_path>/settings.py。
#
# 最少建议填写：is_enabled、meta.display_name、data.base_required_data、tags
# 其余块可整段省略，使用系统默认值。
#
# 系统 tag_key（日志、CLI --scenario、DB scenario.name）= 相对 userspace/extensions/tags/
# 的路径，例如目录 demo/market_cap_tier → tag_key 为 demo/market_cap_tier。
# 勿在 settings 根级写 name；展示名写在 meta.display_name。
#
# 复制为正式 settings.py 时，顶层变量名须为 Settings（discovery 加载 var_name="Settings"）。
#
# 使用 extra_required_data_sources 且引用 DataKey 时，可在 settings.py 顶部：
#   from core.modules.data_contract.contract_const import DataKey
#
# 约定摘要：
# - 计算区间、更新模式、执行模式：calculation（update_mode / execution_mode / recompute 等）
# - 数据声明：data.base_required_data（贴附实体 + 时间轴）+ extra_required_data_sources（辅助数据）
# - 并发、分片调度等运行时性能：core/default_config/worker.json → job_pipeline.tag
#   （scenario settings 不配置 performance 块；其中 update_mode 仅作 normalize 兜底默认，非用户主配置入口）
# - 当前仅支持 entity_based：base 须为 PER_ENTITY + TIME_SERIES 的 DataKey（如日 K、指标、指数 K 线等）
# - 框架自动推导（勿在 userspace 手写）：name、tag_target_type、target_entity、tag_time_axis_based_on

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    # 必填，是否启用（discovery 扫描 / CLI 默认可选）
    "is_enabled": True,              

    # 用户可见文档块；系统 tag_key 由目录路径决定，不在此填写 name
    "meta": {
        # 必填，UI / 报告展示名
        "display_name": "示例场景",   
        # 可选，但强烈建议填写
        "description": "场景说明：打标逻辑、适用实体、演示目的等。",
        # 选填，默认 []；标签 / 检索用
        "keywords": ["示例"],         
        # 选填，默认 {}；结构化说明
        "details": {                  
            "logic": [
                "示例：在 example_tag_1 条件不满足时使用 example_tag_2",
            ],
        },
        # 选填，默认 []
        "category": ["your category"],  
    },

    # -----------------------------------------------------------------------
    # 2. core — scenario 私有参数（tag_worker 里读取）
    # -----------------------------------------------------------------------
    # 选填，默认 {}；键名由 worker 自行约定
    "core": {                       
        # "low_cap_max_threshold": 50.0,
    },

    # -----------------------------------------------------------------------
    # 3. calculation — 计算区间与执行模式（整段可省略）
    # -----------------------------------------------------------------------
    "calculation": {
        # 选填，默认 "incremental"
        # incremental — 在已有 tag 值基础上按区间延伸（日常跑批）
        # refresh     — 对目标区间按全量重算语义处理 tag 值（改逻辑 / 修历史后使用）
        "update_mode": "incremental",

        # 选填，默认 False。一次性运维开关：True 时本次运行等价 refresh，且可能重建 scenario 元数据
        # 与 update_mode 不同：recompute 不描述日常增量策略，仅用于开发修数 / 强制重建
        "recompute": False,

        # 选填，默认 "entity_timeline"
        # entity_timeline — 各实体按各自交易日推进（常规打标）
        # calendar_slice  — 日历切片 + on_calendar_asof（当前须 recompute=True 或 update_mode=refresh）
        "execution_mode": "entity_timeline",

        # 选填，默认 ""；计算起始日 YYYYMMDD，空字符串 = 系统默认起始日
        "start_date": "",

        # 选填，默认 ""；计算结束日 YYYYMMDD，空字符串 = 系统默认结束日（通常最新已完成交易日）
        "end_date": "",
    },

    # -----------------------------------------------------------------------
    # 4. data — 数据契约（与 strategy 命名对齐）
    # -----------------------------------------------------------------------
    "data": {
        # 必填。Tag 贴附在哪个实体时间序列上，同时驱动 tag 时间轴（= 原 tag_time_axis_based_on）
        # 须为 PER_ENTITY + TIME_SERIES 的 DataKey，例如：
        #   stock.kline.daily | stock.kline.weekly | stock.indicators.daily
        #   stock.finance.quarterly | index.kline.daily | index.weight.daily
        "base_required_data": {
            # 必填
            "data_id": "stock.kline.daily",  
            # 选填，默认 {}；依 data_id 而定
            "params": {                      
                # 选填，默认 qfq；可选 raw | hfq
                "adjust": "qfq",              
            },
            # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
            "indicators": {},
        },
        # 选填，默认 []；计算 tag 所需的辅助数据源（不含 base）
        "extra_required_data_sources": [
            {"data_id": "macro.gdp", "params": {}},
        ],
        # 选填，默认 0；calculation.update_mode=incremental 时须显式配置（可为 0）
        # as_of 之前至少需要的 history 条数（warmup / min bars）
        "min_required_records": 0,
    },

    # -----------------------------------------------------------------------
    # 5. tags — 标签定义（一个 scenario 下可多个 tag）
    # -----------------------------------------------------------------------
    # 必填，至少 1 项
    "tags": [                            
        {
            # 必填，机器识别码（对应 tag_definition.name）；字母数字下划线
            "name": "example_tag_1",     
            # 选填，默认与 name 相同
            "display_name": "example tag 1",  
            # 选填，默认 ""
            "description": "标签 1 说明",       
        },
        {
            "name": "example_tag_2",
            "display_name": "example tag 2",
            "description": "举例：当 example_tag_1 条件不满足时使用的互斥标签",
        },
    ],
}
