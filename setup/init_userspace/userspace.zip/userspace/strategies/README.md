# 策略（`userspace/strategies/`）

这里是**策略用户空间**：您定义「买入信号是什么」（`strategy_worker.py`），以及「策略怎么跑」（`settings.py`），框架负责把扫描、枚举、模拟流程串起来。

> **内置演示策略**（新手快速上手，**不是**投资建议）见 **[demo/README.md](demo/README.md)**。  
> **操作细节**见 **[USER_GUIDE.md](USER_GUIDE.md)**（以 Web UI 为主）。

## 在界面里先建立直觉

启动 UI：`python launcher.py`（仓库根目录）。

| 您想做的事 | 顶栏入口 |
|------------|----------|
| 历史回测（枚举 → 价格 → 资金） | **制定策略** |
| 用最新数据找当前机会 | **策略选股** |
| 改全局环境（库、路径等） | **设置** |

### 回测 vs 扫描

- **回测**（制定策略）：用历史数据检验逻辑；三步 Stepper 对应 **枚举机会 / 价格回测 / 资金模拟**。
- **扫描**（策略选股）：对**最新**行情跑一遍，看今天有哪些命中（需先更新数据）。

### 三步各自回答什么

| 步骤 | 您主要在问 |
|------|-----------|
| 枚举机会 | 策略能不能找到机会？找到多少？ |
| 价格回测 | 单笔层面是否偏正？（≠ 真实账户收益） |
| 资金模拟 | 加上资金与仓位约束后，组合还成不成？ |

---

## 一分钟：在 UI 里跑演示策略

1. **制定策略** → 搜索 **「随机买卖 v1 · 纯随机投资」** → 进入。
2. 在 **枚举机会** 页点击运行，看报告中的机会数等指标。
3. 依次打开 **价格回测**、**资金模拟** 并运行。
4. 在报告中点击单只股票，查看 K 线与买卖点（v0.4.1+）。

同族对照与其它 demo 见 [demo/README.md](demo/README.md)。

---

## 从 0 创建新策略（概要）

1. 运行 `python cli.py -s -new my_strategy`，或复制 [`_template/empty_strategy/`](_template/empty_strategy/) 到新目录。
2. 改 `settings.py`：`is_enabled: True`，调整 `meta` / `core` 等。
3. 在 `strategy_worker.py` 中实现 `scan_opportunity`（模板已列出常用钩子）。
4. 回到 **制定策略** 列表，从 **枚举机会** 开始运行。

结果优先在 **UI 报告** 查看；磁盘产物在 `my_strategy/results/`。

---

## 目录结构（示意）

```text
userspace/strategies/
├── README.md                 # 本文件
├── USER_GUIDE.md             # 详细用户指南（UI 优先）
├── settings_example.py
├── _template/                # 可复制模板（不参与 discovery）
│   └── empty_strategy/
└── demo/                     # 内置演示（11 条，见 demo/README.md）
    ├── random/               # 3
    ├── regression/           # 6（RSI + BB）
    ├── trend/                # 规划占位
    └── cross_sectional/      # 横截面（low_price 2 条）
```

## 更多

- [USER_GUIDE.md](USER_GUIDE.md) — 新建策略、常见问题、可选 CLI 附录  
- [demo/README.md](demo/README.md) — 演示策略索引  
- [settings_example.py](settings_example.py) — 字段说明  
