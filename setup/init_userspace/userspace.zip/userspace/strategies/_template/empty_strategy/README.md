# 空白策略模板（`_template/empty_strategy/`）

可直接复制改动的策略起点。**不会**出现在 UI 策略列表（discovery 跳过 `_` 开头目录）。

## 怎么用

```bash
cp -R userspace/strategies/_template/empty_strategy userspace/strategies/my_strategy
# 或
python cli.py -s -new my_strategy
```

然后：

1. 改 `settings.py`：`is_enabled: True`、`meta.display_name`、`core` 等
2. 改 `strategy_worker.py`：重命名 `EmptyStrategyWorker`，实现 `scan_opportunity`
3. 按需删减 settings 块、删除未使用的 worker 钩子

## 文件说明

| 文件 | 作用 |
|------|------|
| `settings.py` | 与 [`settings_example.py`](../../settings_example.py) 同步的完整配置示例 |
| `strategy_worker.py` | 常用钩子骨架，主逻辑为空 |

字段说明以 [`settings_example.py`](../../settings_example.py) 为准。

[← 策略用户空间](../../README.md)
