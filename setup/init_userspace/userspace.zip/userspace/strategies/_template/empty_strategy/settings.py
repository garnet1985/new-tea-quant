# 空白策略模板 — 复制整个 empty_strategy/ 到新目录后改名、改 meta、实现 strategy_worker。
# 字段说明见 ../../settings_example.py（与本文件内容同步）。
# 系统不会扫描 _template/ 目录；复制后请将 is_enabled 设为 True。

settings = {
    # -----------------------------------------------------------------------
    # 1. 基础信息
    # -----------------------------------------------------------------------
    "is_enabled": False,             # 复制到新目录后改为 True

    # 用户可见文档块；系统策略 ID 由目录路径决定，不在此填写 name
    "meta": {
        "display_name": "空白策略模板",
        "description": "复制 _template/empty_strategy/ 到新目录后修改；本模板不产生任何买入信号。",
        "keywords": ["示例"],         # 选填，标签/检索用
        "details": {                  # 选填，结构化说明（如入场条件条目）
            "entry": [
                "示例：RSI(14) 低于 core.rsi_oversold_threshold 时产生买入信号",
            ],
        },
        "category": ["your category"]
    },

    # -----------------------------------------------------------------------
    # 2. core — 策略私有参数（strategy_worker 里读取）
    # -----------------------------------------------------------------------
    "core": {
        "rsi_oversold_threshold": 20,  # 示例：RSI 超卖线，可任意增删键名
        # "momentum_threshold": 0.05,
    },

    # -----------------------------------------------------------------------
    # 3. data — K 线与指标
    # -----------------------------------------------------------------------
    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",  # 省略时默认 stock.kline.daily
            "params": {
                "adjust": "qfq",     # 选填，默认 qfq；可选 raw | hfq
            },
            # 选填，默认 {}；指标名见 core/modules/indicator/AVAILABLE_INDICATORS.md
            "indicators": {
                # "rsi": [{"length": 14}],
                # "sma": [{"length": 5}, {"length": 20}],
                # "macd": [{"fast": 12, "slow": 26, "signal": 9}],
            },
        },
        # 多周期示例：base 驱动回测主时间轴（slot klines），extra 注入辅助周期（slot = data_id）
        # "extra_required_data_sources": [
        #     {
        #         "data_id": "stock.kline.weekly",
        #         "params": {"adjust": "qfq"},
        #         "indicators": {"bbands": [{"length": 20, "std": 2.0}]},
        #     },
        # ],
        "extra_required_data_sources": [  # 选填，默认 []；data_id 见 DataKey
            # {"data_id": "macro.gdp", "params": {}},
            # {"data_id": "tag", "params": {"tag_scenario": "activity-ratio20"}},
        ],
        "min_required_records": 100,  # 选填，默认 100；历史 K 线最少条数
    },

    # -----------------------------------------------------------------------
    # 4. sampling — 股票池与回测区间（三步共用）
    # -----------------------------------------------------------------------
    "sampling": {
        "use_sampling": False,       # 选填，默认 False；True=按下方规则缩小股票池
        "start_date": "",            # 选填，默认 ""；回测开始 YYYYMMDD，空=自动
        "end_date": "",              # 选填，默认 ""；回测结束 YYYYMMDD，空=自动

        # strategy 选填，默认 continuous
        # uniform | stratified | random | continuous | pool | blacklist
        "strategy": "continuous",
        "sampling_amount": 50,       # 选填，默认 10；采样股票数量

        "continuous": {
            "start_idx": 0,          # 选填，默认 0；连续采样起始下标
        },
        # 仅在与 strategy 一致时填写对应子块：
        # "pool": {"stock_ids": ["000001.SZ"], "file": "stock_lists/pool.txt"},
        # "blacklist": {"stock_ids": [], "file": "stock_lists/blacklist.txt"},
        # "random": {"seed": 42},
        # "stratified": {"seed": 42},
    },

    # -----------------------------------------------------------------------
    # 5. goal — 止盈 / 止损 / 到期
    # -----------------------------------------------------------------------
    "goal": {
        "expiration": {              # 选填；不写则只按止盈止损结束
            "fixed_window_in_days": 30,  # 选填，默认 30；最长持仓天数（日历日）
            "is_trading_days": True,     # 选填，默认 True；True=按交易所开市日计持有天数
        },
        "stop_loss": {               # 选填
            "stages": [
                {
                    "name": "loss10%",
                    "ratio": -0.1,           # 亏损比例（负数）
                    "close_invest": True,    # True=全部卖出；False 时用 sell_ratio
                    # "sell_ratio": 0.5,     # 0~1，部分卖出比例
                },
            ],
        },
        "take_profit": {             # 选填；多阶段时至少一阶段 close_invest=True 或 sell_ratio 合计为 1
            "stages": [
                {
                    "name": "win10%",
                    # （必填）触发阈值：正数表示盈利比例
                    "ratio": 0.1,
                    # （必填）部分卖出比例（0~1）
                    # 0.5代表卖出投资总股数的50%
                    "sell_ratio": 0.5,
                    # 追加动作（可选）：
                    # - （选填）set_protect_loss: 启用保本线 - 如果价格跌回到本金，按照protect_loss的配置操作
                    # - （选填）set_dynamic_loss: 启用动态止损 - 如果价格跌回到最高点回撤 N%，按照dynamic_loss的配置操作
                    "actions": ["set_protect_loss"],
                },
                {
                    "name": "win20%",
                    "ratio": 0.2,
                    # close_invest=True 表示直接清仓
                    "close_invest": True,
                    "actions": ["set_dynamic_loss"],
                },

            ]
        },

        # （选填）保本止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "protect_loss": {
            "ratio": 0,                   # 回到成本价
            "close_invest": True          # 触发时清仓
        },

        # （选填）动态止损；运行期由 take_profit stage 的 actions 触发后读取本块
        "dynamic_loss": {
            "ratio": -0.1,                # 从最高点回撤 10%
            "close_invest": True          # 触发时清仓
        },


        # （选填）股票状态风险管控：省略或 rules=[] → 仅退市强平（引擎内置，不可关闭）
        # 可选 delisted_exit_price 覆盖退市平仓价；rules 中不要写 delisted
        "stock_status_risk_management": {
            # "delisted_exit_price": "last_tradable_close",
            "rules": [
                # {
                #     "name": "st",
                #     "close_invest": True,
                # },
                # {
                #     "name": "star_st",
                #     "close_invest": True,
                #     # "sell_ratio": 0.5,
                # },
            ],
        },
    },

    # =======================================================================
    # 6) 枚举器配置（大多可省略）
    # =======================================================================
    # 调度/性能参数（entities_per_job、memory_budget_mb 等）在 worker.json → job_pipeline.enumerator.dispatch
    "enumerator": {
        # （选填， 默认 False）是否输出更详细调度日志
        "is_verbose": False,
    },

    # =======================================================================
    # 7) 公共交易费率（可省略）
    # =======================================================================
    # （选填）全链路模拟共用费率；请勿在 price_simulator / capital_simulator 下再写 fees 覆盖。
    "fees": {
        "commission_rate": 0.00025,  # （选填，有默认值）佣金率
        "min_commission": 5.0,       # （选填，有默认值）最低佣金
        "stamp_duty_rate": 0.001,    # （选填，有默认值）印花税（卖出）
        "transfer_fee_rate": 0.0,    # （选填，有默认值）过户费
    },

    # =======================================================================
    # 7b) market_profile — 市场制度（可省略，默认 china_a_stock）
    # =======================================================================
    # 根级字符串；决定涨跌幅限制、最小申报单位、交易日历映射等（枚举算涨跌停价、capital 手数）。
    # 可选值见 core/modules/market_profile/markets/ 或工作台 market_profile 下拉。
    # "market_profile": "china_a_stock",

    # =======================================================================
    # 8) simulation — 回测执行假设（根级）
    # =======================================================================
    # 多数情况只写 template。preset 的细项由引擎快照决定，工作台只读展示；改细项用 custom。
    #
    # template 选项（侧重点）：
    #   standard — 日常默认；常见成交节奏 + 涨跌停不成交
    #   strict   — 更贴近现实；标准 + 触发日 ST/*ST 不模拟
    #   ideal    — 理想对照；少市场摩擦，便于和 standard 比信号
    #   extreme  — 极值压力；盯盘/成交按极值，结果偏悲观
    #   custom   — 自行配置下方价模型、涨跌停、ST 跳过等
    #
    # calendar_slice：仅需 execution_mode: "calendar_slice"；片宽/步长由运行时 auto
    #
    "simulation": {
        "template": "standard",  # 省略 simulation 块时等价 standard
        # "retention": {"max_output_versions": 3},
    },

    # =======================================================================
    # 9) 价格因子模拟器配置（大多可省略）
    # =======================================================================
    # 不再包含 use_sampling、start_date/end_date（见 sampling）；费率仅根级 fees。
    # 调度参数（entities_per_job 等）在 worker.json → job_pipeline.price_factor.dispatch
    "price_simulator": {
        # （选填， 默认 "latest"）读取枚举产物的版本选择
        # 支持："latest" / "1" / "2" ...（目录：userspace/strategies/<策略路径>/results/simulations/enum/）
        "base_version": "latest",
    },

    # =======================================================================
    # 10) 资金分配模拟器配置（大多可省略）
    # =======================================================================
    # 不再包含 use_sampling、start_date/end_date（见 sampling）；费率仅根级 fees。
    # 买入：必须有枚举器写好的 buy_date、buy_price（缺一即跳过该机会，不回退 trigger_*）。
    # 卖出事件：targets 各行 date + price，与枚举器 completed_targets 一致。
    "capital_simulator": {
        # （选填， 默认 "latest"）读取枚举产物的版本选择（含义同 price_simulator.base_version）
        "base_version": "latest",

        # （选填， 默认 1_000_000）初始资金
        "initial_capital": 1_000_000,

        # （选填）资金分配参数（各字段有默认值，见 StrategyCapitalSimulatorSettings）
        "allocation": {
            # （选填， 默认 "equal_capital"）资金分配模式：
            # - equal_capital：等额资金分配
            # - equal_shares：等额股数分配
            # - kelly：凯利公式分配
            # - custom：自定义分配
            "mode": "equal_capital",
            # （选填， 默认 10）最大持仓数
            "max_portfolio_size": 10,
            # （选填， 默认 0.3）单票最大权重（0~1）
            "max_weight_per_stock": 0.3,
            # （选填， 默认 1）每笔交易手数（手数由 market_profile 决定）
            "lots_per_trade": 1,
            # （选填， 默认 0.5）kelly 模式参数
            # kelly 模式参数
            "kelly_fraction": 0.5,
        },

        # （选填）输出开关（有默认值）
        # - save_trades：是否保存逐笔交易日志
        # - save_equity_curve：是否保存每日权益曲线
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # =======================================================================
    # 11) 扫描器配置（可省略）
    # =======================================================================
    "scanner": {
        # （选填， 默认 ["console"]）输出适配器列表
        # 表示如何继续处理用当前策略扫描出的投资机会 - 可以某种方式通知，可以使用第三方服务自动下单，可以进行机器学习等等。
        # 取决于您在 adapter 里扩展了什么，系统默认只自带 console（命令行输出）。其他适配方式需自行扩展
        # 示例：["console"], ["console", "sms", "machine_learning"], ["wechat", "email"]
        "adapters": ["console"],

        # （选填， 默认 True）是否严格按“上一个交易日”进行扫描
        # True=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会拒绝扫描。
        # False=如果发现数据库最新的一个K线记录只到2025年6月30日，则扫描器会扫描2025年6月30日当天的策略产生的机会。
        "use_strict_previous_trading_day": True,
        
        # （选填， 默认 10）扫描缓存天数
        # 保留最近 N 个扫描日期目录，多于这个数量的结果会被自动删除。
        "max_cache_days": 10,

        # （选填， 默认 ""）股票列表文件路径（相对策略目录或绝对路径）；非空时须为存在的文本文件，每行一个股票代码
        # 复制为正式策略后按需填写，例如："stock_lists/watch.txt"
        "watch_list": "",
    },
}
