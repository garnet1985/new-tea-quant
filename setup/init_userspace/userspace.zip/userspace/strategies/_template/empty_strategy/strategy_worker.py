#!/usr/bin/env python3
"""空白策略模板 — 复制后在此实现 scan_opportunity 等钩子。"""

from __future__ import annotations

from typing import Any, Dict, Optional

from core.modules.strategy.base_strategy_worker import BaseStrategyWorker
from core.modules.strategy.engines.shared.data_classes.opportunity import Opportunity
from core.modules.strategy.engines.simulator.enumerator.calendar_sliced.types import (
    CalendarAsOfContext,
    CalendarAsOfResult,
)

__all__ = ["EmptyStrategyWorker"]


class EmptyStrategyWorker(BaseStrategyWorker):
    """
    空白策略 Worker 模板。

    复制到新策略目录后：
    1. 重命名本类（如 ``MyRsiStrategyWorker``）
    2. 在 ``scan_opportunity`` 中实现入场逻辑
    3. 按需启用 ``on_calendar_asof``（``simulation.execution_mode: calendar_slice`` 时使用）
    4. 删除未使用的钩子
    """

    # ------------------------------------------------------------------
    # 枚举 / 扫描主钩子
    # ------------------------------------------------------------------

    def scan_opportunity(
        self,
        data: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> Optional[Opportunity]:
        """
        扫描单股买入机会（必填）。

        entity_timeline：每个交易日对每只股票调用一次。
        calendar_slice：仅 ``on_calendar_asof`` 选中的股票会进入本钩子。

        常用辅助：
        - ``self.get_record_of_today(data)`` — 当前 as_of 日 K 线
        - ``self.build_opportunity(record, extra_fields={...})`` — 组装标准 Opportunity
        - ``self.core_float(settings, "key")`` / ``self.core_int(settings, "key")`` — 读 core 参数
        """
        _ = data, settings
        return None

    def on_calendar_asof(
        self,
        ctx: CalendarAsOfContext,
        settings: Dict[str, Any],
    ) -> CalendarAsOfResult:
        """
        日历横截面钩子（``simulation.execution_mode: calendar_slice`` 时生效）。

        在本 as_of 日决定哪些股票进入 ``scan_opportunity``。
        默认：对 ``ctx.stocks`` 中有数据的全部股票扫描。

        横截面策略示例流程：
        1. 判断是否为换仓日 / 清仓日
        2. 逐股过滤、排序
        3. 返回 ``CalendarAsOfResult(selected_stock_ids=[...], carry={...})``
        """
        return super().on_calendar_asof(ctx, settings)

    # ------------------------------------------------------------------
    # 生命周期钩子
    # ------------------------------------------------------------------

    def on_init(self) -> None:
        """Worker 实例化完成后调用；可初始化跨日状态。"""
        pass

    def on_before_scan(self) -> None:
        """每次 scan_opportunity 调用前。"""
        pass

    def on_after_scan(self, opportunity: Optional[Opportunity]) -> None:
        """每次 scan_opportunity 调用后。"""
        pass

    # ------------------------------------------------------------------
    # 价格因子钩子（price 回测步）
    # ------------------------------------------------------------------

    def on_price_factor_before_process_stock(
        self,
        stock_id: str,
        opportunities: list[dict],
        config: dict,
    ) -> None:
        """处理单股价格回测前。"""
        return None

    def on_price_factor_after_process_stock(
        self,
        stock_id: str,
        stock_summary: dict,
        config: dict,
    ) -> dict:
        """处理单股价格回测后；可修改并返回 stock_summary。"""
        return stock_summary

    def on_price_factor_opportunity_trigger(
        self,
        opportunity_row: dict,
        config: dict,
    ) -> dict:
        """单笔机会触发买入时；可修改 opportunity_row。"""
        return opportunity_row

    def on_price_factor_target_hit(
        self,
        target_row: dict,
        opportunity_row: dict,
        config: dict,
    ) -> dict:
        """止盈 / 止损 / 到期等 target 命中时；可修改 target_row。"""
        return target_row
