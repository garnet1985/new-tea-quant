# 演示策略课程表（Demo Curriculum）

本文档定义 `userspace/strategies/` 下**内置演示策略**的目标、分类与叙事边界。  
这些策略服务于 **New Tea Quant 框架**：教用户**怎么用工具**、理解**金融常识**、识别**常见坑**——**不是**推销可赚钱的选股方案。

> 与 [DISCLAIMER.md](../../DISCLAIMER.md) 一致：演示策略不构成投资建议；回测结果不保证未来可复现。

---

## 1. 我们要解决什么问题？

| 用户常见误区 | 演示策略要帮用户建立的正确观念 |
|--------------|--------------------------------|
| 「回测赚钱 = 策略有效」 | 先问：对照组是谁？区间、股票池、风控是否一致？ |
| 「技术指标有固定含义」 | 指标是**尺子**，不是答案；要先判断市场状态（regime） |
| 「低价股 K 线涨很猛」 | 图上猛的往往是**幸存者**；看不见的退市/ST 会改写结论 |
| 「单次回测曲线就是真相」 | 换随机种子、换区间、开关退市风控，结论可能完全不同 |
| 「框架是用来找圣杯的」 | 框架是用来**诚实验证想法**、对比假设、沉淀可复用资产（如 Tag） |

### 我们卖什么、不卖什么

**卖（框架能力）**

- Scan / Enumerate / Price / Capital 四层流水线怎么串
- 同条件对比不同假设（settings、风控、股票池）
- Tag 与策略联动、指标注入、市场制度（T+1、涨跌停、ST/退市）
- 工作台与报告：从「一条曲线」走到「可解释的证据」

**不卖**

- 「稳赚」「必涨」「内部信号」
- 未经对照的绝对收益率叙事
- 把演示策略当实盘建议

---

## 2. 目录规划（四类演示）

```text
userspace/strategies/
├── DEMO_CURRICULUM.md          # 本文件：目标与课程表
├── README.md                   # 策略用户空间入门
├── settings_example.py         # settings 字段大全
└── demo/
    ├── random/                 # 随机对照组
    ├── regression/             # 均值回归族（RSI / 均线 / 布林带）
    ├── trend/                  # 趋势 / 热点族
    └── low_price/              # 低价股与幸存者偏差（规划）
```

策略 **系统 ID** = 相对 `strategies/` 的路径（如 `regression/rsi_v1_signal_only`）。  
路径段须为字母开头的 ASCII 字母/数字/下划线。

---

## 3. 四类策略：要说明什么？

### 3.1 随机类（`random/`）

#### 想传递的信息

在无选股技能时，你主要是在赌：

1. **市场本身的漂移**（长期权益市场常存在向上 beta，但**因时期与市场而异**）
2. **你的出场纪律**（止损、止盈、持仓期）

随机策略是 **零技能对照组（null baseline）**，用来回答：

> 「我的信号策略，是否比『瞎买 + 同样风控』多做出一点东西？」

#### 刻意不说的话

- ~~「闭眼随便投，止损小于止盈，基本都会赚」~~ — 这不是普遍规律；熊市、差股票池、极端行情下可以大幅亏损。
- ~~「随机策略 = 市场基准收益（benchmark）」~~ — 金融上 benchmark 通常指指数（如沪深 300）；随机入场更准确的说法是 **朴素主动对照基线**。

#### 多版本意图

| 版本（规划） | 教学要点 |
|--------------|----------|
| `random_v1_uniform_entry` | 固定概率随机开仓 + 统一 `goal` |
| `random_v2_seed_sweep`（可选） | 多 `seed` 对比，教「单次回测有运气成分」 |

#### 建议用户做的对比实验

- 与回归/趋势策略：**同一 `sampling`、同一 `simulation`、同一 `goal`**
- 换 3～5 个 `core.seed`：看 ROI **分布**，而非只看一条曲线
- 若多种子都「赚」：讨论是否牛市 + 股票池是否已剔除退市（幸存者偏差）

#### 框架要展示的能力

- 枚举 → 价格层 → 资金层完整链路
- `settings.core` 参数化 + 可复现随机（固定 seed）
- 报告中的机会数、胜率、资金层组合结果

---

### 3.2 回归类（`regression/`）

子族：**RSI**、**均线（MA）**、**布林带（BB）**

#### 想传递的信息

均值回归不是「数学自动兑现」，而是：

> **你认为价格暂时偏离了一个可信的锚（anchor）；你知道它大概该回到哪里。**

- **RSI / 均线 / 布林带** 是测量「偏离」的**尺子**
- 没有合理锚（估值、景气、稳定区间）时，「回归到哪里」是模糊的
- 在**单边下跌、基本面恶化**时，超卖可以持续超卖 —— 不是指标失灵，是 **regime 不对**

#### 关于布林带的表述（重要）

布林带是「均线 ± k 倍标准差」的**启发式通道**，**不是**严格意义上的「正态分布 95% 概率区间」：

- 股价收益常非正态（厚尾、偏度）
- 均值本身会漂移

对用户说：**「价格相对近期均值偏了多少」**，而非 **「95% 一定会回来」**。

#### 多版本意图（每子族 2～3 版）

| 子族 | 版本线（规划） | 每版多讲一件事 |
|------|----------------|----------------|
| RSI | v1 纯 RSI → v2 财报准入 → v3 PE 分位 | 信号 → 生意锚 → 估值锚 |
| MA | v1 跌破均线 → v2 偏离度% → v3 量能确认 | 锚是否在动 → 阈值 → 多维度 |
| BB | v1 日线下轨 → v2 周线过滤 → v3 protect/dynamic | 尺子 → 多周期 → 出场 |

#### 建议用户做的对比实验

- 同一策略在**震荡段 vs 下跌段**的表现差异
- v1 与 v2：机会数变少是否换来更可控的回撤叙事
- 与 `trend/` 同时期对比：抄底型 vs 顺势型

#### 框架要展示的能力

- 各 data 声明项上的 `indicators` 注入（`rsi`、`sma`、`bbands` 等；按 slot 计算）
- `goal` 多阶段止盈止损、`protect_loss` / `dynamic_loss`
- `extra_required_data_sources` 引用 Tag（如 `activity-ratio20`）

---

### 3.3 趋势类（`trend/`）

#### 想传递的信息

在不少市场阶段：

> **顺势比抄底更容易执行，也更少依赖「猜底」**；但趋势策略同样会有震荡市假突破、回撤期连亏。

核心不是「追就赚」，而是：

1. **承认趋势存在**（资金、动量、信息扩散）
2. **出场与风控**和入场同样重要

#### 刻意不说的话

- ~~「趋势是最简单有效的赚钱方式」~~ — 改为：**相对抄底，顺势更贴合市场结构，但仍需纪律与回撤承受**

#### 多版本意图

| 版本（规划） | 教学要点 |
|--------------|----------|
| `hotspot_v1_activity_high` | 接 `activity-ratio20` Tag：活跃度高 |
| `hotspot_v2_momentum_filter` | + ROC / MACD 等动量确认 |
| `hotspot_v3_trailing_exit` | `dynamic_loss` / 移动止盈：趋势也要出场 |

#### 建议用户做的对比实验

- 与 `regression/rsi` **同区间**：顺势 vs 超卖抄底
- 开关 `goal.dynamic_loss`：教「拿得住」和「卖得掉」是两件事

#### 框架要展示的能力

- Tag 场景 `userspace/extensions/tags/example/`（`activity-ratio20`）
- 策略 `extra_required_data_sources` 读 Tag
- 与回归族共用 sampling，公平对比

---

### 3.4 低价股类（`low_price/`）

#### 想传递的信息

K 线上「低价股涨很猛」往往是**条件样本**；看不见的结局包括：

- 长期阴跌
- ST / *ST
- **退市**

> **不是低价策略骗了你，是你只看见了活下来的 K 线。**

这是 **幸存者偏差（survivorship bias）** 的标准教材，在 A 股语境下尤其重要：

- 低价 ≠ 便宜 ≠ 安全
- 回测池若未诚实处理退市，结论会系统性偏乐观

#### 多版本意图

| 版本（规划） | 教学要点 |
|--------------|----------|
| `low_price_v1_naive` | 仅 `price < X` 买入；弱化或关闭 ST/退市叙事 |
| `low_price_v2_with_risk` | 开启 `goal.stock_status_risk_management`、严格 `simulation` |
| `low_price_v3_pit_pool`（可选） | 更诚实的股票池 / PIT 采样，教「池子定义改结论」 |

#### 建议用户做的对比实验

- **v1 vs v2 同区间**：曲线差异 = 「看不见的结尾」的影响
- 阅读单笔机会 `metadata.stock_status_at_trigger`
- 结合资金层：机会多 ≠ 组合赚

#### 框架要展示的能力

- `stock_status_risk_management`、退市强平
- `simulation.template=strict` 与涨跌停边缘
- 枚举 metadata 中的 ST 状态标注

---

## 4. 跨类别对比原则（控制变量）

为保证「教常识」而不是「比谁的曲线好看」，演示策略默认遵守：

| 维度 | 建议 |
|------|------|
| 回测区间 | 同类对比使用相同 `sampling.start_date` / `end_date` |
| 股票池 | 同类对比使用相同 `sampling.strategy` 与 `sampling_amount` |
| 成交假设 | 默认统一 `simulation`（如收盘信号 → `next_open` 买入） |
| 费率 | 统一 `fees` |
| 风控 | 若版本差异**不是**本课要点，则统一 `goal` |
| 启用数量 | 不必全部 `is_enabled: True`；每族默认只开 v1，避免 scan 过重 |

**对照关系（建议用户按此阅读）**

```text
random_v1          ← 一切「有没有 edge」的零点
regression/*       ← 相对 random：尺子有没有多出信息？
trend/*            ← 相对 regression：顺势 vs 抄底（同区间）
low_price v1 vs v2 ← 相对一切：幸存者偏差开关
```

---

## 5. 实施清单（开发跟踪）

状态图例：⬜ 未开始 · 🟡 进行中 · ✅ 已完成

### 随机类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/random/random_v1_null_baseline` | ✅ | seed=6，±20% 对称 goal |
| `demo/random/random_v2_alt_seed` | ✅ | 仅 seed=42，其余与 v1 相同 |
| `demo/random/random_v3_asymmetric_goal` | ✅ | 与 v1 同 seed；goal 为 -20% / +30% |

### 回归类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/regression/rsi/rsi_v1_without_value_anchor` | ✅ | 纯 RSI 超卖触发 |
| `demo/regression/rsi/rsi_v2_fundamental_gate` | ✅ | v1 + 季频财报 PIT 准入（netprofit_yoy） |
| `demo/regression/rsi/rsi_v3_pe_percentile_gate` | ✅ | v2 + 日频 PE 历史分位（stock.indicators.daily） |
| `regression/ma_v1_price_below_sma` | ⬜ | |
| `demo/regression/bb/bb_v1_lower_touch` | ✅ | 日频 BB 下轨下方买入 |
| `demo/regression/bb/bb_v2_weekly_filter` | ✅ | v1 + extra 周线 BB 下轨过滤 |
| `demo/regression/bb/bb_v3_managed_exit` | ✅ | v2 入场 + protect_loss / dynamic_loss 分阶段出场 |

### 趋势类

| 路径 | 状态 | 备注 |
|------|------|------|
| `trend/hotspot_v1_activity_high` | ⬜ | 依赖 `activity-ratio20` Tag |

### 低价股类

| 路径 | 状态 | 备注 |
|------|------|------|
| `low_price/low_price_v1_naive` | ⬜ | 幸存者偏差对照（乐观侧） |
| `low_price/low_price_v2_with_risk` | ⬜ | 含 ST/退市风控 |

---

## 6. 每个策略 `meta` 应写什么？

`settings.py` 中 `meta` 块面向 UI 与文档，建议每版包含：

```python
"meta": {
    "display_name": "…",           # 人话名称，含版本
    "description": "…",            # 本策略教什么（一句话）
    "keywords": ["演示", "回归", …],
    "details": {
        "entry": [
            "本课要点：…",
            "与上一版差异：…",
            "建议对比：random_v1 / …",
            "常见坑：…",
        ],
    },
},
```

**不要写**：预期收益率、推荐实盘、「稳赚」类措辞。

---

## 7. 用户阅读路径（推荐）

1. 读本文 **§3** 确认四类各教什么  
2. 跑 `random_v1` 建立对照基线  
3. 跑一个 `regression/*` 与一个 `trend/*`，**同区间**对比  
4. 跑 `low_price_v1` 与 `v2`，理解幸存者偏差  
5. 打开工作台报告：看枚举数、价格层、资金层、单笔 ST 标注  
6. 自行改 `settings` / 复制目录，验证「改一个假设，结论变多少」

命令入门见 [README.md](README.md)、[USER_GUIDE.md](USER_GUIDE.md)。

---

## 8. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-06-14 | 初稿：明确四类演示目标、对照原则与实施清单 |
