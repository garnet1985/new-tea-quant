# 演示策略课程表（Demo Curriculum）

本文档定义 `userspace/strategies/` 下**内置演示策略**的目标、分类与叙事边界。  
这些策略服务于 **New Tea Quant 框架**：教用户**怎么用工具**、理解**金融常识**、识别**常见坑**——**不是**推销可赚钱的选股方案。

> 与 [DISCLAIMER.md](../../DISCLAIMER.md) 一致：演示策略不构成投资建议；回测结果不保证未来可复现。

---

## 1. 我们要解决什么问题？

| 用户常见误区 | 演示策略要帮用户建立的正确观念 |
|--------------|--------------------------------|
| 「回测赚钱 = 策略有效」 | 先问：对照组是谁？区间、股票池、风控是否一致？ |
| 「技术指标有固定含义」 | 指标是**尺子**，不是答案；要先判断市场状态（regime） |
| 「低价股 K 线涨很猛」 | 图上猛的往往是**幸存者**；看不见的退市/ST 会改写结论 |
| 「单次回测曲线就是真相」 | 换随机种子、换区间、开关退市风控，结论可能完全不同 |
| 「框架是用来找圣杯的」 | 框架是用来**诚实验证想法**、对比假设、沉淀可复用资产（如 Tag） |

### 我们卖什么、不卖什么

**卖（框架能力）**

- Scan / Enumerate / Price / Capital 四层流水线怎么串
- 同条件对比不同假设（settings、风控、股票池）
- Tag 与策略联动、指标注入、市场制度（T+1、涨跌停、ST/退市）
- 工作台与报告：从「一条曲线」走到「可解释的证据」

**不卖**

- 「稳赚」「必涨」「内部信号」
- 未经对照的绝对收益率叙事
- 把演示策略当实盘建议

---

## 2. 目录规划（四类演示）

```text
userspace/strategies/
├── DEMO_CURRICULUM.md          # 本文件：目标与课程表
├── README.md                   # 策略用户空间入门
├── settings_example.py         # settings 字段大全
└── demo/
    ├── random/                 # 随机对照组（✅ v1–v3）
    ├── regression/
    │   ├── rsi/                # RSI 回归线（✅ v1–v3）
    │   ├── bb/                 # 布林带回归线（✅ v1–v3；共用 bb_indicators.py）
    │   └── ma/                 # 均线回归线（⬜ 规划）
    ├── trend/                  # 趋势 / 热点族（⬜ 规划）
    └── low_price/              # 低价股与幸存者偏差（⬜ 规划）
```

策略 **系统 ID** = 相对 `strategies/` 的路径（如 `demo/regression/rsi/rsi_v1_without_value_anchor`）。  
路径段须为字母开头的 ASCII 字母/数字/下划线。

### 2.1 当前进度快照（2026-06-14）

| 类别 | 已实现 | 规划未做 |
|------|--------|----------|
| 随机 `demo/random/` | 3 | 0 |
| 回归 RSI `demo/regression/rsi/` | 3 | 0 |
| 回归 BB `demo/regression/bb/` | 3 | 0 |
| 回归 MA | 0 | ≥1 |
| 趋势 `demo/trend/` | 0 | ≥1 |
| 低价股 `demo/low_price/` | 0 | ≥2 |
| **合计** | **9 条演示线** | MA / trend / low_price |

---

## 3. 四类策略：要说明什么？

### 3.1 随机类（`random/`）

#### 想传递的信息

在无选股技能时，你主要是在赌：

1. **市场本身的漂移**（长期权益市场常存在向上 beta，但**因时期与市场而异**）
2. **你的出场纪律**（止损、止盈、持仓期）

随机策略是 **零技能对照组（null baseline）**，用来回答：

> 「我的信号策略，是否比『瞎买 + 同样风控』多做出一点东西？」

#### 刻意不说的话

- ~~「闭眼随便投，止损小于止盈，基本都会赚」~~ — 这不是普遍规律；熊市、差股票池、极端行情下可以大幅亏损。
- ~~「随机策略 = 市场基准收益（benchmark）」~~ — 金融上 benchmark 通常指指数（如沪深 300）；随机入场更准确的说法是 **朴素主动对照基线**。

#### 多版本意图（已实现）

| 路径 | 状态 | 教学要点 |
|------|------|----------|
| `demo/random/random_v1_null_baseline` | ✅ | seed=6，固定概率随机开仓，±20% 对称 `goal` |
| `demo/random/random_v2_alt_seed` | ✅ | 仅 `core.seed=42`，其余与 v1 相同 |
| `demo/random/random_v3_asymmetric_goal` | ✅ | 与 v2 同 seed；`goal` 为 -20% / +30% |

#### 建议用户做的对比实验

- 与回归/趋势策略：**同一 `sampling`、同一 `simulation`、同一 `goal`**
- 换 3～5 个 `core.seed`：看 ROI **分布**，而非只看一条曲线
- 若多种子都「赚」：讨论是否牛市 + 股票池是否已剔除退市（幸存者偏差）

#### 框架要展示的能力

- 枚举 → 价格层 → 资金层完整链路
- `settings.core` 参数化 + 可复现随机（固定 seed）
- 报告中的机会数、胜率、资金层组合结果

---

### 3.2 回归类（`regression/`）

子族：**RSI**、**均线（MA）**、**布林带（BB）**

#### 想传递的信息

均值回归不是「数学自动兑现」，而是：

> **你认为价格暂时偏离了一个可信的锚（anchor）；你知道它大概该回到哪里。**

- **RSI / 均线 / 布林带** 是测量「偏离」的**尺子**
- 没有合理锚（估值、景气、稳定区间）时，「回归到哪里」是模糊的
- 在**单边下跌、基本面恶化**时，超卖可以持续超卖 —— 不是指标失灵，是 **regime 不对**

#### 关于布林带的表述（重要）

布林带是「均线 ± k 倍标准差」的**启发式通道**，**不是**严格意义上的「正态分布 95% 概率区间」：

- 股价收益常非正态（厚尾、偏度）
- 均值本身会漂移

对用户说：**「价格相对近期均值偏了多少」**，而非 **「95% 一定会回来」**。

#### 多版本意图（已实现 vs 规划）

| 子族 | 已实现路径 | 状态 | 每版多讲一件事 |
|------|------------|------|----------------|
| RSI | `demo/regression/rsi/rsi_v1_without_value_anchor` | ✅ | 纯 RSI(14) 超卖尺子 |
| RSI | `demo/regression/rsi/rsi_v2_fundamental_gate` | ✅ | + `stock.finance.quarterly` 财报 PIT 准入 |
| RSI | `demo/regression/rsi/rsi_v3_pe_percentile_gate` | ✅ | + `stock.indicators.daily` PE 历史分位 |
| MA | `demo/regression/ma/…` | ⬜ | 跌破均线 → 偏离度% → 量能确认 |
| BB | `demo/regression/bb/bb_v1_lower_touch` | ✅ | 日线下轨下方买入 |
| BB | `demo/regression/bb/bb_v2_weekly_filter` | ✅ | + `stock.kline.weekly` 周线下轨过滤 |
| BB | `demo/regression/bb/bb_v3_managed_exit` | ✅ | v2 入场 + `protect_loss` / `dynamic_loss` 分阶段出场 |

**BB 线数据前提**：v2/v3 依赖周线 K 线已 renew（`stock_klines` config 含 `weekly`，`cli.py -r stock_klines`）。

#### 建议用户做的对比实验

- 同一策略在**震荡段 vs 下跌段**的表现差异
- **RSI**：v1 → v2 → v3，看机会数与「锚」叠加后信号如何变少
- **BB**：v1 vs v2（机会约从全市场日线下轨 → 周线过滤后显著减少）；v2 vs v3（**入场相同**，比出场与持仓周期）
- 与 `trend/` 同时期对比：抄底型 vs 顺势型（趋势线就绪后）

#### 框架要展示的能力（已在 RSI / BB 线验证）

- `stock.kline.daily` / `stock.kline.weekly` 等 DataKey；base → `klines` slot，extra → `data_id` slot
- 各 data 声明项上的 `indicators` 注入（`rsi`、`bbands` 等；按 slot 计算，含周线）
- `extra_required_data_sources`：`stock.finance.quarterly`、`stock.indicators.daily`、周线 K 线
- `goal` 多阶段止盈止损、`protect_loss` / `dynamic_loss`（见 `bb_v3_managed_exit`）
- 趋势族数据层见 [SW_INDUSTRY_AND_TREND_PLAN.md](../../extensions/data_source/docs/SW_INDUSTRY_AND_TREND_PLAN.md)（申万 + `moneyflow`）

---

### 3.3 趋势类（`trend/`）

> **数据层实施计划（申万行业 + 个股 `moneyflow`，暂不聚合行业净流入）：**  
> [SW_INDUSTRY_AND_TREND_PLAN.md](../../extensions/data_source/docs/SW_INDUSTRY_AND_TREND_PLAN.md)

#### 想传递的信息

在不少市场阶段：

> **顺势比抄底更容易执行，也更少依赖「猜底」**；但趋势策略同样会有震荡市假突破、回撤期连亏。

核心不是「追就赚」，而是：

1. **承认趋势存在**（资金、动量、信息扩散）
2. **出场与风控**和入场同样重要

#### 刻意不说的话

- ~~「趋势是最简单有效的赚钱方式」~~ — 改为：**相对抄底，顺势更贴合市场结构，但仍需纪律与回撤承受**

#### 多版本意图（`hot_money` 已下架，见 [STRATEGY_PLAN.md](trend/STRATEGY_PLAN.md)）

原「个股热钱追踪」demo（`hot_money_v1` / `v2` + `moneyflow-heat` tag）已移除：在缺少截面能力时，单日资金流难以做出可靠 demo。

趋势族 demo 可继续对照 `demo/regression/bb/bb_v3_managed_exit`（顺势出场纪律）；待截面排名或 tag 预计算分位就绪后再考虑重做热度类策略。

> 可选扩展（另一 branch）：申万行业池 `sw_hot_*`，非本族必需。

> 出场机制可先对照已实现的 `demo/regression/bb/bb_v3_managed_exit`。

#### 建议用户做的对比实验

- 与 `demo/regression/rsi/rsi_v1_without_value_anchor` **同区间**：顺势 vs 超卖抄底
- 对照 `demo/regression/bb/bb_v3_managed_exit` 理解 `goal.dynamic_loss`

#### 框架要展示的能力

- `extra_required_data_sources`（趋势族未来可接 `stock.moneyflow.daily`、`stock.indicators.daily` 等）
- 与回归族共用 sampling，公平对比

---

### 3.4 低价股类（`low_price/`）

#### 想传递的信息

K 线上「低价股涨很猛」往往是**条件样本**；看不见的结局包括：

- 长期阴跌
- ST / *ST
- **退市**

> **不是低价策略骗了你，是你只看见了活下来的 K 线。**

这是 **幸存者偏差（survivorship bias）** 的标准教材，在 A 股语境下尤其重要：

- 低价 ≠ 便宜 ≠ 安全
- 回测池若未诚实处理退市，结论会系统性偏乐观

#### 多版本意图（规划，目录尚未创建）

| 路径（规划） | 状态 | 教学要点 |
|--------------|------|----------|
| `demo/low_price/low_price_v1_naive` | ⬜ | 仅 `price < X` 买入；弱化或关闭 ST/退市叙事 |
| `demo/low_price/low_price_v2_with_risk` | ⬜ | 开启 `goal.stock_status_risk_management`、严格 `simulation` |
| `demo/low_price/low_price_v3_pit_pool`（可选） | ⬜ | 更诚实的股票池 / PIT 采样 |

#### 建议用户做的对比实验

- **v1 vs v2 同区间**：曲线差异 = 「看不见的结尾」的影响
- 阅读单笔机会 `metadata.stock_status_at_trigger`
- 结合资金层：机会多 ≠ 组合赚

#### 框架要展示的能力

- `stock_status_risk_management`、退市强平
- `simulation.template=strict` 与涨跌停边缘
- 枚举 metadata 中的 ST 状态标注

---

## 4. 跨类别对比原则（控制变量）

为保证「教常识」而不是「比谁的曲线好看」，演示策略默认遵守：

| 维度 | 建议 |
|------|------|
| 回测区间 | 同类对比使用相同 `sampling.start_date` / `end_date` |
| 股票池 | 同类对比使用相同 `sampling.strategy` 与 `sampling_amount` |
| 成交假设 | 默认统一 `simulation`（如收盘信号 → `next_open` 买入） |
| 费率 | 统一 `fees` |
| 风控 | 若版本差异**不是**本课要点，则统一 `goal` |
| 启用数量 | 不必全部 `is_enabled: True`；每族默认只开 v1，避免 scan 过重 |

**对照关系（建议用户按此阅读）**

```text
demo/random/random_v1_null_baseline     ← 一切「有没有 edge」的零点
demo/regression/rsi/* 或 demo/regression/bb/*  ← 相对 random：尺子 / 锚 / 多周期
demo/trend/*                            ← 相对 regression：顺势 vs 抄底（同区间，待实现）
demo/low_price v1 vs v2                 ← 幸存者偏差开关（待实现）
```

---

## 5. 实施清单（开发跟踪）

状态图例：⬜ 未开始 · 🟡 进行中 · ✅ 已完成

### 随机类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/random/random_v1_null_baseline` | ✅ | seed=6，±20% 对称 goal |
| `demo/random/random_v2_alt_seed` | ✅ | 仅 seed=42，其余与 v1 相同 |
| `demo/random/random_v3_asymmetric_goal` | ✅ | 与 v1 同 seed；goal 为 -20% / +30% |

### 回归类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/regression/rsi/rsi_v1_without_value_anchor` | ✅ | 纯 RSI 超卖触发 |
| `demo/regression/rsi/rsi_v2_fundamental_gate` | ✅ | v1 + 季频财报 PIT 准入（netprofit_yoy） |
| `demo/regression/rsi/rsi_v3_pe_percentile_gate` | ✅ | v2 + 日频 PE 历史分位（stock.indicators.daily） |
| `demo/regression/ma/…` | ⬜ | 均线子族；路径待定 |
| `demo/regression/bb/bb_v1_lower_touch` | ✅ | 日频 BB 下轨下方买入 |
| `demo/regression/bb/bb_v2_weekly_filter` | ✅ | v1 + extra 周线 BB 下轨过滤 |
| `demo/regression/bb/bb_v3_managed_exit` | ✅ | v2 入场 + protect_loss / dynamic_loss 分阶段出场 |

### 趋势类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/trend/hot_money/*` | ❌ 已下架 | 见 [STRATEGY_PLAN.md](trend/STRATEGY_PLAN.md) |

### 低价股类

| 路径 | 状态 | 备注 |
|------|------|------|
| `demo/low_price/low_price_v1_naive` | ⬜ | 幸存者偏差对照（乐观侧） |
| `demo/low_price/low_price_v2_with_risk` | ⬜ | 含 ST/退市风控 |

---

## 6. 每个策略 `meta` 应写什么？

`settings.py` 中 `meta` 块面向 UI 与文档，建议每版包含：

```python
"meta": {
    "display_name": "…",           # 人话名称，含版本
    "description": "…",            # 本策略教什么（一句话）
    "keywords": ["演示", "回归", …],
    "details": {
        "entry": [
            "本课要点：…",
            "与上一版差异：…",
            "建议对比：random_v1 / …",
            "常见坑：…",
        ],
    },
},
```

**不要写**：预期收益率、推荐实盘、「稳赚」类措辞。

---

## 7. 用户阅读路径（推荐）

1. 读本文 **§3** 与 **§5**，确认已完成线与待做线  
2. 跑 `demo/random/random_v1_null_baseline` 建立对照基线  
3. 任选一条回归线走完 **Enumerate → Price → Capital**：
   - RSI：`rsi_v1` → `rsi_v2` → `rsi_v3`（信号 → 财报 → 估值）
   - BB：`bb_v1` → `bb_v2` → `bb_v3`（尺子 → 周线 → 出场）
4. 趋势 / 低价股线就绪后，与回归族 **同区间** 对比  
5. 打开工作台报告：枚举数、价格层、资金层、单笔 ST 标注  
6. 复制目录、改 `settings`，验证「改一个假设，结论变多少」

命令入门见 [README.md](README.md)、[USER_GUIDE.md](USER_GUIDE.md)。

---

## 8. 修订记录

| 日期 | 说明 |
|------|------|
| 2026-06-14 | 初稿：四类演示目标、对照原则与实施清单 |
| 2026-06-14 | 同步实现进度：随机 v1–v3、RSI v1–v3、BB v1–v3 已完成；更新目录树、路径示例与阅读路径 |
| 2026-06-14 | 文档对齐：`indicators` 挂在各 data 声明项；BB v2 周线 renew 前提；`protect_loss`/`dynamic_loss` 见 bb_v3 |
