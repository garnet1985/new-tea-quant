# 内置演示策略（`demo/`）

一组**新手快速上手用的演示策略**：在 **制定策略** 界面里跑通枚举 → 价格 → 资金，并理解常见研究误区。**不是投资建议**。

> 与 [DISCLAIMER.md](../../DISCLAIMER.md) 一致：演示结果不保证未来可复现。

## 在 UI 里怎么开始？

1. 仓库根目录：`python launcher.py`
2. 顶栏 **制定策略**
3. 在列表中按 **展示名** 搜索（如「随机买卖 v1」「RSI 超跌反弹」），或按路径辨认系统 ID
4. 进入后按 Stepper 顺序运行：**枚举机会** → **价格回测** → **资金模拟**
5. 阅读每步报告；价格/资金步可点进 **单股 K 线** 看买卖点

| 想先试哪类 | 列表里可搜的展示名（示例） | 说明 |
|----------|---------------------------|------|
| 随机对照 | 随机买卖 v1 · 纯随机投资 | [random/README.md](random/README.md) |
| RSI 回归 | RSI 超跌反弹 | [regression/README.md](regression/README.md) |
| 布林带回归 | 布林带下轨回归 · v1 基础 | 同上 |
| 低价股横截面 | 低价股 · v2 月度换仓 | [cross_sectional/low_price/README.md](cross_sectional/low_price/README.md) |

**策略系统 ID**（日志、路径）= 相对 `strategies/` 的路径，如 `demo/random/random_v1_null_baseline`。

## 当前有哪些演示？

| 目录 | 状态 | 条数 |
|------|------|------|
| [random/](random/README.md) | ✅ | 3 |
| [regression/](regression/README.md) | ✅ | 6（RSI 3 + BB 3） |
| [trend/](trend/README.md) | ⏸ | 暂无 |
| [cross_sectional/](cross_sectional/README.md) | ✅ | 2（low_price v1 + v2） |

## 建议怎么玩？

1. **先跑通一条线**：UI 上完成三步运行并看报告。
2. **读同族 README**：弄清这组 demo 想说明什么、v1→v2→v3 差在哪。
3. **做对照**：在 **制定策略** 里分别打开两条策略，对齐 `sampling` / `simulation` / `goal` 后对比报告；或改 `core.seed` 后重新运行看版本差异。

改参数可在该策略页的 **左侧设置面板** 编辑（会写回 `settings.py`）。

## 演示策略想帮你看清的事

| 常见误区 | 更稳妥的想法 |
|----------|--------------|
| 回测赚钱 = 策略有效 | 先问对照组是谁、区间与股票池是否一致 |
| 指标有固定含义 | 指标是尺子，要先判断市场状态 |
| 低价股 K 线涨很猛 | 图上猛的常是幸存者；退市/ST 会改写结论 |
| 单次曲线就是真相 | 换种子、换区间、换风控，结论可能变 |
| 框架用来找圣杯 | 框架用来验证假设、对比设置 |

## 跨类别对比时建议对齐的设置

对比前确认两条策略的 `sampling`、`simulation`、`goal`、`fees` 一致（或只刻意改一项）。可在 UI 设置面板或 `settings.py` 中核对。

## 更多

- [../README.md](../README.md) — 策略用户空间入门  
- [../USER_GUIDE.md](../USER_GUIDE.md) — 完整 UI 操作说明  
- [../settings_example.py](../settings_example.py) — 字段大全  

命令行等价操作见 [USER_GUIDE.md 附录](../USER_GUIDE.md#附录命令行可选)。
