#!/usr/bin/env python3
"""换仓日历边界判定（不含选股编排）。"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict

from core.modules.strategy.engines.simulator.enumerator.calendar_sliced.types import (
    CalendarAsOfContext,
)

_SHARED_DIR = Path(__file__).resolve().parent
if str(_SHARED_DIR) not in sys.path:
    sys.path.insert(0, str(_SHARED_DIR))

from settings_core import SettingsCoreError, require_core_str  # noqa: E402

_VALID_PERIODS = frozenset({"month", "year"})


def require_rebalance_period(settings: Dict[str, Any]) -> str:
    period = require_core_str(settings, "rebalance_period").lower()
    if period not in _VALID_PERIODS:
        raise SettingsCoreError(
            f"settings.core.rebalance_period must be one of {sorted(_VALID_PERIODS)}, got {period!r}"
        )
    return period


def is_rebalance_period_start(ctx: CalendarAsOfContext, period: str) -> bool:
    if period == "year":
        return ctx.is_first_open_of_year
    return ctx.is_first_open_of_month


def is_rebalance_period_end(ctx: CalendarAsOfContext, period: str) -> bool:
    if period == "year":
        return ctx.is_last_open_of_year
    return ctx.is_last_open_of_month


__all__ = [
    "is_rebalance_period_end",
    "is_rebalance_period_start",
    "require_rebalance_period",
]
