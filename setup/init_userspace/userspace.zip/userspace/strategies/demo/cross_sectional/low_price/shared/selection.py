#!/usr/bin/env python3
"""横截面选股原子步骤（不含钩子编排）。"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, FrozenSet, Mapping, Optional, Sequence

from core.modules.data_contract.contract_const import DataKey
from core.modules.strategy.services.data.helper import storage_key_for
from core.modules.tag.engines.shared.staging.prior_values import parse_tag_value_scalar

_SHARED_DIR = Path(__file__).resolve().parent
if str(_SHARED_DIR) not in sys.path:
    sys.path.insert(0, str(_SHARED_DIR))

from settings_core import (  # noqa: E402
    SettingsCoreError,
    require_core_float,
    require_core_int,
    require_core_str,
    require_core_str_list,
)

INDICATORS = storage_key_for(DataKey.STOCK_INDICATORS_DAILY)
TAGS_SLOT = storage_key_for(DataKey.TAG)
_VALID_CAP_FILTERS = frozenset({"none", "indicator", "tag"})


@dataclass(frozen=True)
class RebalanceFilters:
    """选股条件，字段均来自 settings.core。"""

    min_close: float
    max_close: float
    top_n: int
    cap_filter: str
    allowed_cap_tiers: Optional[FrozenSet[str]] = None
    low_cap_max_yi: Optional[float] = None
    tag_name: Optional[str] = None

    @classmethod
    def from_settings(cls, settings: Dict[str, Any]) -> "RebalanceFilters":
        cap_filter = require_core_str(settings, "cap_filter").lower()
        if cap_filter not in _VALID_CAP_FILTERS:
            raise SettingsCoreError(
                f"settings.core.cap_filter must be one of {sorted(_VALID_CAP_FILTERS)}, "
                f"got {cap_filter!r}"
            )

        min_close = require_core_float(settings, "min_close")
        max_close = require_core_float(settings, "max_close")
        top_n = require_core_int(settings, "top_n")
        if top_n < 0:
            raise SettingsCoreError("settings.core.top_n must be >= 0")
        if min_close > max_close:
            raise SettingsCoreError(
                f"settings.core.min_close ({min_close}) must be <= max_close ({max_close})"
            )

        allowed_cap_tiers: Optional[FrozenSet[str]] = None
        low_cap_max_yi: Optional[float] = None
        tag_name: Optional[str] = None

        if cap_filter == "tag":
            allowed_cap_tiers = frozenset(require_core_str_list(settings, "allowed_cap_tiers"))
            tag_name = require_core_str(settings, "tag_name")
        elif cap_filter == "indicator":
            low_cap_max_yi = require_core_float(settings, "low_cap_max_yi")

        return cls(
            min_close=min_close,
            max_close=max_close,
            top_n=top_n,
            cap_filter=cap_filter,
            allowed_cap_tiers=allowed_cap_tiers,
            low_cap_max_yi=low_cap_max_yi,
            tag_name=tag_name,
        )

    @property
    def min_cap_wan_for_mid_plus(self) -> float:
        if self.low_cap_max_yi is None:
            raise SettingsCoreError(
                "low_cap_max_yi is only valid when cap_filter=indicator"
            )
        return self.low_cap_max_yi * 10_000.0


def find_bar_on_date(
    rows: Sequence[Mapping[str, Any]],
    as_of_date: str,
) -> Optional[Dict[str, Any]]:
    target = str(as_of_date).strip()
    if not target:
        return None
    for row in reversed(rows):
        dt = str(row.get("date") or "").strip()
        if dt == target:
            return dict(row)
        if dt and dt < target:
            break
    return None


def passes_price_range(close: float, min_close: float, max_close: float) -> bool:
    return min_close <= close <= max_close


def tier_at_date_from_tags(
    tag_rows: Sequence[Mapping[str, Any]],
    *,
    as_of_date: str,
    tag_name: str,
) -> Optional[str]:
    """取 as_of_date 当日及之前最近一条 tag 档位。"""
    day = str(as_of_date).strip()
    if not day:
        return None
    name = str(tag_name).strip()
    best_date = ""
    best_tier: Optional[str] = None
    for row in tag_rows:
        if str(row.get("tag_name") or "").strip() != name:
            continue
        row_date = str(row.get("as_of_date") or "").strip()
        if not row_date or row_date > day:
            continue
        tier = _tier_from_tag_row(row)
        if tier is None:
            continue
        if row_date >= best_date:
            best_date = row_date
            best_tier = tier
    return best_tier


def _tier_from_tag_row(row: Mapping[str, Any]) -> Optional[str]:
    raw = row.get("json_value")
    if raw is None:
        raw = row.get("value")
    if isinstance(raw, dict):
        parsed = parse_tag_value_scalar(json.dumps(raw, ensure_ascii=False))
    else:
        parsed = parse_tag_value_scalar(str(raw or ""))
    tier = str(parsed or "").strip()
    return tier or None


def passes_cap_filter(
    *,
    filters: RebalanceFilters,
    as_of_date: str,
    indicators: Sequence[Mapping[str, Any]],
    tag_rows: Sequence[Mapping[str, Any]],
) -> bool:
    if filters.cap_filter == "none":
        return True

    if filters.cap_filter == "tag":
        assert filters.allowed_cap_tiers is not None and filters.tag_name is not None
        tier = tier_at_date_from_tags(
            tag_rows,
            as_of_date=as_of_date,
            tag_name=filters.tag_name,
        )
        return tier in filters.allowed_cap_tiers

    ind = find_bar_on_date(indicators, as_of_date)
    if ind is None:
        return False
    cap_wan = _float_or_none(ind.get("total_market_value"))
    if cap_wan is None:
        return False
    return cap_wan > filters.min_cap_wan_for_mid_plus


def _float_or_none(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


__all__ = [
    "INDICATORS",
    "TAGS_SLOT",
    "RebalanceFilters",
    "find_bar_on_date",
    "passes_cap_filter",
    "passes_price_range",
    "tier_at_date_from_tags",
]
