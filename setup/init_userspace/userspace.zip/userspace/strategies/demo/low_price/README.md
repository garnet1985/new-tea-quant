# 低价股与幸存者偏差（`demo/low_price/`）

## 当前状态：**尚未实现**

需横截面 cohort 选股能力（tag / 排名 API）就绪后再做。目录为规划占位。

## 将来想说明什么

「低价股 K 线很猛」常是**幸存者样本**；看不见的结局包括 ST、退市。回测池若不处理退市，结论会偏乐观。

## 现在可在 UI / 设置里先了解的相关能力

在任意策略的 **设置面板** 或 `settings.py` 中可配置：

- `goal.stock_status_risk_management`、退市相关强平
- `simulation.template=strict` 与涨跌停边缘

跑 [RSI](../regression/README.md) 或 [随机](../random/README.md) demo 时，可在枚举报告的 opportunity 元数据中留意 ST 类标注（视策略与数据而定）。

字段说明：[settings_example.py](../../settings_example.py)。

[← 演示总览](../README.md)
