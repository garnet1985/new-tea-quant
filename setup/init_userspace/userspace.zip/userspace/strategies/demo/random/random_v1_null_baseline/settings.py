settings = {
    # ========================================
    # 策略基本信息（系统 name = 路径 demo/random/random_v1_null_baseline）
    # ========================================
    "is_enabled": True,
    "meta": {
        "display_name": "随机买卖策略v1 · 纯随机投资",
        "description": (
            "演示策略：按固定概率随机买入。止损止盈对称相等。"
            "演示意义：随机策略一定程度能反映出市场整体的收益率水平，也可以作为其他策略的收益衡量基准。"
        ),
        "keywords": ["演示", "随机", "对照组", "零技能"],
        "details": {
            "entry": [
                "固定概率，中签就买。"
            ],
        },
    },
    "market_profile": "china_a_stock",

    # ========================================
    # 策略核心参数
    # ========================================
    "core": {
        # 随机种子：如果种子一样，则每次随机结果一样
        "seed": 6,
        # 随机入场概率：0.03 表示每次随机入场概率为 3%
        "entry_probability": 0.03,
    },

    # ========================================
    # 数据配置（随机入场不依赖指标）
    # ========================================
    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "extra_required_data_sources": [],
        "min_required_records": 5,
    },

    # 与 rsi_regression 对齐：收盘出信号 → 次日开盘成交
    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "retention": {
            "max_output_versions": 5,
        },
    },

    "goal": {
        "stop_loss": {
            "stages": [
                {"name": "loss20%", "ratio": -0.2, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win20%", "ratio": 0.2, "close_invest": True}
            ],
        },
    },

    "sampling": {
        "use_sampling": False,
        "strategy": "uniform",
        "sampling_amount": 1000,
    },

    "enumerator": {
        "is_verbose": False,
    },

    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    "price_simulator": {
        "base_version": "latest",
    },

    "capital_simulator": {
        "base_version": "latest",
        "initial_capital": 100_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
