#!/usr/bin/env python3
"""随机对照演示策略 v1 — 零技能基线（null baseline）。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.base_strategy_worker import BaseStrategyWorker
from core.modules.strategy.engines.shared.data_classes.opportunity import Opportunity

logger = logging.getLogger(__name__)


class RandomNullBaselineWorker(BaseStrategyWorker):
    """
    按 ``core.entry_probability`` 随机触发买入，不包含任何选股逻辑。

    ``core.seed`` 保证 scan / simulate 可复现。
    """

    def scan_opportunity(
        self, data: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[Opportunity]:
        record_of_today = self.get_record_of_today(data)
        if record_of_today is None:
            return None

        if not self._is_lucky_day(record_of_today, settings):
            return None

        return self._build_lucky_day_opportunity(record_of_today, settings)

    def _is_lucky_day(
        self,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> bool:
        """掷骰子：roll < entry_probability 视为幸运日。"""
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self.stock_id,
            self.signal_date(record_of_today),
            seed,
        )
        return roll < entry_probability

    def _build_lucky_day_opportunity(
        self,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> Opportunity:
        """幸运日：记录随机决策上下文并产生买入机会。"""
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self.stock_id,
            self.signal_date(record_of_today),
            seed,
        )
        return self.build_opportunity(
            record_of_today,
            extra_fields={
                "random_roll": roll,
                "entry_probability": entry_probability,
                "seed": seed,
            },
        )
