settings = {
    # ========================================
    # 策略基本信息（系统 name = 路径 demo/random/random_v3_asymmetric_goal）
    # ========================================
    "is_enabled": True,
    "meta": {
        "display_name": "随机买卖策略v3 · 止盈高于止损",
        "description": "与 v2 版本一样的买入点，但止盈大于止损。期望：胜率变低，收益可能变高。",
        "keywords": ["演示", "随机", "对照组", "止损止盈不对称"],
        "details": {
            "entry": [
                "固定随机概率买入。止盈大于止损。",
            ],
        },
    },
    "market_profile": "china_a_stock",

    "core": {
        "seed": 42,
        "entry_probability": 0.03,
    },

    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {},
        },
        "extra_required_data_sources": [],
        "min_required_records": 5,
    },

    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "retention": {
            "max_output_versions": 5,
        },
    },

    "goal": {
        "stop_loss": {
            "stages": [
                {"name": "loss20%", "ratio": -0.2, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win40%", "ratio": 0.4, "close_invest": True}
            ],
        },
    },

    "sampling": {
        "use_sampling": False,
        "strategy": "uniform",
        "sampling_amount": 1000,
    },

    "enumerator": {
        "is_verbose": False,
    },

    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    "price_simulator": {
        "base_version": "latest",
    },

    "capital_simulator": {
        "base_version": "latest",
        "initial_capital": 100_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
