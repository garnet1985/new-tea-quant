#!/usr/bin/env python3
"""随机对照演示策略 v3 — 与 v1 相同入场，不对称止损止盈。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.base_strategy_worker import BaseStrategyWorker
from core.modules.strategy.engines.shared.data_classes.opportunity import Opportunity

logger = logging.getLogger(__name__)


class RandomAsymmetricGoalWorker(BaseStrategyWorker):
    """
    与 ``random_v1_null_baseline`` 相同随机入场（``seed=6``）。

    本版仅调整 ``goal``：止损 -20%、止盈 +30%，用于观察不对称出场对 ROI 分布的影响。
    """

    def scan_opportunity(
        self, data: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[Opportunity]:
        record_of_today = self.get_record_of_today(data)
        if record_of_today is None:
            return None

        if not self._is_lucky_day(record_of_today, settings):
            return None

        return self._build_lucky_day_opportunity(record_of_today, settings)

    def _is_lucky_day(
        self,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> bool:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self.stock_id,
            self.signal_date(record_of_today),
            seed,
        )
        return roll < entry_probability

    def _build_lucky_day_opportunity(
        self,
        record_of_today: Dict[str, Any],
        settings: Dict[str, Any],
    ) -> Opportunity:
        seed = self.core_int(settings, "seed")
        entry_probability = self.core_float(
            settings,
            "entry_probability",
            clamp=(0.0, 1.0),
        )
        roll = self.deterministic_roll(
            self.stock_id,
            self.signal_date(record_of_today),
            seed,
        )
        return self.build_opportunity(
            record_of_today,
            extra_fields={
                "random_roll": roll,
                "entry_probability": entry_probability,
                "seed": seed,
            },
        )
