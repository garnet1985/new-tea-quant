settings = {
    # ========================================
    # 策略基本信息（系统 name = 路径 demo/regression/bb/bb_v1_lower_touch）
    # ========================================
    "is_enabled": True,
    "meta": {
        "display_name": "布林带下轨回归 · v1 基础",
        "description": (
            "演示策略：日线收盘价落在布林带下轨下方时买入，演示均值回归「尺子」与 base K 线 indicators 注入。"
            "出场为固定止盈止损 + 持仓期限，便于与后续 v2（周线过滤）、v3（protect/dynamic）对比。"
        ),
        "keywords": ["演示", "回归", "布林带", "BB"],
        "details": {
            "entry": [
                "BB(20, 2)：收盘价 < 下轨（相对近期均值偏低的启发式信号）",
                "数据：base stock.kline.daily + indicators.bbands",
                "建议对比：demo/regression/rsi/rsi_v1_without_value_anchor（另一把尺子）",
            ],
        },
    },
    "market_profile": "china_a_stock",

    "core": {},

    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {
                "bbands": [{"length": 20, "std": 2.0}],
            },
        },
        "extra_required_data_sources": [],
        "min_required_records": 30,
    },

    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "retention": {
            "max_output_versions": 5,
        },
    },

    "goal": {
        "stop_loss": {
            "stages": [
                {"name": "loss20%", "ratio": -0.2, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win20%", "ratio": 0.2, "close_invest": True},
            ],
        },
    },

    "sampling": {
        "use_sampling": False,
        "strategy": "uniform",
        "sampling_amount": 1000,
    },

    "enumerator": {
        "is_verbose": False,
    },

    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    "price_simulator": {
        "base_version": "latest",
    },

    "capital_simulator": {
        "base_version": "latest",
        "initial_capital": 100_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
