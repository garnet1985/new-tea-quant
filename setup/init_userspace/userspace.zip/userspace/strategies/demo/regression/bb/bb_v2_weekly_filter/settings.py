settings = {
    # ========================================
    # 策略基本信息（系统 name = 路径 demo/regression/bb/bb_v2_weekly_filter）
    # ========================================
    "is_enabled": True,
    "meta": {
        "display_name": "布林带下轨回归 · v2 周线过滤",
        "description": (
            "演示策略：在 v1（日线下轨下方买入）基础上，要求周线收盘价也落在周线布林带下轨下方，"
            "才允许产生信号。演示 extra_required_data_sources 注入 stock.kline.weekly 与多周期过滤。"
        ),
        "keywords": ["演示", "回归", "布林带", "BB", "多周期", "周线"],
        "details": {
            "entry": [
                "继承 v1：日线 BB(20,2) 收盘 < 下轨",
                "周线过滤：截至当日的最新周线收盘 < 周线 BB 下轨（extra stock.kline.weekly）",
                "数据前提：需已 renew 周线 K 线（cli.py -r stock_klines，config 含 weekly term）",
                "建议对比：demo/regression/bb/bb_v1_lower_touch（无周线过滤）",
            ],
        },
    },
    "market_profile": "china_a_stock",

    "core": {},

    "data": {
        "base_required_data": {
            "data_id": "stock.kline.daily",
            "params": {"adjust": "qfq"},
            "indicators": {
                "bbands": [{"length": 20, "std": 2.0}],
            },
        },
        "extra_required_data_sources": [
            {
                "data_id": "stock.kline.weekly",
                "params": {"adjust": "qfq"},
                "indicators": {
                    "bbands": [{"length": 20, "std": 2.0}],
                },
            },
        ],
        "min_required_records": 100,
    },

    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "retention": {
            "max_output_versions": 5,
        },
    },

    "goal": {
        "stop_loss": {
            "stages": [
                {"name": "loss20%", "ratio": -0.2, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win20%", "ratio": 0.2, "close_invest": True},
            ],
        },
    },

    "sampling": {
        "use_sampling": False,
        "strategy": "uniform",
        "sampling_amount": 1000,
    },

    "enumerator": {
        "is_verbose": False,
    },

    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    "price_simulator": {
        "base_version": "latest",
    },

    "capital_simulator": {
        "base_version": "latest",
        "initial_capital": 100_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
