#!/usr/bin/env python3
"""布林带下轨回归演示策略 v3：v2 入场 + protect/dynamic 分阶段出场。"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from core.modules.strategy.base_strategy_worker import BaseStrategyWorker
from core.modules.strategy.engines.shared.data_classes.opportunity import Opportunity

_BB_PKG = Path(__file__).resolve().parents[1]
if str(_BB_PKG) not in sys.path:
    sys.path.insert(0, str(_BB_PKG))

from bb_indicators import (  # noqa: E402
    WEEKLY_KLINE_SLOT,
    bbands_params,
    close_and_lower_band,
    has_kline_warmup,
    is_close_below_lower_band,
)

logger = logging.getLogger(__name__)


class BbManagedExitWorker(BaseStrategyWorker):
    """与 v2 相同的多周期 BB 入场；出场由 settings.goal 的 protect/dynamic 配置驱动。"""

    def scan_opportunity(
        self, data: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[Opportunity]:
        record_of_today = self.get_record_of_today(data)
        if record_of_today is None:
            return None

        params = bbands_params(settings)
        klines = data.get("klines") or []
        if not has_kline_warmup(klines, settings):
            return None
        if not is_close_below_lower_band(record_of_today, params):
            return None

        weekly_rows = data.get(WEEKLY_KLINE_SLOT) or []
        if not has_kline_warmup(weekly_rows, settings):
            return None

        weekly_last = weekly_rows[-1]
        if not is_close_below_lower_band(weekly_last, params):
            return None

        daily_close, daily_lower = close_and_lower_band(record_of_today, params)
        weekly_close, weekly_lower = close_and_lower_band(weekly_last, params)
        return self.build_opportunity(
            record_of_today,
            extra_fields={
                "close": daily_close,
                "bb_lower": daily_lower,
                "weekly_close": weekly_close,
                "weekly_bb_lower": weekly_lower,
                "weekly_bar_date": weekly_last.get("date"),
                "bb_length": int(params["length"]),
                "bb_std": float(params.get("std", 2.0)),
            },
        )
