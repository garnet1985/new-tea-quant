settings = {
    # ========================================
    # 策略基本信息（系统 name = 路径 example，用户不可编辑）
    # ========================================
    "is_enabled": True,
    "meta": {
        "display_name": "RSI超跌反弹",
        "description": "日线超卖反弹演示策略：RSI(14) 低于阈值时产生买入信号，配合固定止盈止损与持仓期限退出。",
        "keywords": ["超卖", "技术面", "RSI"],
        "details": {
            "entry": [
                "RSI(14) 低于超卖阈值（见 core.rsi_oversold_threshold，默认 20）",
            ],
        },
    },
    "market_profile": "china_a_stock",

    # ========================================
    # 策略核心参数
    # ========================================
    "core": {
        "rsi_oversold_threshold": 20,
    },

    # ========================================
    # 数据配置
    # ========================================
    "data": {
        "base_required_data": {
            "params": {"term": "daily", "adjust": "qfq"},
        },
        "extra_required_data_sources": [],
        "min_required_records": 30,
        "indicators": {
            "rsi": [{"length": 14}],
        },
    },

    # 日频：收盘出信号 → 次日开盘成交；持仓用收盘价盯盘/平仓
    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
        "retention": {
            "max_output_versions": 2,
        },
    },

    "goal": {
        "expiration": {
            "fixed_window_in_days": 30,
            "is_trading_days": True,
        },
        "stop_loss": {
            "stages": [
                {"name": "loss20%", "ratio": -0.2, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win20%", "ratio": 0.2, "sell_ratio": 0.5},
                {"name": "win30%", "ratio": 0.3, "close_invest": True},
            ],
        },
    },

    # ========================================
    # 采样（示例默认：小股票池 + 采样，便于本地快速回测）
    # ========================================
    "sampling": {
        "use_sampling": False,
        "strategy": "uniform",
        "sampling_amount": 1000,
        # "pool": {"file": "stock_lists/test_stocks.txt"},
    },

    # ========================================
    # 枚举器（调度参数见 userspace/config/worker.json → job_pipeline.enumerator.dispatch）
    # ========================================
    "enumerator": {
        "is_verbose": False,
    },

    # ========================================
    # 费率（全链路共用）
    # ========================================
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    # ========================================
    # 价格因子 / 资金（调度参数见 worker.json → job_pipeline.price_factor.dispatch）
    # ========================================
    "price_simulator": {
        "base_version": "latest",
    },

    "capital_simulator": {
        "base_version": "latest",
        "initial_capital": 1_000_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # ========================================
    # 扫描器
    # ========================================
    "scanner": {
        "adapters": ["console"],
        "use_strict_previous_trading_day": False,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
