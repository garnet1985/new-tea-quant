#!/usr/bin/env python3
"""PE 分位与 stock.indicators.daily contract 单元测试。"""

from __future__ import annotations

import unittest

from core.modules.data_contract.contract_const import DataKey
from core.modules.strategy.services.data.helper import storage_key_for
from userspace.strategies.demo.regression.rsi.rsi_v3_pe_percentile_gate.strategy_worker import (
    pe_percentile_from_rows,
)


class TestPePercentileFromRows(unittest.TestCase):
    def test_percentile_at_bottom_of_history(self):
        rows = [{"pe_ttm": float(v)} for v in [20, 18, 22, 15, 16, 14]]
        stats = pe_percentile_from_rows(rows, "pe_ttm", min_history_days=6)
        self.assertIsNotNone(stats)
        current, percentile = stats
        self.assertEqual(current, 14.0)
        self.assertEqual(percentile, 100.0 * 1 / 6)

    def test_percentile_rejects_insufficient_history(self):
        rows = [{"pe_ttm": 10.0}, {"pe_ttm": 12.0}]
        self.assertIsNone(pe_percentile_from_rows(rows, "pe_ttm", min_history_days=60))

    def test_percentile_skips_non_positive_pe(self):
        rows = [{"pe_ttm": 10.0}] * 59 + [{"pe_ttm": -1.0}, {"pe_ttm": 8.0}]
        stats = pe_percentile_from_rows(rows, "pe_ttm", min_history_days=60)
        self.assertIsNotNone(stats)
        self.assertEqual(stats[0], 8.0)


class TestStockIndicatorsDailySlot(unittest.TestCase):
    def test_storage_key(self):
        self.assertEqual(
            storage_key_for(DataKey.STOCK_INDICATORS_DAILY),
            "stock.indicators.daily",
        )


if __name__ == "__main__":
    unittest.main()
