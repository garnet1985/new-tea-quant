# 追热点（Trend / Hot Money）— 已下架

**状态：** 已移除（2026-06-15）  
**原因：** 在现有 per-entity 架构下，资金流类「热度」策略难以表达横截面选股与可靠入场；实验效果不达 demo 标准。

原规划目录 `demo/trend/hot_money/`（v1 策略内计算、v2 tag 消费、`moneyflow-heat` tag scenario）已删除。

**数据层保留：** `stock.moneyflow.daily`（`sys_stock_moneyflow`）仍可用于未来策略或 tag，与 demo 下架无关。

**后续若重做趋势/热度 demo，建议前置条件：**

1. 截面排名或 tag 层预计算分位（Top N / 市场分位）
2. 价量自相对热度（换手、量比 vs 自身历史）优先于单日净流入追涨
3. 入场时机：回调/防追高，避免 signal 日收盘 → 次日开盘直追

申万行业扩展仍见 [SW_INDUSTRY_AND_TREND_PLAN.md](../../extensions/data_source/docs/SW_INDUSTRY_AND_TREND_PLAN.md)。
