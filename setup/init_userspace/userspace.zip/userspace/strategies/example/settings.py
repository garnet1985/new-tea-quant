settings = {
    # ========================================
    # 策略基本信息
    # ========================================
    # 展示名；磁盘目录为 example/，pool 等相对路径按目录名解析
    "name": "RSI超跌",
    "description": "RSI(14) 低于阈值时视为超卖并产生买入信号（演示策略，结果仅供跑通流程）。",
    "is_enabled": True,
    "market_profile": "china_a_stock",

    # ========================================
    # 策略核心参数
    # ========================================
    "core": {
        "rsi_oversold_threshold": 20,
    },

    # ========================================
    # 数据配置
    # ========================================
    "data": {
        "base_required_data": {
            "params": {"term": "daily", "adjust": "qfq"},
        },
        "extra_required_data_sources": [],
        "min_required_records": 30,
        "indicators": {
            "rsi": [{"length": 14}],
        },
    },

    # 日频：收盘出信号 → 次日开盘成交；持仓用收盘价盯盘/平仓
    "simulation": {
        "template": "custom",
        "monitor_price_model": "close",
        "buy_price_model": "next_open",
        "sell_price_model": "close",
        "slippage": {"buy_bps": 5.0, "sell_bps": 5.0},
        "edges": {
            "no_next_bar": "skip_trade",
            "allow_buy_at_limit_up": False,
            "allow_sell_at_limit_down": False,
        },
    },

    "goal": {
        "expiration": {
            "fixed_window_in_days": 30,
            "is_trading_days": True,
        },
        "stop_loss": {
            "stages": [
                {"name": "loss10%", "ratio": -0.1, "close_invest": True},
            ],
        },
        "take_profit": {
            "stages": [
                {"name": "win10%", "ratio": 0.1, "sell_ratio": 0.5},
                {"name": "win20%", "ratio": 0.2, "close_invest": True},
            ],
        },
    },

    # ========================================
    # 采样（示例默认：小股票池 + 采样，便于本地快速回测）
    # ========================================
    "sampling": {
        "use_sampling": False,
        "strategy": "pool",
        "sampling_amount": 10,
        "pool": {"file": "stock_lists/test_stocks.txt"},
    },

    # ========================================
    # 枚举器
    # ========================================
    "enumerator": {
        "max_output_versions": 2,
        "max_workers": "auto",
        "is_verbose": False,
        "memory_budget_mb": "auto",
        "warmup_batch_size": "auto",
        "min_batch_size": "auto",
        "max_batch_size": "auto",
        "monitor_interval": 5,
    },

    # ========================================
    # 费率（全链路共用）
    # ========================================
    "fees": {
        "commission_rate": 0.00025,
        "min_commission": 5.0,
        "stamp_duty_rate": 0.001,
        "transfer_fee_rate": 0.0,
    },

    # ========================================
    # 价格因子 / 资金（读取枚举产物，不重算 simulation）
    # ========================================
    "price_simulator": {
        "max_workers": "auto",
        "base_version": "latest",
    },

    "capital_simulator": {
        "max_workers": "auto",
        "base_version": "latest",
        "initial_capital": 100_000,
        "allocation": {
            "mode": "equal_capital",
            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,
            "lots_per_trade": 1,
            "kelly_fraction": 0.5,
            "skip_trade_when_insufficient": True,
        },
        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # ========================================
    # 扫描器
    # ========================================
    "scanner": {
        "max_workers": "auto",
        "adapters": ["console"],
        "use_strict_previous_trading_day": True,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
