#!/usr/bin/env python3
"""Example Strategy Worker — RSI 超卖演示策略。"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from core.modules.strategy.base_strategy_worker import BaseStrategyWorker
from core.modules.strategy.engines.shared.data_classes.opportunity import Opportunity

logger = logging.getLogger(__name__)


class ExampleStrategyWorker(BaseStrategyWorker):
    """当 RSI(14) 低于 ``core.rsi_oversold_threshold`` 时产生买入信号。"""

    def scan_opportunity(
        self, data: Dict[str, Any], settings: Dict[str, Any]
    ) -> Optional[Opportunity]:
        core_config = settings["core"]
        rsi_length = int(settings["data"]["indicators"]["rsi"][0]["length"])

        klines = data.get("klines", [])
        if not klines or len(klines) < rsi_length:
            return None

        latest_kline = klines[-1]
        rsi_field = f"rsi{rsi_length}"
        latest_rsi = latest_kline.get(rsi_field)
        if latest_rsi is None:
            return None

        if latest_rsi >= core_config["rsi_oversold_threshold"]:
            return None

        return Opportunity(
            stock=self.stock_info,
            record_of_today=latest_kline,
            extra_fields={"rsi_value": latest_rsi},
        )
