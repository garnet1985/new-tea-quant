settings = {
    # ========================================
    # 策略基本信息
    # ========================================
    "name": "RSI超跌",
    "description": "策略假设当RSI指数低于20时股票处于超跌状态, 即将发生回归,可以尝试买入。（注意：这是一个简化过的演示策略, 结果没有可参考性）",
    "is_enabled": True,

    # ========================================
    # 策略核心参数（仅示例策略真正需要的字段）
    # ========================================
    "core": {
        # 超卖阈值
        "rsi_oversold_threshold": 20,
    },

    # ========================================
    # 数据配置（仅保留枚举器 / 模拟器真正需要的字段）
    # ========================================
    "data": {
        # 主数据依赖：data_id 可省略（默认 stock.kline）；params.term 必填；adjust 默认 qfq，可显式写出
        "base_required_data": {
            "params": {"term": "daily", "adjust": "qfq"},
        },
        "extra_required_data_sources": [],
        # 最小要求的基础周期记录数
        "min_required_records": 30,

        # 仅计算本策略需要的 RSI 指标
        "indicators": {
            "rsi": [
                {"period": 14}
            ]
        },
    },

    "goal": {
        # 简单的到期平仓
        "expiration": {
            "fixed_window_in_days": 30,
            "is_trading_days": True
        },
        # 简单的止损
        "stop_loss": {
            "stages": [
                {
                    "name": "loss10%",
                    "ratio": -0.1,
                    "close_invest": True
                }
            ]
        },
        "take_profit": {
            "stages": [
                {
                    "name": "win10%",
                    "ratio": 0.1,
                    "sell_ratio": 0.5,
                },
                {
                    "name": "win20%",
                    "ratio": 0.2,
                    "close_invest": True
                }
            ]
        }
    },

    # ========================================
    # 股票采样配置（统一「采样 / 全量」开关：枚举 + 价格因子 + 资金模拟共用）
    # ========================================
    "sampling": {
        # True: 全流程走采样（结果在 test/）；False: 全量（结果在 output/）
        "use_sampling": False,
        "strategy": "continuous",
        "sampling_amount": 20,
        # 可选：限制模拟回测窗口（须为 YYYYMMDD 或留空）
        # "start_date": "",
        # "end_date": "",
        # "pool": {
        #     "stock_ids": ["000001.SZ", "000002.SZ"],
        # }
    },

    # ========================================
    # 枚举器配置（性能与版本保留；不再包含 use_sampling / max_test_versions）
    # ========================================
    "enumerator": {
        # 最多保留的全量枚举（output）版本数（默认 3）
        "max_output_versions": 2,

        # 枚举器专用 worker 数量（"auto" 或具体数字）
        "max_workers": "auto",

        # 是否输出详细 worker/scheduler 决策日志
        "is_verbose": True,

        # Memory-aware batch scheduler 配置（全部支持 "auto" 自动计算）
        "memory_budget_mb": "auto",
        "warmup_batch_size": "auto",
        "min_batch_size": "auto",
        "max_batch_size": "auto",
        # 每多少个 batch 输出一次监控日志
        "monitor_interval": 5,
    },

    # ========================================
    # 交易成本配置（根级 fees 为全链路费率唯一来源）
    # ========================================
    "fees": {
        "commission_rate": 0.00025,      # 佣金率（双边，万2.5）
        "min_commission": 5.0,            # 最低佣金（元）
        "stamp_duty_rate": 0.001,         # 印花税率（卖出时，千1）
        "transfer_fee_rate": 0.0,         # 过户费（如需要）
    },

    # ========================================
    # 价格因子模拟器（是否采样由 sampling.use_sampling 决定）
    # ========================================
    "price_simulator": {
        "max_workers": "auto",
        "base_version": "latest",
    },

    # ========================================
    # 资金分配模拟器（CapitalAllocationSimulator）
    # ========================================
    "capital_simulator": {
        "max_workers": "auto",
        "base_version": "latest",

        # 初始资金（元）
        "initial_capital": 1_000_000,

        # 资金分配策略
        "allocation": {
            #   - "equal_capital" / "equal_shares" / "kelly" / "custom"
            "mode": "equal_capital",

            "max_portfolio_size": 10,
            "max_weight_per_stock": 0.3,

            "lot_size": 100,
            "lots_per_trade": 1,

            "kelly_fraction": 0.5,
        },

        "output": {
            "save_trades": True,
            "save_equity_curve": True,
        },
    },

    # ========================================
    # 扫描器（选股运行）
    # ========================================
    "scanner": {
        "max_workers": "auto",
        "adapters": ["console"],
        "use_strict_previous_trading_day": True,
        "max_cache_days": 10,
        "watch_list": "",
    },
}
